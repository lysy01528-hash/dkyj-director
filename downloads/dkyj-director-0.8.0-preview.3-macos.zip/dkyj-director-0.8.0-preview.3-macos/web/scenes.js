(()=>{
 const $=id=>document.getElementById(id);let state={},signature='',pending=null,event=0;
 const feedback=m=>{$('sceneFeedback').textContent=m||''};
 function send(body){if(pending!==null)return;pending=event;feedback('正在处理场次…');window.previsControl(body,null,error=>{pending=null;feedback(error.message||'操作未确认，请检查连接后重试')})}
 async function discardChoice(){return !state.scenes?.draft||await window.previsConfirm('当前是未保存的临时场次。放弃临时修改并切换？你也可以取消，先删旧场次腾位后保存。')}
 $('sceneCreateForm').onsubmit=async e=>{e.preventDefault();if(!await discardChoice())return;send({type:'scene_create',name:$('sceneName').value,discard_draft:!!state.scenes?.draft})};
 $('sceneSave').onclick=()=>send({type:'scene_save'});
 $('sceneDiscard').onclick=async()=>{if(await discardChoice())send({type:'scene_discard',discard_draft:true})};
 window.previsScenes={render(s){
  state=s;event=s.project_event||0;
  if(pending!==null&&event>pending){feedback(s.error||s.project_message);pending=null}
  const data=s.scenes||{saved:[],saved_count:0,free_limit:3},pro=s.license?.plan==='pro';
  $('sceneQuota').textContent=pro?`${data.saved_count} 场 · Pro 不限`:`${data.saved_count} / ${data.free_limit||3} 场 · Lite`;
  $('sceneDraftNotice').textContent=data.draft?`正在编辑临时场次「${data.draft.name}」，尚未保存。${pro||data.saved_count<(data.free_limit||3)?'现在可点击保存。':'请手动删除一个旧场次腾位，再保存。'}`:'';
  $('sceneDiscard').hidden=!data.draft;
  const locked=pending!==null||s.recording||s.export?.status==='running'||s.demo;
  for(const b of document.querySelectorAll('.scene-library button,.scene-library input'))b.disabled=!!locked||b.dataset.unavailable==='true';
  const sig=JSON.stringify(data);if(sig===signature)return;signature=sig;$('sceneList').replaceChildren();
  for(const item of data.saved||[]){const row=document.createElement('article');row.className='scene-card';const label=document.createElement('div'),name=document.createElement('strong');name.textContent=item.name;const info=document.createElement('small');info.textContent=item.id===data.active&&!data.draft?'当前场次':item.available?'已保存':'文件缺失';label.append(name,info);const actions=document.createElement('div');actions.className='scene-actions';
   const open=document.createElement('button');open.textContent='打开';open.dataset.unavailable=String(!item.available||item.id===data.active&&!data.draft);open.disabled=locked||open.dataset.unavailable==='true';open.onclick=async()=>{if(await discardChoice())send({type:'scene_switch',id:item.id,discard_draft:!!data.draft})};
   const del=document.createElement('button');del.textContent='删除';del.dataset.unavailable=String(data.saved.length<=1);del.disabled=locked||data.saved.length<=1;del.onclick=async()=>{if(await window.previsConfirm(`删除已保存场次「${item.name}」以腾出额度？文件会保留在项目 trash 备份中，当前临时场次不会被删除。`))send({type:'scene_delete',id:item.id})};actions.append(open,del);row.append(label,actions);$('sceneList').append(row);
  }
 }};
})();
