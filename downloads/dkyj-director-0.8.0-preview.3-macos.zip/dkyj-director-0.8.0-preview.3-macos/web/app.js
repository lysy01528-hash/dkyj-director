(()=>{
const $=s=>document.querySelector(s), token=new URLSearchParams(location.search).get('token')||'';
if(!$('#cameraSelect')){const s=document.createElement('select');s.id='cameraSelect';s.setAttribute('aria-label','选择摄影机');s.innerHTML='<option>Camera_Phone</option>';$('#sensorBtn').before(s)}
const ui={image:$('#frame'),wait:$('#frameWait'),dot:$('#statusDot'),conn:$('#connectionText'),fps:$('#fpsText'),camera:$('#cameraName'),take:$('#takeName'),frameText:$('#frameText'),time:$('#timeText'),badge:$('#recordBadge'),sensor:$('#sensorBanner'),sensorBtn:$('#sensorBtn'),timeline:$('#timeline'),play:$('#playBtn'),stop:$('#stopBtn'),record:$('#recordBtn'),recordStatus:$('#recordStatus'),export:$('#exportBtn'),download:$('#downloadLink'),speed:$('#speed'),lens:$('#lens'),speedValue:$('#speedValue'),lensValue:$('#lensValue'),start:$('#startText'),duration:$('#durationText'),end:$('#endText'),toast:$('#toast')};
const phoneEntry=new URLSearchParams(location.search).get('phone')==='1'||/iPhone|iPod/.test(navigator.userAgent||'');let phoneProject=null;
const clientId=globalThis.crypto?.randomUUID?.()||('web-'+Math.random().toString(36).slice(2));
let state={},busy=false,oldURL='',sensorOn=false,sensorPaused=false,base=null,gyroReady=false,gyroLatest=null,move=[0,0,0],pendingLook=[0,0],latestInput=null,inputDirty=false,zeroPending=false,drag=null,joy=null,keys={},lastCameras=[],recordIntent=null,lastErrorToast=0,continuousFailures=0,oldRecording=false,resumePending=false;
let inputGeneration=0,manualPitch=0,gamepadMode='off',gamepadIndex=null,gamepadEpoch=0,gamepadStarted=0,gamepadLens=35,lastPadLensSent=0,gamepadReason='蓝牙连接手柄后，点击「手柄运镜」。';
const gamepadApi=window.DKYJGamepad||{},gamepadStore=key=>{try{return globalThis.localStorage?.getItem(key)}catch(_){return null}},setGamepadStore=(key,value)=>{try{globalThis.localStorage?.setItem(key,value)}catch(_){}},gamepadProfile=gamepadApi.getProfile?gamepadApi.getProfile(gamepadStore('dkyj.gamepad.profile')):{key:'xbox',label:'Xbox',lower:6,raise:7,zoomOut:4,zoomIn:5};
let activeGamepadProfile=gamepadProfile.key;
const gamepadInput=gamepadApi.Input?new gamepadApi.Input(activeGamepadProfile):null;
function profileConfig(){return gamepadApi.getProfile?gamepadApi.getProfile(activeGamepadProfile):{key:'xbox',label:'Xbox',lower:6,raise:7,zoomOut:4,zoomIn:5}}
function profileLabels(){return activeGamepadProfile==='ps5'?{lower:'L2',raise:'R2',zoomOut:'L1',zoomIn:'R1'}:{lower:'LT',raise:'RT',zoomOut:'LB',zoomIn:'RB'}}
function updateGamepadProfileUI(){const p=profileConfig(),l=profileLabels(),sel=$('#gamepadProfile');if(sel&&sel.value!==p.key)sel.value=p.key;const title=$('#gamepadGuideTitle');if(title)title.textContent=`${p.label} · 手柄运镜`;const trigger=$('#gamepadTriggerLabel');if(trigger)trigger.textContent=`${l.lower} / ${l.raise}`;const bumper=$('#gamepadBumperLabel');if(bumper)bumper.textContent=`${l.zoomOut} / ${l.zoomIn}`;const note=$('#gamepadGuideNote');if(note)note.textContent=`录制用下方网页按钮。切换页面或断连后，回中并再次启用。${p.key==='ps5'?'PS5 使用标准映射，尚未真机验证。':''}同一时刻请只用一台设备控制机位。`;const btn=$('#gamepadBtn');if(btn)btn.title=`${p.label} 手柄控制摄影机`;document.querySelectorAll('[data-move]').forEach(b=>b.title=`按住${b.dataset.move==='up'?'升高':'降低'}机位 · ${b.dataset.move==='up'?l.raise:l.lower}`);document.querySelectorAll('[data-look]').forEach(b=>b.title=`按住${b.dataset.look==='up'?'抬头':'低头'} · 右摇杆向${b.dataset.look==='up'?'上':'下'}`)}
function setGamepadProfile(value){const next=gamepadApi.getProfile?gamepadApi.getProfile(value):{key:'xbox',label:'Xbox'};if(next.key===activeGamepadProfile){updateGamepadProfileUI();return}if(gamepadMode!=='off')stopGamepad('手柄类型已切换 · 请重新点击手柄运镜');else{clearControls();enqueue({type:'input',move:[0,0,0],look:[0,0]})}activeGamepadProfile=next.key;gamepadInput?.setProfile?.(activeGamepadProfile);setGamepadStore('dkyj.gamepad.profile',activeGamepadProfile);updateGamepadProfileUI()}
const discrete=[], api=(p,o={})=>{const AC=globalThis.AbortController,ac=AC?new AC():null,timer=setTimeout(()=>ac?.abort(),4000),opts={...o,headers:{'Content-Type':'application/json',...(o.headers||{})}};if(ac)opts.signal=ac.signal;return fetch(p+(p.includes('?')?'&':'?')+'token='+encodeURIComponent(token),opts).finally(()=>clearTimeout(timer))};
const toast=m=>{ui.toast.textContent=m;ui.toast.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>ui.toast.classList.remove('show'),2600)};
const limitedToast=m=>{const now=Date.now();if(now-lastErrorToast>2200){lastErrorToast=now;toast(m)}};
function cancelQueued(type){for(let i=discrete.length-1;i>=0;i--)if(discrete[i].body.type===type&&!(commandBusy&&i===0))discrete.splice(i,1)}
function enqueue(body,done,failed){
 if(!body.input_source&&['record','settings'].includes(body.type))body.input_source=gamepadMode!=='off'?'gamepad':'manual';
 if(['play','pause','stop','seek','camera','reset_camera','project_save','project_switch','project_create','project_update','scene_save','scene_switch','scene_create','scene_delete','scene_discard','demo_start','demo_exit','export'].includes(body.type))stopGamepad('操作已切换 · 再次点击手柄运镜启用');
 if(body.type==='seek'||body.type==='settings'){
  const index=discrete.findLastIndex((item,i)=>!(commandBusy&&i===0)&&item.body.type===body.type&&Object.keys(item.body).join()===Object.keys(body).join());
  if(index>=0){discrete[index]={body,done,failed,retries:0};return}
 }
 discrete.push({body,done,failed,retries:0});pump()
 }
async function post(body){
 const AC=globalThis.AbortController,ac=AC?new AC():null,timer=setTimeout(()=>ac?.abort(),4000);
 try{const opts={method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,client_id:clientId})};if(ac)opts.signal=ac.signal;
 const r=await fetch('/api/control?token='+encodeURIComponent(token),opts);let d;
 try{d=await r.json()}catch(_){const e=Error('服务器未返回有效结果（HTTP '+r.status+'）');e.status=r.status;throw e}
 if(!r.ok||d.ok===false){const e=Error(d.error||`HTTP ${r.status}`);e.status=r.status;throw e}return d;
 }finally{clearTimeout(timer)}
}
let commandBusy=false,continuousBusy=false,lastInputSent=0,lastContinuousType='';
function pump(){if(commandBusy||continuousBusy||!discrete.length)return;commandBusy=true;const item=discrete[0];post(item.body).then(()=>{discrete.shift();item.done?.();}).catch(e=>{item.retries++;if(e.status===400||e.status===403||e.status===409||item.retries>=3){discrete.shift();item.failed?.(e);if(item.body.type==='controller_begin')stopGamepad('手柄接管失败：'+e.message);if(item.body.type==='record'){recordIntent=null;stopGamepad('录制命令失败 · 手柄已暂停')}if(item.body.type==='resume_live'&&gamepadMode!=='off')stopGamepad('机位恢复失败 · 请重新启用手柄');if(item.body.type==='resume_live'){resumePending=false;ui.sensor.textContent='取景恢复失败 · 请重试'}limitedToast((e.status===403?'无权执行：':e.status===400?'参数错误：':'命令未确认：')+e.message)}else limitedToast('命令发送失败，正在重试')}).finally(()=>{commandBusy=false;setTimeout(pump,item.retries?300:0)})}
function sendContinuous(){
 if(commandBusy||continuousBusy||sensorPaused)return;
 let body=null,sentLook=[0,0],sentMove=null;const generation=inputGeneration;
 if(gyroLatest&&gyroReady&&!zeroPending&&lastContinuousType==='input')body={type:'orientation',quaternion:gyroLatest};
 else if(inputDirty||zeroPending||pendingLook.some(Boolean)||(move.some(Boolean)&&Date.now()-lastInputSent>140)){
  sentLook=[...pendingLook];sentMove=[...(latestInput||move)];body={type:'input',move:sentMove,look:sentLook};
 }else if(gyroLatest&&gyroReady)body={type:'orientation',quaternion:gyroLatest};
 if(!body&&gamepadMode==='active'&&Date.now()-lastInputSent>800)body={type:'controller_heartbeat'};
 if(!body)return;body.input_source=gamepadMode==='active'?'gamepad':'manual';continuousBusy=true;lastContinuousType=body.type;
 post(body).then(()=>{continuousFailures=0;lastInputSent=Date.now();if(body.type==='input'){
  // A release/pause during an in-flight request invalidates its old deltas.
  if(generation===inputGeneration){pendingLook[0]-=sentLook[0];pendingLook[1]-=sentLook[1];zeroPending=false;if(JSON.stringify(latestInput)===JSON.stringify(sentMove)&&!pendingLook.some(Boolean))inputDirty=false;}
 }}).catch(e=>{
  continuousFailures++;if(gamepadMode!=='off')stopGamepad('网络中断 · 手柄已暂停，请重新启用');
  if(continuousFailures>=3){clearControls();sensorPaused=true;limitedToast('连续控制已暂停，请检查连接后点击“继续取景”')}
  else limitedToast('控制发送失败：'+(e.status?'HTTP '+e.status+' · ':'')+(e.name==='AbortError'?'请求超时':e.message));
 }).finally(()=>{continuousBusy=false;pump()});
}
setInterval(sendContinuous,50);
function render(s){
 const previousProject=state.project_event;state=s||{};
 if(gamepadMode!=='off'&&(!s.connected||s.export?.status==='running'||(previousProject!==undefined&&s.project_event!==previousProject)))stopGamepad('场景或连接已变更 · 请重新启用手柄'); const take=s.recorded_take; const status=s.record_status||((s.recording)?'recording':take?'ready':'idle'); const held=!!s.control_hold;
 if(held&&!s.recording){sensorPaused=true;if(gamepadMode==='active')stopGamepad('回放已暂停取景 · 点击手柄运镜继续')}
 if(gamepadMode==='centering'&&s.connected&&!held&&(!s.playing||s.recording)){gamepadMode='active';sensorPaused=false;gamepadNotice('请松开摇杆与按键，再开始运镜')}
 if(gamepadMode==='active'&&s.playing&&!s.recording)stopGamepad('排练中 · 手柄已暂停');
 const height=$('#cameraHeight');if(height)height.textContent=Number.isFinite(s.camera_height)?'机位 Z '+s.camera_height.toFixed(2)+' m':'机位 Z — m';
 if(oldRecording&& !s.recording && status!=='recording') pauseSensor(take?.frames>=2?'已录制 · 点击继续取景':'未录制完成 · 点击继续取景');
 if(s.recording && !oldRecording && sensorPaused && !resumePending && recordIntent!=='stop'){sensorPaused=false;ui.sensor.textContent='录制中 · 转动手机取景'} oldRecording=!!s.recording;
 ui.conn.textContent=s.connected?'已连接':'等待 Blender';ui.dot.style.background=s.connected?'var(--yellow)':'#666';ui.fps.textContent=(s.stream_fps||'--')+' FPS';ui.camera.textContent=s.camera||'Camera_Phone';
 ui.take.textContent=take?.name?`已录制：${take.name}`:'未录制镜头';
 const frame=Number(s.frame||0),start=Number(s.frame_start||1),end=Number(s.frame_end||240),fps=Number(s.fps||24);
 ui.frameText.textContent=String(frame).padStart(4,'0');ui.time.textContent=Math.max(0,(frame-start)/fps).toFixed(1)+'s';ui.timeline.min=start;ui.timeline.max=end;ui.timeline.value=frame||start;ui.start.textContent=String(start).padStart(2,'0');ui.end.textContent=String(end);ui.duration.textContent=((end-start+1)/fps).toFixed(1)+'s / '+fps+'fps';
 if(document.activeElement!==ui.speed)ui.speed.value=s.speed||1;if(document.activeElement!==ui.lens)ui.lens.value=gamepadMode==='active'?Math.round(gamepadLens):s.lens||35;ui.speedValue.textContent=Number(s.speed||1).toFixed(1);ui.lensValue.textContent=(gamepadMode==='active'?Math.round(gamepadLens):s.lens||35)+' mm';
 ui.badge.classList.toggle('on',status==='recording');ui.badge.hidden=status!=='recording';ui.record.textContent=status==='recording'?'停止录制':'开始录制';ui.record.setAttribute('aria-label',ui.record.textContent);ui.play.textContent=s.playing?'Ⅱ':'▶';ui.play.title='排练（不录镜头）';
 if(status==='recording')ui.recordStatus.textContent=`录制中 · 已记 ${take?.frames||s.recorded_frames||0} 帧`;
 else if(take?.frames>=2)ui.recordStatus.textContent=`已录制 ${Number(take.duration||((take.end-take.start+1)/fps)).toFixed(1)} 秒 · ${take.frames} 帧`;
 else ui.recordStatus.textContent='未录制 · 先开始录制，再运镜';
 if(s.cameras&&JSON.stringify(s.cameras)!==JSON.stringify(lastCameras)){let sel=$('#cameraSelect');if(sel){sel.innerHTML='';s.cameras.forEach(n=>{let o=document.createElement('option');o.value=o.textContent=n;sel.append(o)})}lastCameras=[...s.cameras]};const sel=$('#cameraSelect');if(sel&&s.camera&&sel.value!==s.camera)sel.value=s.camera;
 const exporting=s.export?.status==='running',canExport=!!(take&&take.frames>=2);ui.download.hidden=!(s.export?.status==='done'&&s.export.url);if(!ui.download.hidden){ui.download.href=s.export.url;ui.download.download=(decodeURIComponent(s.export.url.split('?')[0].split('/').pop())||'camera-take.mp4')};ui.export.textContent=exporting?'导出中…':'导出 MP4';ui.export.disabled=exporting||!!s.recording||!canExport;ui.export.title=canExport?'导出已录制镜头':'先开始录制，再运镜';ui.record.disabled=exporting;ui.stop.disabled=exporting&&!s.recording;ui.timeline.disabled=!!s.recording;$('#cameraSelect').disabled=!!s.recording;$('#resetBtn').disabled=!!s.recording;
 if(!sensorPaused&&!held)ui.sensorBtn.textContent=sensorOn?'◎ 关闭体感':'◎ 启用体感';if(s.export?.status==='error')limitedToast(`导出失败：${s.export.message||'未知错误'}`);if(s.error)limitedToast(s.error);if((sensorPaused||held)&&status!=='recording'){ui.sensor.textContent='取景已暂停 · 点击继续取景';ui.sensor.setAttribute('title','点击继续取景');ui.sensorBtn.textContent=resumePending?'正在恢复…':'继续取景'}if(status==='recording'){ui.sensor.textContent=sensorOn?'体感已启用 · 转动手机取景':'触控运镜 · 镜头正在录制';ui.sensor.removeAttribute('title');ui.sensorBtn.textContent=sensorOn?'◎ 关闭体感':'◎ 启用体感'}
 if(gamepadMode==='active'){const l=profileLabels();ui.sensor.textContent=`${profileConfig().label} 手柄运镜 · 右杆抬头低头 · ${l.lower} / ${l.raise} 升降`+(s.recording?' · 录制中':'');ui.sensor.removeAttribute('title')}
}
async function poll(){try{let r=await api('/api/state'),s=await r.json();if(!r.ok||s.ok===false)throw Error(s.error||`HTTP ${r.status}`);if(phoneEntry&&!s.recording&&s.export?.status!=='running'){const project=s.projects?.active||'default';if(phoneProject!==project){phoneProject=project;enqueue({type:'camera',name:'Camera_Phone'},()=>{sensorPaused=false;clearControls()})}}render(s);window.previsOverview?.render(s);window.previsProjects?.render(s);window.previsWelcome?.render(s);window.previsPhone?.render(s);window.previsLicensing?.render(s);window.previsScenes?.render(s)}catch(e){stopGamepad('连接中断 · 手柄已暂停');ui.conn.textContent='连接失败';ui.dot.style.background='#666';toast('无法连接 Blender：'+(e.message||'网络错误'))}setTimeout(poll,600)}
async function frame(){if(busy)return;busy=true;try{let r=await api('/frame.png?n='+Date.now());if(!r.ok)throw Error(`HTTP ${r.status}`);let u=URL.createObjectURL(await r.blob()),old=oldURL;ui.image.onload=()=>{if(old)URL.revokeObjectURL(old);oldURL=u};ui.image.onerror=()=>{URL.revokeObjectURL(u);ui.wait.hidden=false};ui.image.src=u;ui.wait.hidden=true}catch(e){ui.wait.hidden=false;ui.wait.textContent='等待 Blender 画面…';if(e.message!=='HTTP 503')toast('取景画面失败：'+e.message)}finally{busy=false}}setInterval(frame,150);
const qm=(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]],qi=q=>[-q[0],-q[1],-q[2],q[3]],qn=q=>{let n=Math.hypot(...q);return n>.0001?q.map(x=>x/n):[0,0,0,1]},qaxis=(x,y,z,a)=>[x*Math.sin(a/2),y*Math.sin(a/2),z*Math.sin(a/2),Math.cos(a/2)];
function quat(e){let d=Math.PI/180,a=(e.alpha||0)*d,b=(e.beta||0)*d,g=(e.gamma||0)*d,ang=((screen.orientation&&screen.orientation.angle)||window.orientation||0)*d;return qn(qm(qm(qm(qm(qaxis(0,1,0,a),qaxis(1,0,0,b)),qaxis(0,0,1,-g)),qaxis(1,0,0,-Math.PI/2)),qaxis(0,0,1,-ang)))}
function orientation(e){if(!sensorOn||sensorPaused)return;const q=quat(e);if(!base){base=q;gyroReady=false;enqueue({type:'sensor_base'},()=>{if(sensorOn&&!sensorPaused){gyroReady=true;ui.sensor.textContent='体感已启用 · 转动手机取景'}})}if(gyroReady)gyroLatest=qn(qm(q,qi(base)))}
async function toggleSensor(){stopGamepad('已切换到触控 / 体感');if(sensorOn){sensorOn=false;gyroReady=false;gyroLatest=null;base=null;window.removeEventListener('deviceorientation',orientation);ui.sensor.textContent='体感已关闭';$('#sensorBtn').textContent='◎ 启用体感';return}if(!window.isSecureContext){ui.sensor.innerHTML=state.http_url?`体感需 HTTPS · <a href="${state.http_url.replace('/?token=','/local-camera.mobileconfig?token=')}" target="_blank" rel="noopener">下载本地证书</a> · <a href="${state.https_url}" target="_blank" rel="noopener">已信任，打开 HTTPS</a>`:'体感需 HTTPS，当前可触控';toast('体感需 HTTPS；HTTP 仍可触控');return}try{if(typeof DeviceOrientationEvent==='undefined')throw Error();if(typeof DeviceOrientationEvent.requestPermission==='function'&&await DeviceOrientationEvent.requestPermission()!=='granted')throw Error();sensorOn=true;$('#sensorBtn').textContent='◎ 关闭体感';base=null;gyroReady=false;gyroLatest=null;window.addEventListener('deviceorientation',orientation);ui.sensor.textContent='体感已启用 · 等待校准'}catch(_){toast('设备不支持或未获得体感权限')}}
function recalibrate(){if(!sensorOn)return;base=null;gyroReady=false;gyroLatest=null;ui.sensor.textContent='正在校准…'}
function resetBaseAfterCommand(){base=null;gyroReady=false;gyroLatest=null;if(sensorOn)ui.sensor.textContent='机位已变更 · 等待重新校准'}
function pauseSensor(message='取景已暂停 · 点击继续取景'){stopGamepad(message);cancelQueued('sensor_base');const hadManual=move.some(Boolean)||pendingLook.some(Boolean)||inputDirty;clearControls();if(!sensorPaused&&hadManual)enqueue({type:'input',move:[0,0,0],look:[0,0]});sensorPaused=true;gyroReady=false;gyroLatest=null;base=null;ui.sensor.textContent=message}
function resumeSensor(){if(resumePending||!sensorPaused)return;resumePending=true;cancelQueued('sensor_base');enqueue({type:'resume_live'},()=>{resumePending=false;sensorPaused=false;clearControls();if(sensorOn){base=null;gyroReady=false;gyroLatest=null;ui.sensor.textContent='体感已启用 · 等待校准'}else ui.sensor.textContent='取景已恢复 · 可触控运镜'});ui.sensor.textContent='正在恢复取景…'}
$('#sensorBtn').onclick=()=>{stopGamepad('已切换到触控 / 体感');if(sensorPaused){resumeSensor();return}toggleSensor()};$('#calibrateBtn').onclick=recalibrate;$('#resetBtn').onclick=()=>{pauseSensor();enqueue({type:'reset_camera'},resetBaseAfterCommand)};ui.play.onclick=()=>{pauseSensor('排练模式 · 体感已暂停');enqueue({type:state.playing?'pause':'play'})};ui.stop.onclick=()=>{pauseSensor('已停止 · 点击启用体感继续取景');enqueue({type:'stop'})};ui.record.onclick=()=>{if(state.recording||recordIntent==='record'){pauseSensor('正在停止录制…');recordIntent='stop';enqueue({type:'stop'},()=>{recordIntent=null})}else{if(gamepadMode!=='off'&&state.license?.plan!=='pro'&&!state.demo){window.previsLicensing?.open('手柄录制需要 Pro；其他方式可免费录制，导出带 Preview 水印。');return}clearControls();resumeSensor();recordIntent='record';enqueue({type:'record'},()=>{recordIntent=null})}};ui.export.onclick=()=>{const take=state.recorded_take;if(!take||take.frames<2){toast('先开始录制，再运镜');return}enqueue({type:'export',camera:take.name,...(window.previsExportOptions?.()||{})});};ui.timeline.oninput=e=>{pauseSensor('回放模式 · 体感已暂停');enqueue({type:'seek',frame:+e.target.value})};$('#cameraSelect')?.addEventListener('change',e=>{pauseSensor('机位已变更 · 点击继续取景');enqueue({type:'camera',name:e.target.value},resetBaseAfterCommand)});[['speed','speedValue','speed'],['lens','lensValue','lens']].forEach(([i,o,k])=>$('#'+i).oninput=e=>{if(k==='lens')gamepadLens=+e.target.value;let v=+e.target.value;$('#'+o).textContent=k==='lens'?v+' mm':v.toFixed(1);enqueue({type:'settings',[k]:v})});
function publishMove(){latestInput=[...move];inputDirty=true;if(!move.some(Boolean))zeroPending=true}function release(){inputGeneration++;manualPitch=0;move=[0,0,0];pendingLook=[0,0];latestInput=[0,0,0];inputDirty=true;zeroPending=true}function clearControls(){keys={};drag=null;joy=null;release();const j=$('#joystick span');if(j)j.style.transform=''}function recompute(){move[0]=(keys.d?1:0)-(keys.a?1:0);move[1]=(keys.w?1:0)-(keys.s?1:0);move[2]=(keys.e?1:0)-(keys.q?1:0);publishMove()}
window.onkeydown=e=>{if(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName))return;let k=e.key.toLowerCase();if('wasdqe'.includes(k)){stopGamepad('键盘已接管 · 手柄已暂停');e.preventDefault();keys[k]=1;recompute()}};window.onkeyup=e=>{let k=e.key.toLowerCase();if(keys[k]){keys[k]=0;recompute()}else if('wasdqe'.includes(k))publishMove()};
const lp=$('#lookPad');lp.onpointerdown=e=>{stopGamepad('触控已接管 · 手柄已暂停');drag={x:e.clientX,y:e.clientY,id:e.pointerId};lp.setPointerCapture(e.pointerId)};lp.onpointermove=e=>{if(drag&&drag.id===e.pointerId){pendingLook[0]-=(e.clientX-drag.x)*.005;pendingLook[1]-=(e.clientY-drag.y)*.005;drag.x=e.clientX;drag.y=e.clientY}};['pointerup','pointercancel','lostpointercapture'].forEach(x=>lp.addEventListener(x,e=>{if(!drag||e.pointerId===undefined||e.pointerId===drag.id){drag=null;publishMove()}}));
const js=$('#joystick');js.onpointerdown=e=>{stopGamepad('触控已接管 · 手柄已暂停');joy={x:e.clientX,y:e.clientY,id:e.pointerId};js.setPointerCapture(e.pointerId)};js.onpointermove=e=>{if(joy&&joy.id===e.pointerId){move[0]=Math.max(-1,Math.min(1,(e.clientX-joy.x)/38));move[1]=Math.max(-1,Math.min(1,-(e.clientY-joy.y)/38));latestInput=[...move];inputDirty=true;js.querySelector('span').style.transform=`translate(${move[0]*25}px,${-move[1]*25}px)`}};['pointerup','pointercancel','lostpointercapture'].forEach(x=>js.addEventListener(x,e=>{if(joy&&(!e.pointerId||e.pointerId===joy.id)){joy=null;move[0]=move[1]=0;publishMove();js.querySelector('span').style.transform=''}}));document.querySelectorAll('[data-move]').forEach(b=>{b.onpointerdown=e=>{stopGamepad('高度按钮已接管 · 手柄已暂停');b.setPointerCapture(e.pointerId);move[2]=b.dataset.move==='up'?1:-1;publishMove()};['pointerup','pointercancel','lostpointercapture'].forEach(x=>b.addEventListener(x,()=>{move[2]=0;publishMove()}))});
window.addEventListener('blur',()=>{stopGamepad('页面已失焦 · 点击手柄运镜重新启用');clearControls()});document.addEventListener('visibilitychange',()=>{if(document.hidden){stopGamepad('页面已切到后台 · 手柄已暂停');clearControls();if(sensorOn){gyroReady=false;gyroLatest=null}}else if(sensorOn)recalibrate()});window.addEventListener('pagehide',()=>{stopGamepad('页面已关闭 · 手柄已暂停');clearControls();fetch('/api/control?token='+encodeURIComponent(token),{method:'POST',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'input',move:[0,0,0],look:[0,0]})}).catch(()=>{})});window.addEventListener('orientationchange',()=>{if(sensorOn)recalibrate();toast('屏幕旋转，请重新校准')});poll();
// One browser input loop; all writes use the existing serialized control channel.
function gamepadNotice(message){
 gamepadReason=message;const key=gamepadMode+':'+message;if(gamepadNotice.last===key)return;gamepadNotice.last=key;const button=$('#gamepadBtn'),label=$('#gamepadButtonLabel');
 if(button){button.setAttribute('aria-pressed',String(gamepadMode!=='off'));button.title=message;}
 if(label)label.textContent=gamepadMode==='active'?`${profileConfig().label} · 开`:gamepadMode==='waiting'?`等待${profileConfig().label}…`:['starting','centering'].includes(gamepadMode)?'准备机位…':'手柄运镜';
 const info=$('#gamepadStatus');if(info)info.textContent=message;
 document.body?.classList.toggle('gamepad-enabled',gamepadMode==='active');
}
function stopGamepad(reason){
 if(gamepadMode==='off')return;
 const preparing=['starting','centering'].includes(gamepadMode);
 gamepadMode='off';gamepadIndex=null;gamepadEpoch++;gamepadInput?.reset();
 if(preparing)cancelQueued('resume_live');
 clearControls();enqueue({type:'input',move:[0,0,0],look:[0,0]});enqueue({type:'controller_end'});gamepadNotice(reason);ui.sensor.textContent=reason;
}
function pads(){try{return Array.from(navigator.getGamepads?.()||[]).filter(p=>p?.connected)}catch(e){stopGamepad('浏览器无法读取手柄：'+e.message);return []}}
function beginGamepad(pad){
 if(!pad||gamepadMode!=='waiting')return;
 if(pad.mapping!=='standard'){stopGamepad('此手柄未提供标准映射 · 请检查系统手柄设置');toast(gamepadReason);return;}
 gamepadIndex=pad.index;gamepadInput.setProfile?.(activeGamepadProfile);gamepadInput.reset();gamepadLens=Number(state.lens)||35;clearControls();
 enqueue({type:'controller_begin'});
 if(state.recording){gamepadMode='active';sensorPaused=false;gamepadNotice('请松开摇杆与按键，再开始运镜');return;}
 gamepadMode='starting';gamepadStarted=Date.now();const epoch=gamepadEpoch;gamepadNotice('正在恢复可运镜机位…');
 enqueue({type:'resume_live'},()=>{if(epoch!==gamepadEpoch||gamepadMode!=='starting')return;gamepadMode='centering';gamepadNotice('等待 Blender 就绪…');});
}
function toggleGamepad(){
 if(gamepadMode!=='off'){stopGamepad('手柄已暂停 · 可触控或再次启用');return;}
 if(!gamepadInput||typeof navigator.getGamepads!=='function'){toast('当前浏览器不能读取手柄，请使用 Safari 或 Windows Edge');return;}
 if(!state.connected||state.export?.status==='running'){toast('请先连接 Blender，并等待导出结束');return;}
 if(state.recording&&state.license?.plan!=='pro'&&!state.demo){window.previsLicensing?.open('请先停止录制。手柄可以免费预览，手柄录制需要 Pro。');return}
 sensorOn=false;gyroReady=false;gyroLatest=null;base=null;window.removeEventListener('deviceorientation',orientation);cancelQueued('sensor_base');clearControls();
 gamepadMode='waiting';gamepadEpoch++;gamepadNotice(`蓝牙连接 ${profileConfig().label} 手柄后，按任意键识别`);
 beginGamepad(pads().find(p=>p.mapping==='standard')||pads()[0]);
}
$('#gamepadBtn')?.addEventListener('click',toggleGamepad);
$('#gamepadProfile')?.addEventListener('change',e=>setGamepadProfile(e.target.value));
updateGamepadProfileUI();
window.addEventListener('gamepaddisconnected',e=>{if(e.gamepad.index===gamepadIndex)stopGamepad('手柄已断开 · 重连并回中后重新启用')});
document.querySelectorAll('[data-look]').forEach(b=>{
 b.onpointerdown=e=>{stopGamepad('俯仰按钮已接管 · 手柄已暂停');if(sensorOn){sensorOn=false;gyroReady=false;gyroLatest=null;base=null;window.removeEventListener('deviceorientation',orientation);cancelQueued('sensor_base');ui.sensor.textContent='触控俯仰 · 体感已暂停';ui.sensorBtn.textContent='◎ 启用体感'}b.setPointerCapture(e.pointerId);manualPitch=b.dataset.look==='up'?1:-1;};
 ['pointerup','pointercancel','lostpointercapture'].forEach(type=>b.addEventListener(type,()=>{manualPitch=0;publishMove();}));
});
let lastControlFrame=null;
function controlFrame(time){
 const dt=lastControlFrame===null?0:Math.min(.05,Math.max(0,(time-lastControlFrame)/1000));lastControlFrame=time;
 const foreground=!document.hidden&&document.hasFocus?.()!==false&&!document.querySelector('dialog[open]');
 if(gamepadMode!=='off'&&!foreground)stopGamepad('页面或面板已切换 · 手柄已暂停');
 if(gamepadMode==='waiting')beginGamepad(pads().find(p=>p.mapping==='standard')||pads()[0]);
 if(['starting','centering'].includes(gamepadMode)&&Date.now()-gamepadStarted>6000)stopGamepad('机位就绪超时 · 请重新启用');
 if(gamepadMode==='active'){
  const pad=pads().find(p=>p.index===gamepadIndex),sample=gamepadInput.sample(pad,dt);
  if(sample.reason==='disconnected'||sample.reason==='unmapped')stopGamepad('手柄已断开或映射改变 · 请重新启用');
  else{
   if(sample.reason==='center')gamepadNotice('请松开摇杆与按键，再开始运镜');
   else {const l=profileLabels();gamepadNotice(`手柄运镜已启用 · 右杆抬头低头 · ${l.lower} / ${l.raise} 升降`)}
   if(!sensorPaused){
    if(sample.move.some((v,i)=>Math.abs(v-move[i])>.0001)){move=[...sample.move];publishMove();}
    // Do not accumulate stale rotations while a request is delayed.
    if(!commandBusy&&!continuousBusy){pendingLook[0]+=sample.look[0];pendingLook[1]+=sample.look[1];}
    if(sample.lens){gamepadLens=Math.max(18,Math.min(100,gamepadLens+sample.lens));if(Date.now()-lastPadLensSent>=120&&!commandBusy&&!continuousBusy){lastPadLensSent=Date.now();enqueue({type:'settings',lens:Math.round(gamepadLens)});}}
   }
  }
 }
 if(manualPitch&&foreground&&!sensorPaused&&!commandBusy&&!continuousBusy)pendingLook[1]+=manualPitch*.9*dt;
 if(typeof requestAnimationFrame==='function')requestAnimationFrame(controlFrame);
}
if(typeof requestAnimationFrame==='function')requestAnimationFrame(controlFrame);
window.addEventListener('previs-overview-editing',e=>{sensorPaused=!!e.detail;if(sensorPaused){stopGamepad('正在编辑空间 · 手柄已暂停');cancelQueued('sensor_base');clearControls();gyroReady=false;gyroLatest=null;base=null}});window.previsControl=enqueue;window.previsState=()=>state;
})();
