(()=>{
 const $=id=>document.getElementById(id),dialog=$('licenseDialog');let state={},busy=false,lastDemoURL=null;
 let confirmResult=null;window.previsConfirm=message=>new Promise(resolve=>{if(confirmResult)confirmResult(false);confirmResult=resolve;$('confirmMessage').textContent=message;$('confirmDialog').showModal()});
 const answer=value=>{const resolve=confirmResult;confirmResult=null;$('confirmDialog').close();resolve?.(value)};
 $('confirmCancel').onclick=()=>answer(false);$('confirmAccept').onclick=()=>answer(true);$('confirmDialog').addEventListener('cancel',()=>answer(false));
 const token=new URLSearchParams(location.search).get('token')||'';
 const feedback=message=>{$('licenseFeedback').textContent=message||''};
 function render(s){
  state=s;const license=s.license||{},pro=license.plan==='pro';
  $('licenseBtn').textContent=s.demo?'官方体验场景':pro?'Pro · 已激活':'Lite · 预览版';
  $('licenseSummary').textContent=pro?'Pro 已激活 · 本商业大版本离线使用':'Lite 免费预览 · 每项目 3 个已保存场次 · 导出带水印';
  const remote=!(location.hostname==='localhost'||location.hostname==='127.0.0.1'||location.hostname==='[::1]');
  const secure=!remote||location.protocol==='https:';
  $('licenseToken').disabled=busy||!secure;$('licenseActivate').disabled=busy||!secure||s.recording||s.export?.status==='running';
  $('licenseRemove').disabled=busy||!secure||!pro||s.recording||s.export?.status==='running';
  $('licenseTransportNote').textContent=secure?'授权保存在运行 Blender 的电脑上，手机与电脑共用。':'请在电脑端激活，或使用已信任的 HTTPS 手机页面。普通 HTTP 不传输授权码。';
  $('controllerDemo').textContent=s.demo?'退出体验，返回正式项目':'官方场景 · 手柄试录';
  $('controllerDemo').disabled=busy||!!s.recording||s.export?.status==='running';
  if(s.demo_url&&s.demo_url!==lastDemoURL){lastDemoURL=s.demo_url;feedback('体验场景已打开，正式项目保持不变。');const link=document.createElement('a');link.href=s.demo_url;link.textContent='打开官方手柄体验 ↗';link.target='_blank';link.rel='noopener';$('licenseFeedback').append(' ',link)}
 }
 function open(message=''){feedback(message);window.dispatchEvent(new CustomEvent('previs-overview-editing',{detail:true}));if(!dialog.open)dialog.showModal();render(state)}
 async function action(body){
  if(busy)return;busy=true;render(state);feedback('正在本机验证…');
  try{const r=await fetch('/api/license?token='+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'授权操作失败');if(d.license)state={...state,license:d.license};if(d.result?.ok===false||d.result?.valid===false&&body.action==='activate')throw Error(d.result.error||d.result.message||d.license?.message||'授权码未通过验证');feedback(body.action==='remove'?'已移除本机授权，恢复 Lite。原授权码仍可再次使用。':state.license?.plan==='pro'?'Pro 激活成功。':d.result?.message||d.license?.message||'未激活，请检查授权码。')}
  catch(e){feedback(e.message||'无法连接本机授权服务')}
  finally{$('licenseToken').value='';busy=false;render(state)}
 }
 $('licenseBtn').onclick=()=>open();$('licenseClose').onclick=()=>dialog.close();dialog.addEventListener('close',()=>{$('licenseToken').value='';window.dispatchEvent(new CustomEvent('previs-overview-editing',{detail:false}))});
 $('licenseForm').onsubmit=e=>{e.preventDefault();if(!$('licenseToken').value.trim()){feedback('请先输入授权码');return}action({action:'activate',token:$('licenseToken').value})};
 $('licenseRemove').onclick=async()=>{if(await window.previsConfirm('移除这台电脑的 Pro 授权？项目和录制不会删除。'))action({action:'remove'})};
 $('licensePurchase').onclick=()=>{const url=state.license?.purchase_url;if(!url){feedback('Pro 商品尚未配置。你可以先使用 Lite；开售后在这里购买。');return}try{const u=new URL(url);if(u.protocol!=='https:'||!['afdian.com','afdian.net'].includes(u.hostname))throw Error();window.open(u.href,'_blank','noopener,noreferrer')}catch(_){feedback('购买链接配置无效，请联系作者。')}};
 $('controllerDemo').onclick=()=>{feedback(state.demo?'正在关闭体验场景…':'正在打开独立体验场景…');window.previsControl({type:state.demo?'demo_exit':'demo_start'});if(state.demo&&state.demo_return_url)setTimeout(()=>location.assign(state.demo_return_url),1200)};
 window.previsLicensing={render,open};
})();
