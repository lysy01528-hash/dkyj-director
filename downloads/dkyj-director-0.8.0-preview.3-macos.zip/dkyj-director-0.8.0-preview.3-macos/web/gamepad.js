/* Standard Gamepad mapping, shared by desktop and iPhone Safari. No network I/O. */
((root) => {
  const finite = (value, min = -1, max = 1) => Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : 0;
  function stick(x, y) {
    x = finite(x); y = finite(y);
    const length = Math.hypot(x, y), deadzone = .16;
    if (length <= deadzone) return [0, 0];
    const strength = ((Math.min(1, length) - deadzone) / (1 - deadzone)) ** 1.5;
    return [x / length * strength, y / length * strength];
  }
  const zero = reason => ({move: [0, 0, 0], look: [0, 0], lens: 0, reason});
  const profiles = Object.freeze({
    xbox: Object.freeze({key: 'xbox', label: 'Xbox', lower: 6, raise: 7, zoomOut: 4, zoomIn: 5}),
    ps5: Object.freeze({key: 'ps5', label: 'PS5', lower: 6, raise: 7, zoomOut: 4, zoomIn: 5}),
  });
  const getProfile = value => profiles[value === 'ps5' ? 'ps5' : 'xbox'];
  class Input {
    constructor(profile = 'xbox') { this.profile = getProfile(profile); this.reset(); }
    setProfile(profile) { this.profile = getProfile(profile); this.reset(); }
    reset() { this.ready = false; this.identity = null; }
    sample(pad, dt) {
      if (!pad?.connected) { this.reset(); return zero('disconnected'); }
      if (pad.mapping !== 'standard' || pad.axes.length < 4 || pad.buttons.length < 8) { this.reset(); return zero('unmapped'); }
      const identity = `${pad.index}:${pad.id}`;
      if (identity !== this.identity) { this.reset(); this.identity = identity; }
      const left = stick(pad.axes[0], pad.axes[1]), right = stick(pad.axes[2], pad.axes[3]);
      const values = Array.from(pad.buttons, b => finite(b.value, 0, 1));
      if (!this.ready) {
        if (![...left, ...right].some(Boolean) && values.every(v => v < .05) && !pad.buttons.some(b => b.pressed)) this.ready = true;
        return zero('center');
      }
      const seconds = finite(dt, 0, .05), trigger = v => v <= .05 ? 0 : (v - .05) / .95;
      const p = this.profile;
      return {
        move: [left[0], -left[1] || 0, trigger(values[p.raise]) - trigger(values[p.lower])],
        look: [-right[0] * 1.2 * seconds || 0, -right[1] * 1.2 * seconds || 0],
        lens: (values[p.zoomIn] - values[p.zoomOut]) * 18 * seconds,
        reason: 'active',
      };
    }
  }
  const api = {Input, stick, finite, profiles, getProfile};
  root.DKYJGamepad = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window === 'undefined' ? globalThis : window);
