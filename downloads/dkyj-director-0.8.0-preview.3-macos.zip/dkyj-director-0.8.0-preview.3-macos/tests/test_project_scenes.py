"""Filesystem-only checks for the project scene catalog (no Blender process)."""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'addon'))
from project_scenes import FREE_SAVED_SCENE_LIMIT, SceneCatalog


with tempfile.TemporaryDirectory() as root:
    folder = Path(root) / 'project'
    folder.mkdir()
    (folder / 'scene.blend').write_bytes(b'legacy')
    project = {'id': 'p', 'name': 'Demo', 'description': 'legacy',
               'created_at': '2026-01-01T00:00:00+00:00',
               'updated_at': '2026-01-01T00:00:00+00:00'}
    catalog = SceneCatalog(folder)
    catalog.migrate_legacy(project)
    assert project['active_scene'] == 'default'
    assert catalog.path(project).name == 'scene.blend'
    assert catalog.saved_count(project) == 1
    for index in range(FREE_SAVED_SCENE_LIMIT - 1):
        item = catalog.new_item(project, f'Scene {index}')
        target = catalog.path(project, item['id'])
        target.parent.mkdir(parents=True)
        target.write_bytes(b'saved')
    assert catalog.saved_count(project) == FREE_SAVED_SCENE_LIMIT
    assert not catalog.quota_allows(project)
    assert catalog.quota_allows(project, is_pro=True)
print('PROJECT_SCENE_CATALOG_TESTS_OK legacy migration, active path, quota, pro override')
