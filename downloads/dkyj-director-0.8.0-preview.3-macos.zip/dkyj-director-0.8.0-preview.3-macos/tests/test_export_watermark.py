import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from export_policy import ExportPolicy
from export_watermark import mark_image, mark_structured


class ExportWatermarkTests(unittest.TestCase):
    def test_preview_json_is_marked_and_pro_is_unchanged(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "zones.json"
            path.write_text(json.dumps({"zones": []}), encoding="utf-8")
            mark_structured(path, ExportPolicy())
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["export_plan"], "preview")
            original = path.read_text(encoding="utf-8")
            mark_structured(path, ExportPolicy("pro"))
            self.assertEqual(path.read_text(encoding="utf-8"), original)

    def test_preview_png_is_replaced_in_place(self):
        from PIL import Image

        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "board.png"
            Image.new("RGB", (320, 180), "white").save(path)
            mark_image(path, ExportPolicy())
            with Image.open(path) as image:
                self.assertEqual(image.size, (320, 180))
            self.assertFalse(Path(str(path) + ".preview.tmp").exists())


if __name__ == "__main__":
    unittest.main()
