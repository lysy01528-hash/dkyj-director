"""Client-side scene payload and confirmation checks without a running Blender."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import director_client


original_state, original_request, original_sleep = director_client.state, director_client.request, director_client.time.sleep
try:
    snapshots = [
        {'project_event': 17, 'scenes': {'active': 'one', 'saved': []}},
        {'project_event': 17, 'error': 'previous command failed'},
        {'project_event': 18, 'scenes': {'active': 'two', 'saved': [{'id': 'two'}]}},
    ]
    calls = []
    director_client.state = lambda: snapshots.pop(0)
    director_client.request = lambda path, body=None: calls.append((path, body)) or {'ok': True, 'accepted': True}
    director_client.time.sleep = lambda _: None
    result = director_client.scene_create('第二场', '出弯反超', discard_draft=True)
    assert result['scenes']['active'] == 'two'
    assert calls[0][1] == {'type': 'scene_create', 'name': '第二场', 'description': '出弯反超', 'discard_draft': True}
    assert 'is_pro' not in calls[0][1]

    snapshots = [{'project_event': 18}, {'project_event': 19, 'scenes': {'active': 'two'}, 'error': '当前场次尚未保存'}]
    director_client.state = lambda: snapshots.pop(0)
    director_client.request = lambda path, body=None: {'ok': True, 'accepted': True}
    try:
        director_client.scene_switch('one')
        raise AssertionError('backend error was swallowed')
    except RuntimeError as error:
        assert '尚未保存' in str(error)
finally:
    director_client.state, director_client.request, director_client.time.sleep = original_state, original_request, original_sleep

print('AGENT_SCENE_TESTS_OK payload/no-is-pro/event-wait/error-path')
