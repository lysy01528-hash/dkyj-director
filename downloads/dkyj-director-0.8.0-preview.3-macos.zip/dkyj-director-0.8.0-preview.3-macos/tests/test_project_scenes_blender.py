"""Real bpy acceptance checks for saved-scene limits and recovery semantics."""
import json
import shutil
import sys
import tempfile
from pathlib import Path

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'addon'))
from project_scenes import SceneDraftError, SceneLimitError
from scene_projects import ProjectStore


def new_scene(name):
    scene = bpy.data.scenes.new(name)
    scene.camera = bpy.data.objects.new(name + '_Camera', bpy.data.cameras.new(name + '_CameraData'))
    bpy.context.scene.collection.objects.link(scene.camera)
    return scene


with tempfile.TemporaryDirectory(prefix='dkyj-scenes-') as root:
    store = ProjectStore(root)
    base = bpy.context.scene
    base.camera = bpy.data.objects.get('Camera')
    if base.camera is None:
        base.camera = bpy.data.objects.new('Camera', bpy.data.cameras.new('CameraData'))
        base.collection.objects.link(base.camera)
    pid = store.attach(base)
    assert store.catalog['version'] == 2
    assert (Path(root) / 'projects' / 'index.pre-scenes.json').is_file()
    first = store.entry(pid)
    assert store.scene_public(pid)['saved_count'] == 1
    second = store.create_scene(base, '第二场次')
    third = store.create_scene(base, '第三场次')
    assert store.scene_public(pid)['saved_count'] == 3

    removed_draft = store.create_scene(base, '删除测试草稿')
    bpy.data.scenes.remove(removed_draft)
    # A removed Blender Scene wrapper must not break the state endpoint, and a
    # saved scene must still be recoverable afterwards.
    assert store.scene_public(pid)['draft'] is None
    assert store.load(pid)['dkyj_scene_id'] == store.entry(pid)['active_scene']

    draft = store.create_scene(base, '第四场次')
    assert draft.get('dkyj_scene_draft') is True
    other_draft = store.create_scene(base, '另一个草稿')
    try:
        store.create_scene(draft, '草稿中再创建')
        raise AssertionError('other cached draft was silently replaced')
    except SceneDraftError:
        pass
    draft = store.create_scene(draft, '草稿中再创建', discard_draft=True)
    try:
        store.save_current_scene(draft)
        raise AssertionError('free fourth scene was saved')
    except SceneLimitError:
        pass
    assert store.scene_public(pid)['draft']['id'] == draft['dkyj_scene_id']
    try:
        store.switch_scene('default', current_scene=draft)
        raise AssertionError('draft switch silently discarded')
    except SceneDraftError:
        pass
    other_pid, _ = store.create(base, '另一项目')
    store.catalog['active'] = other_pid
    assert store.scene_public(pid)['draft']['id'] == draft['dkyj_scene_id']
    store.catalog['active'] = pid

    # Delete a non-active saved scene, then explicitly save the draft.
    active = store.entry(pid)['active_scene']
    non_active = next(item['id'] for item in store.entry(pid)['scenes'] if item['id'] != active)
    store.delete_scene(non_active, pid)
    state = store.save_current_scene(draft)
    assert state['saved_count'] == 3
    assert not draft.get('dkyj_scene_draft')

    # Pro may keep four saved scenes in the same package.
    pro_pid, _ = store.create(base, 'Pro 项目')
    store.catalog['active'] = pro_pid
    for index in range(3):
        store.create_scene(base, f'Pro 场次 {index + 2}', is_pro=True)
    assert store.scene_public(pro_pid)['saved_count'] == 4
    # The backend-facing writer also accepts the explicit Pro entitlement.
    store.write_scene(base, pro_pid, scene_id='pro-extra', is_pro=True)
    assert store.scene_public(pro_pid)['saved_count'] == 5
    pro_project = store.entry(pro_pid)
    pro_project['active_scene'] = pro_project['scenes'][1]['id']
    store.persist()

    # Restart resolves the persisted active scene, not the first scene.
    restarted = ProjectStore(root)
    assert restarted.scene_public(pro_pid)['saved_count'] == 5
    restored = restarted.load(pro_pid)
    assert restored['dkyj_scene_id'] == pro_project['scenes'][1]['id']
    active_before_delete = restarted.entry(pro_pid)['active_scene']
    restarted.delete_scene(active_before_delete, pro_pid)
    fallback = restarted.entry(pro_pid)['active_scene']
    assert fallback and fallback != active_before_delete
    assert restarted.load(pro_pid)['dkyj_scene_id'] == fallback
    assert len(restarted.entry(pro_pid)['scenes']) == 4

    # Existing over-limit projects are preserved rather than silently trimmed.
    assert len(restarted.entry(pid)['scenes']) == 3
    assert restarted.scene_public(pid)['saved_count'] == 3

    # A hand-authored multi-Scene .blend is rejected explicitly; it is never
    # silently reduced to its first Blender Scene.
    external = restarted.add('外部多场景')
    external_catalog = restarted._scene_catalog(external)
    external_item = external_catalog.new_item(external, '外部多场景', '', 'default')
    external_path = external_catalog.path(external, external_item['id'])
    external_path.parent.mkdir(parents=True, exist_ok=True)
    external_scene = bpy.data.scenes.new('ExternalSecond')
    external_source = Path(root) / 'external-multiscene.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(external_source), copy=True)
    shutil.copy2(external_source, external_path)
    try:
        restarted.load(external['id'])
        raise AssertionError('multi-scene blend was silently truncated')
    except ValueError as error:
        assert '多个 Blender Scene' in str(error)

print('PROJECT_SCENE_BLENDER_TESTS_OK free3 draft/manual-delete/pro4/restart/fallback/no-trim')
