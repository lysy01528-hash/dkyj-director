import json
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from licensing.license_manager import LicenseManager
from licensing.license_token import decode_and_verify, encode_token
import secrets


def payload(license_id=None):
    # Standalone fixture: client source packages intentionally omit issuer tools.
    return {"schema": 1, "product": "dkyj-director", "license_id": license_id or secrets.token_urlsafe(16),
            "plan": "pro", "major_version": 1, "issued_at": "2026-09-12T00:00:00Z",
            "nonce": secrets.token_urlsafe(16)}
from licensing.runtime import RuntimeLicense


def keypair():
    private = Ed25519PrivateKey.generate()
    public = private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return private, public


def test_preview_shape_and_three_scene_quota(tmp_path):
    _, public = keypair()
    manager = LicenseManager(tmp_path / "license.json", public)
    status = manager.get_status()
    assert status["plan"] == "preview" and status["valid"] is False
    assert manager.has_feature("scene.create", {"scene_count": 2})
    assert not manager.has_feature("scene.create", {"scene_count": 3})
    assert manager.has_feature("camera.record")
    assert manager.has_feature("controller.project")
    assert not manager.has_feature("controller.record")
    assert not manager.has_feature("controller.persist")
    assert not manager.has_feature("camera.persist_take", {"input_source": "gamepad"})
    assert manager.has_feature("camera.persist_take", {"input_source": "keyboard"})


def test_activate_masks_id_and_preserves_no_full_token(tmp_path):
    private, public = keypair()
    token = encode_token(private, payload("ABCDEFGHIJKLMNOPQRSTUV"))
    manager = LicenseManager(tmp_path / "license.json", public)
    status = manager.activate(token)
    assert status["is_pro"] is True
    assert token not in json.dumps(status)
    assert status["license_id"] == "…QRSTUV"
    assert manager.has_feature("controller.project")


def test_rejects_tamper_duplicate_and_noncanonical(tmp_path):
    private, public = keypair()
    token = encode_token(private, payload("ABCDEFGHIJKLMNOPQRSTUV"))
    with pytest.raises(Exception):
        decode_and_verify(token[:-1] + ("A" if token[-1] != "A" else "B"), public)
    body = '{"schema":1,"schema":1,"product":"dkyj-director","license_id":"ABCDEFGHIJKLMNOPQRSTUV","plan":"pro","major_version":1,"issued_at":"2026-01-01T00:00:00Z","nonce":"ABCDEFGHIJKLMNOPQRSTUV"}'.encode()
    import base64
    duplicate = "DKYJ1." + base64.urlsafe_b64encode(body).decode().rstrip("=") + ".AAAA"
    with pytest.raises(Exception):
        decode_and_verify(duplicate, public)


def test_invalid_activation_keeps_existing_license(tmp_path):
    private, public = keypair()
    path = tmp_path / "license.json"
    manager = LicenseManager(path, public)
    good = encode_token(private, payload("ABCDEFGHIJKLMNOPQRSTUV"))
    manager.activate(good)
    with pytest.raises(Exception):
        manager.activate("DKYJ1.invalid.invalid")
    assert manager.is_pro()


def test_unlicensed_install_stays_preview(tmp_path):
    manager = LicenseManager(tmp_path / "license.json")
    assert manager.get_plan() == "preview"
    assert not manager.is_pro()


def test_unknown_public_key_rejects_without_replacing_existing(tmp_path):
    private, public = keypair()
    other_private, other_public = keypair()
    path = tmp_path / "license.json"
    manager = LicenseManager(path, public)
    original = encode_token(private, payload("ABCDEFGHIJKLMNOPQRSTUV"))
    manager.activate(original)
    foreign = encode_token(other_private, payload("ZYXWVUTSRQPONMLKJIHGFE"))
    with pytest.raises(Exception):
        LicenseManager(path, public).activate(foreign)
    assert manager.is_pro()
    assert path.read_text(encoding="utf-8").find(original) >= 0


def test_storage_failure_does_not_replace_valid_file(tmp_path):
    private, public = keypair()
    path = tmp_path / "license.json"
    manager = LicenseManager(path, public)
    original = encode_token(private, payload("ABCDEFGHIJKLMNOPQRSTUV"))
    manager.activate(original)
    # Pointing storage at a directory forces the write path to fail safely.
    manager.storage.path = tmp_path
    with pytest.raises(Exception):
        manager.activate(encode_token(private, payload("1234567890ABCDEFGHIJKL")))
    assert original in (tmp_path / "license.json").read_text(encoding="utf-8")


def test_runtime_bridge_failure_is_safe_and_cached(monkeypatch, tmp_path):
    runtime = RuntimeLicense(tmp_path)
    responses = {"status": {"ok": True, "status": {"plan": "pro", "is_pro": True}},
                 "activate": {"ok": False, "error": "bad", "status": {"plan": "preview", "is_pro": False}},
                 "remove": {"ok": False, "error": "bad", "status": {"plan": "preview", "is_pro": False}}}
    monkeypatch.setattr(runtime, "_call", lambda command, token=None: responses[command])
    assert runtime.status()["plan"] == "pro"
    assert runtime.activate("bad")["ok"] is False
    assert runtime.is_pro() is True
    assert runtime.remove_local_license()["ok"] is False
    assert runtime.is_pro() is True


def test_runtime_bridge_live_preview(tmp_path):
    runtime = RuntimeLicense(Path(__file__).resolve().parents[1])
    status = runtime.refresh()
    assert status["plan"] == "preview"
    assert runtime.is_pro() is False
