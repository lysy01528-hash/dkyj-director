import importlib.util
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from export_policy import ExportPolicy, PREVIEW_MARK, resolve_policy


class _Runtime:
    def __init__(self, status):
        self._status = status

    def status(self):
        return self._status


class ExportPolicyTests(unittest.TestCase):
    def test_unknown_is_watermarked_preview(self):
        policy = resolve_policy(runtime=_Runtime({}))
        self.assertTrue(policy.is_preview)
        self.assertEqual(policy.watermark_text, PREVIEW_MARK)

    def test_pro_requires_runtime_status(self):
        self.assertTrue(resolve_policy(runtime=_Runtime({"plan": "pro", "is_pro": True})).is_pro)
        self.assertTrue(resolve_policy(runtime=_Runtime({"plan": "pro", "is_pro": False})).is_preview)

    def test_cli_like_output_name_cannot_select_pro(self):
        self.assertTrue(resolve_policy(runtime=_Runtime({"plan": "preview"})).is_preview)

    def test_metadata_has_no_preview_watermark_for_pro(self):
        self.assertIsNone(resolve_policy(runtime=_Runtime({"plan": "pro", "is_pro": True})).metadata()["watermark"])


if __name__ == "__main__":
    unittest.main()
