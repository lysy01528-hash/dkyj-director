"""Commercial gate regression tests.

Run inside Blender, for example:
  blender --background --factory-startup --python-exit-code 1 \
    --python tests/test_commercial_controls.py
"""
import collections
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "addon"))
from controller_session import ControllerSession

spec = importlib.util.spec_from_file_location("commercial_webcam", ROOT / "addon/whitebox_webcam.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class FakeLicense:
    def __init__(self, pro=False):
        self.pro = pro

    def is_pro(self):
        return self.pro

    def status(self):
        return {"plan": "pro" if self.pro else "preview", "is_pro": self.pro}

    def refresh(self):
        return self.status()

    def activate(self, token):
        raise ValueError("授权码无效")

    def remove_local_license(self):
        return self.status()


class ControllerSessionTests(unittest.TestCase):
    def test_manual_client_and_ttl(self):
        session = ControllerSession()
        session.accept({"type": "controller_begin", "client_id": "phone"}, recording=False, pro=False, demo=False)
        self.assertEqual(session.public()["client_id"], "phone")
        session.accept({"type": "controller_heartbeat", "client_id": "phone"}, recording=False, pro=False, demo=False)
        self.assertFalse(session.expire(session.last_seen + 2.9))
        self.assertTrue(session.expire(session.last_seen + 3.1))
        self.assertIsNone(session.owner)

    def test_multiple_clients_and_disconnect(self):
        session = ControllerSession()
        session.accept({"type": "controller_begin", "client_id": "a"}, recording=False, pro=False, demo=False)
        with self.assertRaisesRegex(ValueError, "另一台设备"):
            session.accept({"type": "controller_begin", "client_id": "b"}, recording=False, pro=False, demo=False)
        session.accept({"type": "controller_end", "client_id": "a"}, recording=False, pro=False, demo=False)
        self.assertIsNone(session.owner)


class CommercialControlTests(unittest.TestCase):
    def setUp(self):
        # Reuse the existing disposable Blender scene fixture without inheriting
        # its unrelated lifecycle test methods.
        fixture_spec = importlib.util.spec_from_file_location("deleted_fixture", ROOT / "tests/test_deleted_data.py")
        fixture_module = importlib.util.module_from_spec(fixture_spec)
        fixture_spec.loader.exec_module(fixture_module)
        self.fixture = fixture_module.DeletedDataTests()
        self.fixture.setUp()
        self.s = self.fixture.s
        self.scene = self.fixture.scene
        self.s._license = FakeLicense(False)

    def tearDown(self):
        self.fixture.tearDown()

    def process(self, event):
        return self.s.process(event)

    def test_free_manual_recording_is_allowed(self):
        self.process({"type": "record"})
        self.assertTrue(self.s.recording)
        self.process({"type": "stop"})
        self.assertFalse(self.s.recording)
        self.assertTrue(self.s.recorded_take_info())

    def test_free_controller_preview_is_allowed(self):
        self.process({"type": "controller_begin", "client_id": "desktop"})
        self.process({"type": "input", "client_id": "desktop", "input_source": "gamepad",
                      "move": [0, 0, 0], "look": [0, 0]})
        self.assertEqual(self.s.controller().owner, "desktop")

    def test_free_gamepad_record_is_rejected_before_camera_clone(self):
        self.process({"type": "controller_begin", "client_id": "desktop"})
        before = self.scene.camera
        camera_names = {obj.name for obj in self.scene.objects}
        with self.assertRaisesRegex(ValueError, "手柄录制需要 Pro"):
            self.process({"type": "record", "client_id": "desktop"})
        self.assertIs(self.scene.camera, before)
        self.assertEqual(camera_names, {obj.name for obj in self.scene.objects})
        self.assertFalse(self.s.recording)

    def test_manual_recording_blocks_controller_begin(self):
        self.process({"type": "record"})
        with self.assertRaisesRegex(ValueError, "手柄录制需要 Pro"):
            self.process({"type": "controller_begin", "client_id": "desktop"})
        self.assertTrue(self.s.recording)

    def test_pro_gamepad_record_and_keys_are_allowed(self):
        self.s._license = FakeLicense(True)
        self.process({"type": "controller_begin", "client_id": "desktop"})
        self.process({"type": "record", "client_id": "desktop"})
        self.scene.frame_set(2)
        self.process({"type": "input", "client_id": "desktop", "input_source": "gamepad",
                      "move": [0.3, 0, 0], "look": [0.1, 0]})
        self.process({"type": "stop", "client_id": "desktop"})
        take = self.s.recorded_take_info()
        self.assertIsNotNone(take)
        self.assertGreaterEqual(take["frames"], 2)

    def test_demo_can_record_but_cannot_touch_project(self):
        self.s.demo = True
        self.process({"type": "controller_begin", "client_id": "demo"})
        self.process({"type": "record", "client_id": "demo"})
        self.process({"type": "stop", "client_id": "demo"})
        self.assertTrue(self.s.recorded_take_info())
        for event in ({"type": "project_create"}, {"type": "scene_create"}, {"type": "brief_create"}, {"type": "export"}):
            with self.assertRaisesRegex(ValueError, "官方体验场景"):
                self.process(event)
        with self.assertRaisesRegex(ValueError, "体验场景不导出"):
            self.s.begin_export()

    def test_license_route_does_not_echo_token_on_error(self):
        self.s._license = FakeLicense(False)
        token = "SECRET_FULL_TEST_TOKEN"
        body = json.dumps({"action": "activate", "token": token}).encode()
        url = self.fixture.url.replace("/api/state", "/api/license")
        request = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as raised:
            self.fixture.opener.open(request, timeout=3)
        response = raised.exception.read().decode("utf-8")
        self.assertNotIn(token, response)
        self.assertIn("授权码无效", response)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    print("COMMERCIAL_CONTROL_TESTS_OK", result.testsRun)

