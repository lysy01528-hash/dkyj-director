"""Small atomic, per-OS-user license store."""
import json
import os
import sys
import tempfile
from pathlib import Path

from .errors import LicenseStorageError


def default_path() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData/Local"))
    else:
        base = Path.home() / "Library/Application Support"
    return base / "DKYJ Director" / "license.json"


class LicenseStorage:
    def __init__(self, path=None):
        self.path = Path(path) if path else default_path()

    def read(self):
        if not self.path.exists():
            return None
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or data.get("schema") != 1 or not isinstance(data.get("token"), str):
                raise ValueError
            return data["token"]
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise LicenseStorageError("本机授权文件不可读") from exc

    def write(self, token):
        parent = self.path.parent
        try:
            parent.mkdir(parents=True, exist_ok=True)
            if os.name != "nt":
                os.chmod(parent, 0o700)
            fd, name = tempfile.mkstemp(prefix=".license.", dir=str(parent), text=True)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump({"schema": 1, "token": token}, handle, ensure_ascii=True, separators=(",", ":"))
                    handle.flush()
                    os.fsync(handle.fileno())
                if os.name != "nt":
                    os.chmod(name, 0o600)
                os.replace(name, self.path)
            finally:
                try:
                    os.unlink(name)
                except FileNotFoundError:
                    pass
        except OSError as exc:
            raise LicenseStorageError("本机授权文件无法保存") from exc

    def remove(self):
        try:
            self.path.unlink(missing_ok=True)
        except OSError as exc:
            raise LicenseStorageError("本机授权文件无法移除") from exc

