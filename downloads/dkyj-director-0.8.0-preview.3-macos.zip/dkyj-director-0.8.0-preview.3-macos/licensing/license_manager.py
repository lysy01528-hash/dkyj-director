import base64

from . import config
from .entitlement import allows
from .errors import LicenseError
from .license_token import decode_and_verify
from .storage import LicenseStorage


class LicenseManager:
    def __init__(self, storage_path=None, public_key=None):
        self.storage = LicenseStorage(storage_path)
        self.public_key = self._public_key(public_key)
        self._status = None

    @staticmethod
    def _public_key(value):
        if value is not None:
            return bytes(value)
        if not config.PRODUCTION_PUBLIC_KEY_B64:
            return None
        try:
            return base64.urlsafe_b64decode(config.PRODUCTION_PUBLIC_KEY_B64 + "=" * (-len(config.PRODUCTION_PUBLIC_KEY_B64) % 4))
        except Exception:
            return None

    def _public(self, plan, license_id=None, issued_at=None, error=None):
        is_pro = plan == "pro"
        masked = None if not license_id else "…" + license_id[-6:]
        return {"plan": plan, "label": "Pro" if is_pro else "Lite / Preview", "is_pro": is_pro,
                "valid": is_pro, "major_version": config.COMMERCIAL_MAJOR_VERSION,
                "license_id": masked, "issued_at": issued_at, "purchase_url": config.PURCHASE_URL,
                "creator_url": config.CREATOR_URL, "error": error,
                "features": {"scene.create": True, "controller.demo": True,
                              "controller.project": True, "controller.record": is_pro,
                              "controller.persist": is_pro, "camera.record": True,
                              "camera.persist_take": True, "export.clean": is_pro}}

    def _preview(self, error=None):
        return self._public("preview", error=error)

    def refresh(self):
        try:
            token = self.storage.read()
            if not token or self.public_key is None:
                self._status = self._preview()
            else:
                payload = decode_and_verify(token, self.public_key)
                self._status = self._public("pro", payload["license_id"], payload["issued_at"])
        except LicenseError as exc:
            self._status = self._preview(str(exc))
        return dict(self._status)

    def get_status(self):
        return dict(self._status if self._status is not None else self.refresh())

    def get_plan(self):
        return self.get_status()["plan"]

    def is_pro(self):
        return bool(self.get_status()["is_pro"])

    def has_feature(self, name, context=None):
        return allows(self.get_plan(), name, context)

    def activate(self, token):
        if self.public_key is None:
            raise LicenseError("Pro 尚未开售，当前预览包暂不能激活")
        payload = decode_and_verify(token, self.public_key)
        self.storage.write(token.strip())
        self._status = self._public("pro", payload["license_id"], payload["issued_at"])
        return dict(self._status)

    def remove_local_license(self):
        self.storage.remove()
        self._status = self._preview()
        return dict(self._status)
