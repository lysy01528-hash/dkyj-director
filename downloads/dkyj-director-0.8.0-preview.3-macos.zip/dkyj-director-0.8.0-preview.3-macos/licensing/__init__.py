"""Offline entitlement verification for DKYJ Director.

The package deliberately has no network, account, or device binding code.
"""

from .license_manager import LicenseManager
from .runtime import RuntimeLicense

__all__ = ["LicenseManager", "RuntimeLicense"]
