"""Blender-safe facade; all cryptography runs in the external project venv."""
import json
import subprocess
import sys
import threading
from pathlib import Path


class RuntimeLicense:
    def __init__(self, root, timeout=4.0):
        self.root = Path(root).resolve()
        self.timeout = timeout
        self._cache = None
        self._lock = threading.RLock()

    @staticmethod
    def _normalize_status(status):
        if not isinstance(status, dict):
            return {"plan": "preview", "is_pro": False}
        normalized = dict(status)
        plan = normalized.get("plan")
        is_pro = normalized.get("is_pro")
        # The bridge is local input, but never allow inconsistent fields to
        # make export and backend checks choose different entitlements.
        if plan not in ("preview", "pro") or type(is_pro) is not bool or is_pro != (plan == "pro"):
            return {"plan": "preview", "is_pro": False, "error": "授权状态无效"}
        return normalized

    def _call(self, command, token=None):
        payload = {"command": command}
        if token is not None:
            payload["token"] = token
        python = self.root / ".venv" / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
        bridge = self.root / "scripts" / "license_bridge.py"
        try:
            proc = subprocess.run([str(python), str(bridge)], input=json.dumps(payload), text=True,
                                  capture_output=True, timeout=self.timeout, cwd=str(self.root))
            data = json.loads(proc.stdout) if proc.stdout.strip() else {}
            if not isinstance(data, dict):
                raise ValueError
            return data
        except Exception:
            return {"ok": False, "error": "授权验证暂不可用", "status": {"plan": "preview", "is_pro": False}}

    def status(self):
        with self._lock:
            if self._cache is None:
                self._cache = self._normalize_status(self._call("status").get("status"))
            return dict(self._cache)

    def refresh(self):
        with self._lock:
            self._cache = self._normalize_status(self._call("status").get("status"))
        return self.status()

    def activate(self, token):
        result = self._call("activate", token)
        if result.get("ok"):
            with self._lock:
                self._cache = self._normalize_status(result.get("status"))
        return result

    def remove_local_license(self):
        result = self._call("remove")
        if result.get("ok"):
            with self._lock:
                self._cache = self._normalize_status(result.get("status"))
        return result

    def is_pro(self):
        return bool(self.status().get("is_pro"))

    def has_feature(self, name, context=None):
        # Status is cached so this method is safe inside a per-frame callback.
        from .entitlement import allows
        return allows(self.status().get("plan", "preview"), name, context)
