"""Strict DKYJ1 token encoding and Ed25519 verification."""
import base64
import json
import re
from datetime import datetime
from typing import Any, Mapping

from . import config
from .errors import LicenseFormatError, LicenseSignatureError

try:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
except ImportError:  # pragma: no cover - bridge reports this as unavailable
    InvalidSignature = Exception
    Ed25519PrivateKey = Ed25519PublicKey = None

# 128 bits encoded with URL-safe base64 require at least 22 characters.
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{22,128}$")
_KEYS = {"schema", "product", "license_id", "plan", "major_version", "issued_at", "nonce"}


def _b64decode(value: str) -> bytes:
    if not isinstance(value, str) or not value or not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise LicenseFormatError("授权码编码无效")
    raw = value.encode("ascii")
    decoded = base64.urlsafe_b64decode(raw + b"=" * (-len(raw) % 4))
    if base64.urlsafe_b64encode(decoded).rstrip(b"=").decode("ascii") != value:
        raise LicenseFormatError("授权码编码不规范")
    return decoded


def _b64encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise LicenseFormatError("授权载荷包含重复字段")
        result[key] = value
    return result


def canonical_payload(payload: Mapping[str, Any]) -> bytes:
    if not isinstance(payload, Mapping) or set(payload) != _KEYS:
        raise LicenseFormatError("授权载荷字段不完整或包含未知字段")
    if type(payload.get("schema")) is not int or payload.get("schema") != 1:
        raise LicenseFormatError("授权协议版本不支持")
    if payload.get("product") != config.PRODUCT_ID or payload.get("plan") != "pro":
        raise LicenseFormatError("授权产品或计划不匹配")
    if isinstance(payload.get("major_version"), bool) or not isinstance(payload.get("major_version"), int) or payload["major_version"] != config.COMMERCIAL_MAJOR_VERSION:
        raise LicenseFormatError("授权大版本不匹配")
    for field in ("license_id", "nonce"):
        if not isinstance(payload.get(field), str) or not _ID_RE.fullmatch(payload[field]):
            raise LicenseFormatError("授权标识格式无效")
    issued = payload.get("issued_at")
    if not isinstance(issued, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", issued):
        raise LicenseFormatError("授权时间格式无效")
    try:
        datetime.strptime(issued, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as exc:
        raise LicenseFormatError("授权时间无效") from exc
    encoded = json.dumps(dict(payload), ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return encoded.encode("ascii")


def encode_token(private_key, payload: Mapping[str, Any]) -> str:
    body = canonical_payload(payload)
    signature = private_key.sign(body)
    if len(signature) != 64:
        raise LicenseSignatureError("签名长度无效")
    return f"{config.TOKEN_PREFIX}.{_b64encode(body)}.{_b64encode(signature)}"


def decode_and_verify(token: str, public_key: bytes):
    if not isinstance(token, str):
        raise LicenseFormatError("授权码格式无效")
    token = token.strip()
    if len(token) > config.MAX_TOKEN_LENGTH or token.count(".") != 2:
        raise LicenseFormatError("授权码长度或段数无效")
    prefix, encoded_payload, encoded_signature = token.split(".")
    if prefix != config.TOKEN_PREFIX:
        raise LicenseFormatError("授权码版本不支持")
    body = _b64decode(encoded_payload)
    signature = _b64decode(encoded_signature)
    if len(body) > config.MAX_PAYLOAD_LENGTH or len(signature) != 64:
        raise LicenseFormatError("授权码长度无效")
    try:
        parsed = json.loads(body.decode("utf-8"), object_pairs_hook=_reject_duplicate_keys, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (UnicodeDecodeError, ValueError, json.JSONDecodeError) as exc:
        raise LicenseFormatError("授权载荷不是有效 JSON") from exc
    if not isinstance(parsed, dict) or canonical_payload(parsed) != body:
        raise LicenseFormatError("授权载荷不是规范格式")
    if not isinstance(public_key, bytes) or len(public_key) != 32:
        raise LicenseSignatureError("生产公钥不可用")
    try:
        Ed25519PublicKey.from_public_bytes(public_key).verify(signature, body)
    except (InvalidSignature, ValueError) as exc:
        raise LicenseSignatureError("授权签名无效") from exc
    return parsed
