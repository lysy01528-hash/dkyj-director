"""Commercial entitlement constants shared by the verifier and UI layers."""

PRODUCT_ID = "dkyj-director"
LICENSE_SCHEMA = 1
COMMERCIAL_MAJOR_VERSION = 1
FREE_SCENE_LIMIT = 3
PURCHASE_URL = ""
CREATOR_URL = "https://afdian.com/a/DKYJ666"

# Production v1 public key approved by the author on 2026-09-12.
# A released build may replace this constant at build time; runtime never reads
# an arbitrary public key from an environment variable.
PRODUCTION_PUBLIC_KEY_B64 = 'Ub2Gj5mFLIvXA2Zn2qyUJzIahE-xtRO_xo_TIUD5-2A'
TOKEN_PREFIX = "DKYJ1"
MAX_TOKEN_LENGTH = 4096
MAX_PAYLOAD_LENGTH = 2048

