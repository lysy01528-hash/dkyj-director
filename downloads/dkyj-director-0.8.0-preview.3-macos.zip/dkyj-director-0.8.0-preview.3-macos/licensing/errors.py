class LicenseError(Exception):
    """Safe, user-facing base error; details must not contain credentials."""


class LicenseFormatError(LicenseError):
    pass


class LicenseSignatureError(LicenseError):
    pass


class LicenseStorageError(LicenseError):
    pass

