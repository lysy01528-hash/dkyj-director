"""Feature policy. Unknown capabilities are intentionally denied."""
from . import config

FEATURES = {
    "scene.create": "pro_or_quota",
    "controller.demo": "free",
    # Free users can move a formal-project camera live; only saving a take or
    # recording that gamepad session is commercial.
    "controller.project": "free",
    "controller.record": "pro",
    "controller.persist": "pro",
    "camera.record": "free_watermarked",
    "camera.persist_take": "pro_for_controller",
    "export.clean": "pro",
}


def allows(plan, feature, context=None):
    rule = FEATURES.get(feature)
    if rule is None:
        return False
    if rule in ("free", "free_watermarked"):
        return True
    if rule == "pro":
        return plan == "pro"
    if rule == "pro_or_quota":
        if plan == "pro":
            return True
        count = (context or {}).get("scene_count")
        return isinstance(count, int) and not isinstance(count, bool) and 0 <= count < config.FREE_SCENE_LIMIT
    if rule == "pro_for_controller":
        return plan == "pro" or (context or {}).get("input_source") != "gamepad"
    return False
