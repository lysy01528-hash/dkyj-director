"""Final Preview marking for downloadable exports.

Video marking uses Blender's VSE so the existing Workbench render/color path is
left untouched.  The source is always rendered to a temporary sibling before
being replaced, which prevents a failed watermark pass from registering a
clean source as the final download.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping

from export_policy import ExportPolicy, PREVIEW_MARK


def _temp_sibling(path: Path, suffix: str = ".preview.tmp") -> Path:
    return path.with_name(path.name + suffix)


def mark_structured(path: str | Path, policy: ExportPolicy) -> Path:
    """Add non-video Preview metadata to JSON/TXT reference files."""
    path = Path(path)
    if policy.is_pro or not path.exists():
        return path
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {"data": data}
        data.update(policy.metadata())
        tmp = _temp_sibling(path)
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    else:
        text = path.read_text(encoding="utf-8")
        marker = f"\n导出计划：Preview（{PREVIEW_MARK}）\n"
        if marker.strip() not in text:
            tmp = _temp_sibling(path)
            tmp.write_text(text.rstrip() + marker, encoding="utf-8")
            os.replace(tmp, path)
    return path


def _mark_image_pillow(path: Path, label: str) -> Path:
    """Pillow implementation, executed in the project venv when needed."""
    from PIL import Image, ImageDraw, ImageFont

    image = Image.open(path).convert("RGBA")
    draw = ImageDraw.Draw(image, "RGBA")
    size = max(14, round(min(image.size) * 0.024))
    try:
        from platform_paths import chinese_font

        font = ImageFont.truetype(chinese_font(), size)
    except Exception:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0, 0), label, font=font)
    x = 18
    y = image.height - (bbox[3] - bbox[1]) - 18
    draw.rounded_rectangle((x - 8, y - 5, x + bbox[2] + 8, y + bbox[3] + 5), radius=5, fill=(0, 0, 0, 155))
    draw.text((x, y), label, font=font, fill=(255, 255, 255, 235))
    tmp = _temp_sibling(path)
    fmt = "JPEG" if path.suffix.lower() in (".jpg", ".jpeg") else "PNG"
    image.convert("RGB").save(tmp, format=fmt)
    os.replace(tmp, path)
    return path


def mark_image(path: str | Path, policy: ExportPolicy, text: str | None = None) -> Path:
    """Burn a mark, delegating to the project venv from Blender's Python."""
    path = Path(path)
    if policy.is_pro or not path.exists():
        return path
    label = text or PREVIEW_MARK
    try:
        return _mark_image_pillow(path, label)
    except ModuleNotFoundError as exc:
        if exc.name != "PIL":
            raise
        from platform_paths import project_python

        root = Path(__file__).resolve().parents[1]
        subprocess.run([str(project_python(root)), str(Path(__file__)), "--image", str(path), "--text", label], check=True)
        return path


def watermark_video(
    source: str | Path,
    policy: ExportPolicy,
    *,
    output: str | Path | None = None,
    resolution: tuple[int, int] = (1280, 720),
    frame_start: int = 1,
    frame_end: int | None = None,
    fps: float = 24.0,
) -> Path:
    """Burn the Preview label with a disposable Blender VSE scene."""
    source = Path(source)
    target = Path(output) if output is not None else source
    if policy.is_pro:
        if source != target:
            shutil.copy2(source, target)
        return target
    if not source.exists():
        raise FileNotFoundError(source)
    try:
        import bpy  # type: ignore
    except ImportError as exc:  # pragma: no cover - only Blender can render video
        raise RuntimeError("Blender is required for video watermarking") from exc

    # Give Blender a real movie extension.  Some Blender builds append a frame
    # range when the temporary path has an unknown suffix; we handle that
    # generated sibling below as well.
    temp_output = target.with_name(target.stem + ".preview-tmp.mp4")
    source_scene = bpy.context.window.scene if bpy.context.window else None
    scene = bpy.data.scenes.new("DKYJ_Preview_Watermark")
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x, scene.render.resolution_y = resolution
    scene.render.resolution_percentage = 100
    rate = Fraction(str(fps)).limit_denominator(1000)
    scene.render.fps = rate.numerator
    scene.render.fps_base = rate.denominator
    scene.frame_start = frame_start
    seq = scene.sequence_editor_create()
    movie = seq.strips.new_movie("DKYJ Preview Source", str(source), channel=1, frame_start=frame_start)
    duration = movie.frame_final_duration
    scene.frame_end = frame_end if frame_end is not None else frame_start + duration - 1
    # Blender 5.2 uses (name, type, channel, frame_start, length); older
    # releases accepted keyword frame_end, so keep the call version-neutral by
    # setting the final range after construction.
    text = seq.strips.new_effect("DKYJ Preview Mark", "TEXT", 2, frame_start, length=duration)
    text.frame_final_start = frame_start
    text.frame_final_duration = duration
    text.text = policy.watermark_text
    text.font_size = max(22, round(min(resolution) * 0.038))
    text.color = (1.0, 1.0, 1.0, 0.88)
    text.location = (0.025, 0.04)
    if hasattr(text, "alignment_x"):
        text.alignment_x = "LEFT"
    elif hasattr(text, "align_x"):
        text.align_x = "LEFT"
    text.use_shadow = True
    text.shadow_color = (0.0, 0.0, 0.0, 0.72)
    if hasattr(scene.render.image_settings, "media_type"):
        scene.render.image_settings.media_type = "VIDEO"
    else:
        scene.render.image_settings.file_format = "FFMPEG"
    scene.render.ffmpeg.format = "MPEG4"
    scene.render.ffmpeg.codec = "H264"
    scene.render.ffmpeg.audio_codec = "NONE"
    if source_scene is not None:
        # Keep the source render's color management for a pixel-preserving pass.
        for attr in ("view_transform", "look", "exposure", "gamma", "use_curve_mapping"):
            if hasattr(source_scene.view_settings, attr) and hasattr(scene.view_settings, attr):
                try:
                    setattr(scene.view_settings, attr, getattr(source_scene.view_settings, attr))
                except Exception:
                    pass
    elif hasattr(scene.view_settings, "view_transform"):
        # A movie strip already contains display-referred pixels.  Standard
        # avoids applying Blender's default AgX transform a second time when
        # this helper is invoked from a background process without a window.
        scene.view_settings.view_transform = "Standard"
    scene.render.filepath = str(temp_output)
    old = bpy.context.window.scene if bpy.context.window else None
    try:
        if bpy.context.window:
            bpy.context.window.scene = scene
        bpy.ops.render.render(animation=True)
        generated = temp_output
        if not generated.exists():
            candidates = sorted(target.parent.glob(temp_output.name + "*"))
            if candidates:
                generated = candidates[0]
        if not generated.exists():
            raise RuntimeError("Preview watermark render produced no output")
        os.replace(generated, target)
    finally:
        if bpy.context.window and old:
            bpy.context.window.scene = old
        bpy.data.scenes.remove(scene)
        temp_output.unlink(missing_ok=True)
        for candidate in target.parent.glob(temp_output.name + "*"):
            candidate.unlink(missing_ok=True)
    return target


def finalize_video(path: str | Path, policy: ExportPolicy, **kwargs: Any) -> Path:
    """Finalize a newly rendered video without leaving a clean Preview file."""
    path = Path(path)
    if policy.is_pro:
        return watermark_video(path, policy, **kwargs)
    if not path.exists():
        raise FileNotFoundError(path)
    raw = path.with_name(path.stem + ".raw-preview.mp4")
    raw.unlink(missing_ok=True)
    os.replace(path, raw)
    try:
        return watermark_video(raw, policy, output=path, **kwargs)
    except Exception:
        # The clean intermediate is never a downloadable final artifact.
        path.unlink(missing_ok=True)
        raise
    finally:
        raw.unlink(missing_ok=True)


if __name__ == "__main__" and "--image" in sys.argv:
    idx = sys.argv.index("--image")
    label = sys.argv[sys.argv.index("--text") + 1] if "--text" in sys.argv else PREVIEW_MARK
    _mark_image_pillow(Path(sys.argv[idx + 1]), label)
