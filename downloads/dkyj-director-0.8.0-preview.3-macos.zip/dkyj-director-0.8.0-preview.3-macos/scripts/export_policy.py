"""Single source of truth for Preview/Pro export policy.

The command line is deliberately not an authority for the plan.  The host
license runtime is queried when a policy is created; a failed or unknown
lookup safely falls back to the watermarked Preview path.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


PREVIEW_PLAN = "preview"
PRO_PLAN = "pro"
PREVIEW_MARK = "DKYJ DIRECTOR · PREVIEW"


@dataclass(frozen=True)
class ExportPolicy:
    plan: str = PREVIEW_PLAN
    watermark_text: str = PREVIEW_MARK

    @property
    def is_pro(self) -> bool:
        return self.plan == PRO_PLAN

    @property
    def is_preview(self) -> bool:
        return not self.is_pro

    def metadata(self) -> dict[str, Any]:
        return {"export_plan": self.plan, "watermark": None if self.is_pro else self.watermark_text}


def _runtime_status(root: Path | str | None = None) -> Mapping[str, Any]:
    """Read the licensing runtime without importing Blender or trusting CLI input."""
    try:
        import sys
        if root:
            root_path = str(Path(root).resolve())
            if root_path not in sys.path:
                sys.path.insert(0, root_path)
        from licensing.runtime import RuntimeLicense  # type: ignore

        runtime = RuntimeLicense(root=Path(root) if root else None)
        status = runtime.status()
        return status if isinstance(status, Mapping) else {}
    except Exception:
        # Preview is the safe, useful behavior when licensing is unavailable.
        return {}


def resolve_policy(root: Path | str | None = None, runtime: Any = None) -> ExportPolicy:
    """Resolve the host's current plan.

    ``runtime`` exists for unit tests and dependency injection only.  Production
    callers omit it, so the only authority is licensing.runtime.
    """
    try:
        status = runtime.status() if runtime is not None else _runtime_status(root)
        plan = str(status.get("plan", PREVIEW_PLAN)).lower()
        if plan == PRO_PLAN and (runtime is None or bool(status.get("is_pro", True))):
            return ExportPolicy(PRO_PLAN)
    except Exception:
        pass
    return ExportPolicy()


def policy_for_output(root: Path | str | None, output: str | Path, runtime: Any = None) -> ExportPolicy:
    """Resolve policy once for an export job; output names never select Pro."""
    return resolve_policy(root=root, runtime=runtime)
