"""Data-only CLI for local agents and project management."""
import argparse,json,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('action',choices=['list','save','switch','create','update','scene_create','scene_save','scene_switch','scene_delete','scene_discard']);p.add_argument('--id');p.add_argument('--name');p.add_argument('--description',default='');p.add_argument('--source',default='current');p.add_argument('--discard-draft',action='store_true');a=p.parse_args()
info=json.loads((root/'runtime/connection.json').read_text(encoding='utf-8'));base='http://127.0.0.1:8765';token=info['token'];opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def request(path,data=None):
    body=None if data is None else json.dumps(data).encode()
    req=urllib.request.Request(base+path+'?token='+token,data=body,headers={'Content-Type':'application/json'})
    return json.load(opener.open(req,timeout=15))
def revision(snapshot,body):
    kind=body.get('type','')
    if kind.startswith('project_'):return snapshot.get('project_event',0)
    if kind.startswith('scene_'):
        scenes=snapshot.get('scenes') or {}
        if 'project_event' in snapshot:return snapshot.get('project_event',0)
        if 'scene_event' in snapshot:return snapshot.get('scene_event',0)
        return scenes.get('revision',snapshot.get('scene_revision',0)) if isinstance(scenes,dict) else snapshot.get('scene_revision',0)
    return snapshot.get('briefs',{}).get('revision',0)

s=request('/api/state')
if a.action!='list':
    scene=a.action.startswith('scene_')
    kind=a.action if scene else 'project_'+a.action
    body={'type':kind}
    if scene:
        if a.action=='scene_create':body.update(name=a.name or '',description=a.description,discard_draft=bool(a.discard_draft))
        elif a.action=='scene_switch':body.update(id=a.id,discard_draft=bool(a.discard_draft))
        elif a.action=='scene_delete':body.update(id=a.id)
        elif a.action=='scene_discard':body.update(discard_draft=True)
    else:
        body.update(description=a.description,source=a.source)
        if a.id:body['id']=a.id
        if a.name:body['name']=a.name
    response=request('/api/control',body)
    if response.get('ok') is False:raise SystemExit(response.get('error'))
    event=revision(s,body)
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        time.sleep(.4);s=request('/api/state')
        if s.get('error'):raise SystemExit(s['error'])
        if revision(s,body)>event:break
    else:raise SystemExit('操作尚未确认，请检查网页状态；不要重复创建项目。')
print(json.dumps(s.get('scenes',{}) if a.action.startswith('scene_') else s.get('projects',{}),ensure_ascii=False,indent=2))
