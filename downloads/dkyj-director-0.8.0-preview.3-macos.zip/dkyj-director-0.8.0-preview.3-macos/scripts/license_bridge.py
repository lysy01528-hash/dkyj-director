"""stdin JSON -> stdout JSON bridge used by Blender's embedded Python."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main():
    try:
        raw = sys.stdin.read(16384)
        if len(raw) >= 16384:
            raise ValueError("request too large")
        request = json.loads(raw)
        if not isinstance(request, dict) or request.get("command") not in {"status", "activate", "remove"}:
            raise ValueError("unknown command")
        from licensing.license_manager import LicenseManager
        manager = LicenseManager()
        command = request["command"]
        if command == "status":
            out = {"ok": True, "status": manager.get_status()}
        elif command == "activate":
            token = request.get("token")
            if not isinstance(token, str) or len(token) > 4096:
                raise ValueError("token invalid")
            out = {"ok": True, "status": manager.activate(token)}
        else:
            out = {"ok": True, "status": manager.remove_local_license()}
    except Exception as exc:
        from licensing.errors import LicenseError
        message = str(exc)[:120] if isinstance(exc, LicenseError) else "授权操作失败，请检查输入或重新启动导演台"
        out = {"ok": False, "error": message, "status": {"plan": "preview", "is_pro": False}}
    # Emit exactly one JSON document. RuntimeLicense intentionally parses the
    # whole stream so diagnostic noise cannot be mistaken for a valid result.
    sys.stdout.write(json.dumps(out, ensure_ascii=True, separators=(",", ":")))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
