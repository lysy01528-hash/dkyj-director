"""Blender + production JS adapter regression, using synthetic controller samples.
Run with Blender --background --factory-startup --python-exit-code 1 --python this_file.
Requires Node on PATH. Uses an isolated scene; never opens a user project.
"""
import importlib.util
import json
from pathlib import Path
import subprocess
import time
import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'qa/gamepad-integration'
OUT.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('gamepad_fixture', ROOT / 'tests/test_deleted_data.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
trace = json.loads(subprocess.check_output(['node', '-e', r'''
const {Input}=require(process.argv[1]),m=new Input();
const p={connected:true,index:0,id:'SYNTHETIC',mapping:'standard',axes:[0,0,0,0],buttons:Array.from({length:17},()=>({value:0,pressed:false}))};
m.sample(p,0);let lens=35;const trace=[];
for(let f=1;f<=40;f++){
 p.axes=[.35,-.6,.25,-.25];p.buttons[7].value=f<=20?1:0;p.buttons[6].value=f>20&&f<=30?1:0;p.buttons[5].value=.8;
 const sample=m.sample(p,1/24);lens+=sample.lens;
 trace.push({frame:f,input:{type:'input',move:sample.move,look:sample.look},settings:{type:'settings',lens}});
}
console.log(JSON.stringify(trace));
''', str(ROOT / 'web/gamepad.js')], text=True))
test = fixture.DeletedDataTests()
test.setUp()
s = test.s
old_time = fixture.module.time.monotonic
result = {'ok': False, 'input_source': 'production web/gamepad.js, synthetic samples', 'blender': bpy.app.version_string, 'checks': []}
try:
    clock = [old_time()]
    fixture.module.time.monotonic = lambda: clock[0]
    s.prepare_overview = lambda: None
    s.scene.frame_end = 60
    s.scene.render.fps = 24
    camera = s.scene.camera
    camera.data.lens = 35
    # Visible references make an optional video export reviewable.
    for location in ((0, 0, 2), (-2, 2, 1), (2, 4, 1)):
        bpy.ops.mesh.primitive_cube_add(size=1.5, location=location)
    bpy.ops.mesh.primitive_plane_add(size=30, location=(0, 0, 0))
    camera.rotation_quaternion = Vector((0, 1, -.25)).to_track_quat('-Z', 'Y')
    s.window.view_layer.update()
    s.process({'type': 'record'})
    take = s.scene.camera
    s.last_tick = clock[0]
    positions = []
    for step in trace:
        clock[0] += 1/24 + 1e-6
        s.events.append(step['input']); s.events.append(step['settings'])
        s.tick()
        assert not s.error, s.error
        positions.append(list(take.location))
    s.process({'type': 'input', 'move': [0, 0, 0], 'look': [0, 0]})
    s.process({'type': 'stop'})
    info = s.recorded_take_info(take.name)
    assert info and info['has_motion'] and info['frames'] >= 40, info
    result['checks'].append('synthetic gamepad input recorded into a Take')
    assert positions[19][2] > positions[0][2] + .5
    assert positions[29][2] < positions[19][2] - .2
    result['checks'].append('RT ascends and LT descends in Blender world Z')
    samples = []
    for frame in (info['start'], info['end']):
        s.scene.frame_set(frame);s.window.view_layer.update()
        samples.append({'frame':frame,'position':list(take.matrix_world.translation),'quaternion':list(take.matrix_world.to_quaternion()),'lens':take.data.lens})
    assert samples[0]['position'] != samples[1]['position']
    assert samples[0]['quaternion'] != samples[1]['quaternion']
    assert samples[1]['lens'] > samples[0]['lens']
    result['checks'].append('playback preserves translation, tilt and focal length')
    s.refresh_state()
    assert abs(s.state['camera_height'] - take.matrix_world.translation.z) < 1e-5
    result['checks'].append('height display reads actual camera world Z')
    filepath = OUT / 'gamepad-recording.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(filepath), copy=True)
    result.update(ok=True, take=info, samples=samples, snapshot=str(filepath))
finally:
    fixture.module.time.monotonic = old_time
    test.tearDown()
(OUT / 'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('GAMEPAD_RECORDING', json.dumps(result,ensure_ascii=False), flush=True)
