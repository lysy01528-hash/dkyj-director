"""Internal demo bootstrap, executed by a separate Blender process."""
import importlib.util
import json
from pathlib import Path
import sys
import bpy

root = Path(__file__).resolve().parents[1]
args = sys.argv[sys.argv.index('--') + 1:]
folder, port = Path(args[0]), int(args[1])
folder.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root / 'addon'))
sys.path.insert(0, str(root / 'scripts'))
spec = importlib.util.spec_from_file_location('dkyj_official_demo', root / 'addon/whitebox_webcam.py')
webcam = importlib.util.module_from_spec(spec)
spec.loader.exec_module(webcam)
webcam.ROOT = root
webcam.DATA_ROOT = folder
webcam.RUNTIME = folder / 'runtime'
webcam.TAKES = folder / 'takes'
webcam.HTTP_PORT = port
webcam.DEMO_SESSION = True
return_file=folder / 'return.json'
webcam.DEMO_RETURN_URL=json.loads(return_file.read_text()).get('url') if return_file.exists() else None


def start():
    scene = bpy.context.scene
    scene['previs_title'] = '官方手柄体验 · 临时试录'
    for key in ('dkyj_project_id', 'dkyj_scene_id'):
        if key in scene:
            del scene[key]
    phone = scene.objects.get('Camera_Phone')
    if phone:
        scene.camera = phone
    scene.frame_set(scene.frame_start)
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next(r for r in area.regions if r.type == 'WINDOW')
                with bpy.context.temp_override(window=window, area=area, region=region):
                    webcam.SERVICE = webcam.Viewfinder(bpy.context)
                return None
    return .5

bpy.app.timers.register(start, first_interval=.5)
