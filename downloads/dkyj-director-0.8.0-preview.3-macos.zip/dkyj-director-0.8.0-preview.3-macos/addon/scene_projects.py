"""Local scene project catalog. Blender calls belong on the main thread only."""
import datetime
import json
import re
import shutil
import tempfile
import uuid
from pathlib import Path

from project_scenes import (FREE_SAVED_SCENE_LIMIT, SceneCatalog,
                            SceneDraftError, SceneLimitError, utc_now)

class ProjectStore:
    def __init__(self, root):
        self.root=Path(root);self.directory=self.root/'projects/library';self.directory.mkdir(parents=True,exist_ok=True)
        self.index=self.root/'projects/index.json';self.cache={}
        self.catalog=json.loads(self.index.read_text(encoding='utf-8')) if self.index.exists() else {'version':1,'active':None,'projects':[]}
        if not isinstance(self.catalog,dict) or not isinstance(self.catalog.get('projects'),list):raise ValueError('项目索引损坏，请从备份恢复')
        self.catalog.setdefault('active',None);self.catalog.setdefault('version',1);self.scene_catalogs={}
        for project in self.catalog['projects']:self._scene_catalog(project).migrate_legacy(project)

    def persist(self):
        # The first scene-catalog write upgrades the index. Keep one immutable
        # pre-migration copy so a user can roll back the metadata without
        # touching any Blender files.
        if self.catalog.get('version',1)<2 and self.index.exists():
            backup=self.index.with_name('index.pre-scenes.json')
            if not backup.exists():
                backup_tmp=backup.with_suffix('.json.tmp')
                backup_tmp.write_text(self.index.read_text(encoding='utf-8'),encoding='utf-8')
                backup_tmp.replace(backup)
            self.catalog['version']=2
        tmp=self.index.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(self.catalog,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(self.index)

    def _scene_catalog(self,project):
        catalog=self.scene_catalogs.get(project['id'])
        if catalog is None:
            catalog=SceneCatalog(self.directory/project['id']);self.scene_catalogs[project['id']]=catalog
        catalog.migrate_legacy(project);return catalog

    def _active_scene_id(self,project):
        self._scene_catalog(project);return project.get('active_scene') or (project.get('scenes') or [{}])[0].get('id')

    def entry(self, project_id):
        if not isinstance(project_id,str) or not re.fullmatch(r'[a-z0-9-]{1,64}',project_id):raise ValueError('无效项目编号')
        result=next((p for p in self.catalog['projects'] if p['id']==project_id),None)
        if result is None:raise ValueError('项目不存在，请刷新项目列表')
        return result

    def path(self, project_id, scene_id=None):
        project=self.entry(project_id);self._scene_catalog(project)
        folder=self.directory/project_id
        if not folder.resolve().is_relative_to(self.directory.resolve()):raise ValueError('项目路径超出目录')
        return self.scene_catalogs[project_id].path(project,scene_id)

    def public(self):
        items=[]
        for project in self.catalog['projects']:
            catalog=self._scene_catalog(project);items.append(dict(project,available=any(x.get('available') for x in catalog.items(project))))
        return {'active':self.catalog['active'],'items':items}

    def scene_public(self,project_id=None):
        project_id=project_id or self.catalog.get('active')
        if not project_id:return {'project':None,'active':None,'saved':[],'saved_count':0,'free_limit':FREE_SAVED_SCENE_LIMIT,'draft':None}
        project=self.entry(project_id);catalog=self._scene_catalog(project);active=self._active_scene_id(project)
        draft=None
        cached_drafts=[]
        # Blender can remove a draft Scene while its wrapper remains in cache.
        # Inspect liveness before touching custom properties; otherwise a
        # StructRNA ReferenceError can escape through the state endpoint.
        for key,value in list(self.cache.items()):
            if not isinstance(key,tuple) or key[0]!=project_id:continue
            try:
                live=self.scene_is_live(value)
            except Exception:
                live=False
            if not live:
                self.cache.pop(key,None)
                continue
            try:
                if value.get('dkyj_scene_draft'):cached_drafts.append(value)
            except (ReferenceError,RuntimeError):
                self.cache.pop(key,None)
        if cached_drafts:
            cached=cached_drafts[-1];draft={'id':cached.get('dkyj_scene_id'),'name':cached.get('previs_title','未保存场次'),'unsaved':True}
        return {'project':project_id,'active':active,'saved':catalog.items(project),'saved_count':catalog.saved_count(project),'free_limit':FREE_SAVED_SCENE_LIMIT,'draft':draft}

    def add(self,name,description='',project_id=None):
        name=str(name).strip()[:80];description=str(description).strip()[:2000]
        if not name:raise ValueError('请填写项目名称')
        project_id=project_id or uuid.uuid4().hex[:12]
        if not re.fullmatch(r'[a-z0-9-]{1,64}',project_id) or any(p['id']==project_id for p in self.catalog['projects']):raise ValueError('项目编号已存在或无效')
        stamp=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
        p={'id':project_id,'name':name,'description':description,'created_at':stamp,'updated_at':stamp,'scene_schema':2,'active_scene':None,'scenes':[]}
        self.catalog['projects'].append(p);return p

    def write_scene(self,scene,project_id,scene_id=None,is_pro=False):
        import bpy
        if not self.scene_is_live(scene):raise ValueError('场景已移除，请重新打开项目后保存')
        p=self.entry(project_id);catalog=self._scene_catalog(p)
        new_item=False
        scene_id=scene_id or scene.get('dkyj_scene_id') or self._active_scene_id(p)
        if scene_id is None:
            item=catalog.new_item(p,p.get('name','默认场次'),p.get('description',''),'default');scene_id=item['id'];p['active_scene']=scene_id;new_item=True
        else:
            try:item=catalog.item(p,scene_id)
            except ValueError:
                if scene_id != 'default' and not catalog.quota_allows(p,is_pro=is_pro):
                    raise SceneLimitError('免费版每个项目最多保存3个场次；请先手动删除旧场次，或激活 Pro')
                item=catalog.new_item(p,scene.get('previs_title',p.get('name','默认场次')),scene.get('previs_subtitle',p.get('description','')),scene_id)
                new_item=True
        dest=catalog.path(p,scene_id);dest.parent.mkdir(parents=True,exist_ok=True)
        if not catalog.quota_allows(p,is_pro=is_pro) and not dest.exists():
            if new_item:p['scenes'].remove(item)
            raise SceneLimitError('免费版每个项目最多保存3个场次；请先手动删除旧场次，或激活 Pro')
        scene['dkyj_project_id']=project_id
        scene['dkyj_scene_id']=scene_id;scene['dkyj_scene_draft']=False
        for ob in scene.objects:ob['dkyj_saved_name']=ob.name
        tmp=dest.with_name('scene.pending.blend')
        # Only this scene and its dependencies: other cached projects stay private.
        bpy.data.libraries.write(str(tmp),{scene},path_remap='RELATIVE_ALL',fake_user=True,compress=True)
        if dest.exists():
            import shutil
            shutil.copy2(dest,dest.with_name('scene.previous.blend'))
        tmp.replace(dest)
        stamp=utc_now();p['updated_at']=stamp;item['updated_at']=stamp;p['active_scene']=scene_id
        self.cache[(project_id,scene_id)]=scene
        self.persist()

    @staticmethod
    def scene_is_live(scene):
        import bpy
        try:return scene is not None and bpy.data.scenes.get(scene.name) == scene
        except ReferenceError:return False

    def load(self,project_id,scene_id=None):
        import bpy
        p=self.entry(project_id);catalog=self._scene_catalog(p);scene_id=scene_id or self._active_scene_id(p)
        cached=self.cache.get((project_id,scene_id))
        if self.scene_is_live(cached):return cached
        self.cache.pop((project_id,scene_id),None)
        file=catalog.path(p,scene_id)
        if not file.is_file():raise ValueError('项目文件不存在；当前场景保持不变')
        with bpy.data.libraries.load(str(file),link=False) as (data,loaded):
            if not data.scenes:raise ValueError('项目文件中没有场景')
            if len(data.scenes)!=1:raise ValueError('场次文件包含多个 Blender Scene，已拒绝导入以避免丢失场景')
            original_names=set(data.objects)
            loaded.scenes=[data.scenes[0]]
        scene=loaded.scenes[0]
        # Blender adds suffixes when different projects have identically named objects.
        names={}
        for o in scene.objects:
            original=o.get('dkyj_saved_name')
            if not original:
                candidates=[n for n in original_names if o.name==n or re.fullmatch(re.escape(n)+r'\.\d{3,}',o.name)]
                original=max(candidates,key=len) if candidates else o.name
            names[original]=o.name
            o['dkyj_saved_name']=o.name
        take=scene.get('previs_last_take')
        if take in names:scene['previs_last_take']=names[take]
        subjects=json.loads(scene.get('previs_subjects','[]'))
        for subject in subjects:
            if subject.get('object') in names:subject['object']=names[subject['object']]
        if subjects:scene['previs_subjects']=json.dumps(subjects,ensure_ascii=False)
        p=self.entry(project_id);scene['previs_title']=catalog.item(p,scene_id).get('name',p['name']);scene['previs_subtitle']=catalog.item(p,scene_id).get('description',p['description'])
        scene['dkyj_project_id']=project_id;scene['dkyj_scene_id']=scene_id;scene['dkyj_scene_draft']=False;self.cache[(project_id,scene_id)]=scene
        return scene

    def attach(self,scene):
        project_id=scene.get('dkyj_project_id')
        if project_id and any(p['id']==project_id for p in self.catalog['projects']):
            project=self.entry(project_id);self._scene_catalog(project)
            scene_id=scene.get('dkyj_scene_id') or self._active_scene_id(project)
            if scene_id:self.cache[(project_id,scene_id)]=scene;project['active_scene']=scene_id
        else:
            p=self.add(scene.get('previs_title','我的场景'),scene.get('previs_subtitle',''));project_id=p['id'];self.write_scene(scene,project_id)
        self.catalog['active']=project_id
        # Seed examples once, copying their saved models; never regenerate on switch.
        for pid,name,desc,file in [('steamship','蒸汽小船','船舱跑向甲板，飞机掠过。','steamship_scene.blend'),('room','室内排练','桌椅、窗户与两名角色的走位排练。','calibration_scene.blend')]:
            source=self.root/'examples'/file
            if source.exists() and not any(p['id']==pid for p in self.catalog['projects']):
                import shutil
                project=self.add(name,desc,pid);catalog=self._scene_catalog(project);item=catalog.new_item(project,name,desc,'default');dest=catalog.path(project,item['id']);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);project['active_scene']='default'
        self.persist();return project_id

    def create(self,current_scene,name,description='',source='current'):
        import shutil
        if source!='current':self.entry(source)
        p=self.add(name,description);pid=p['id'];catalog=self._scene_catalog(p);item=catalog.new_item(p,name,description,'default');p['active_scene']='default';dest=catalog.path(p,'default');dest.parent.mkdir(parents=True,exist_ok=True)
        try:
            if source=='current':
                # Snapshot then load independently, including independent mesh/action data.
                import bpy
                for ob in current_scene.objects:ob['dkyj_saved_name']=ob.name
                bpy.data.libraries.write(str(dest),{current_scene},path_remap='RELATIVE_ALL',fake_user=True,compress=True)
            else:shutil.copy2(self.path(source),dest)
            self.persist();scene=self.load(pid);scene['previs_title']=p['name'];scene['previs_subtitle']=p['description']
            self.write_scene(scene,pid);return pid,scene
        except Exception:
            self.catalog['projects'].remove(p);self.persist()
            raise

    def _snapshot_in_memory(self,current_scene):
        """Clone a Blender scene through a temporary file, never a project file."""
        import bpy
        with tempfile.TemporaryDirectory(prefix='dkyj-scene-draft-') as folder:
            draft_file=Path(folder)/'draft.blend'
            for ob in current_scene.objects:ob['dkyj_saved_name']=ob.name
            bpy.data.libraries.write(str(draft_file),{current_scene},path_remap='RELATIVE_ALL',fake_user=True,compress=True)
            with bpy.data.libraries.load(str(draft_file),link=False) as (data,loaded):
                if not data.scenes:raise ValueError('当前场景无法复制')
                loaded.scenes=[data.scenes[0]]
            return loaded.scenes[0]

    def create_scene(self,current_scene,name,description='',can_save=True,is_pro=False,discard_draft=False):
        """Create a saved scene, or an in-memory draft when its slot is full."""
        project_id=self.catalog.get('active')
        if not project_id:raise ValueError('请先打开一个项目')
        project=self.entry(project_id);catalog=self._scene_catalog(project)
        other_drafts=[]
        for key,value in list(self.cache.items()):
            if not isinstance(key,tuple) or key[0]!=project_id:continue
            try:
                if value is not current_scene and self.scene_is_live(value) and value.get('dkyj_scene_draft'):
                    other_drafts.append((key,value))
            except (ReferenceError,RuntimeError):
                self.cache.pop(key,None)
        if current_scene.get('dkyj_scene_draft') and other_drafts and not discard_draft:
            raise SceneDraftError('已有其他未保存场次；请先保存或明确 discard_draft=True')
        if discard_draft:
            for key,_value in other_drafts:self.cache.pop(key,None)
        allowed=bool(is_pro) or catalog.saved_count(project)<FREE_SAVED_SCENE_LIMIT
        if can_save and allowed:
            item=catalog.new_item(project,name,description)
            dest=catalog.path(project,item['id']);dest.parent.mkdir(parents=True,exist_ok=True)
            import bpy
            try:
                if not self.scene_is_live(current_scene):raise ValueError('当前场景已移除，请重新打开项目')
                bpy.data.libraries.write(str(dest),{current_scene},path_remap='RELATIVE_ALL',fake_user=True,compress=True)
                project['active_scene']=item['id'];project['updated_at']=utc_now();self.persist();return self.load(project_id,item['id'])
            except Exception:
                project['scenes'].remove(item)
                if dest.exists():dest.unlink()
                raise
        # A fourth free scene is useful for experimentation, but stays draft-only.
        draft=self._snapshot_in_memory(current_scene)
        draft['dkyj_project_id']=project_id;draft['dkyj_scene_id']='draft-'+uuid.uuid4().hex[:12];draft['dkyj_scene_draft']=True
        draft['previs_title']=str(name).strip()[:80] or '未保存场次';draft['previs_subtitle']=str(description).strip()[:2000]
        self.cache[(project_id,draft['dkyj_scene_id'])]=draft
        return draft

    def switch_scene(self,scene_id,current_scene=None,discard_draft=False):
        project_id=self.catalog.get('active')
        if not project_id:raise ValueError('请先打开一个项目')
        project=self.entry(project_id);catalog=self._scene_catalog(project)
        if current_scene is not None and current_scene.get('dkyj_scene_draft') and not discard_draft:
            raise SceneDraftError('当前场次尚未保存；请先保存或明确 discard_draft=True')
        catalog.item(project,scene_id)
        loaded=self.load(project_id,scene_id);project['active_scene']=scene_id;self.persist();return loaded

    def delete_scene(self,scene_id,project_id=None):
        """Manually remove a saved scene, retaining a recoverable project trash copy."""
        project_id=project_id or self.catalog.get('active')
        project=self.entry(project_id);catalog=self._scene_catalog(project);item=catalog.item(project,scene_id)
        if len(project.get('scenes',[]))<=1:raise ValueError('项目至少保留一个场次')
        source=catalog.path(project,scene_id)
        if source.exists():
            trash=self.directory/project_id/'trash'/f"{scene_id}-{datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')}"
            trash.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(source),str(trash))
        project['scenes']=[value for value in project['scenes'] if value.get('id')!=scene_id]
        self.cache.pop((project_id,scene_id),None)
        if project.get('active_scene')==scene_id:project['active_scene']=project['scenes'][0].get('id') if project['scenes'] else None
        self.persist();return self.scene_public(project_id)

    def save_current_scene(self,scene,is_pro=False):
        project_id=self.catalog.get('active')
        if not project_id:raise ValueError('请先打开一个项目')
        scene_id=scene.get('dkyj_scene_id')
        if scene.get('dkyj_scene_draft'):
            if not (is_pro or self._scene_catalog(self.entry(project_id)).saved_count(self.entry(project_id))<FREE_SAVED_SCENE_LIMIT):
                raise SceneLimitError('免费版每个项目最多保存3个场次；请先手动删除旧场次，或激活 Pro')
            item=self._scene_catalog(self.entry(project_id)).new_item(self.entry(project_id),scene.get('previs_title','未保存场次'),scene.get('previs_subtitle',''))
            scene_id=item['id']
        try:
            self.write_scene(scene,project_id,scene_id,is_pro=is_pro)
        except Exception:
            if scene.get('dkyj_scene_draft') and item is not None:
                self.entry(project_id)['scenes'].remove(item)
            raise
        return self.scene_public(project_id)

    def metadata(self,project_id,name,description):
        p=self.entry(project_id)
        name=str(name).strip()[:80]
        if not name:raise ValueError('请填写项目名称')
        p['name']=name;p['description']=str(description).strip()[:2000];self.persist()
