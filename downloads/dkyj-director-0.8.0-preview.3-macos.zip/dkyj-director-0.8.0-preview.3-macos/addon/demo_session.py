"""A disposable Blender process for the built-in controller recording trial."""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile


class DemoSession:
    def __init__(self, root):
        self.root = Path(root)
        self.process = None
        self.folder = None
        self.log = None

    def start(self, return_url=None):
        if self.process and self.process.poll() is None:
            return
        self.close()
        from platform_paths import blender_binary
        source = self.root / 'examples/calibration_scene.blend'
        if not source.is_file():
            raise ValueError('官方体验场景未安装，请先运行 scripts/setup.py')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        self.folder = Path(tempfile.mkdtemp(prefix='dkyj-controller-demo-'))
        if return_url:
            target = self.folder / 'return.json'
            target.write_text(json.dumps({'url': return_url}))
            target.chmod(0o600)
        self.log = (self.folder / 'demo.log').open('w')
        # Never use the user's active .blend or start Blender MCP for the demo.
        try:
            self.process = subprocess.Popen([
                blender_binary(), '--factory-startup', '--disable-autoexec', str(source),
                '--python', str(self.root / 'scripts/launch_controller_demo.py'), '--',
                str(self.folder), str(port)], stdout=self.log, stderr=subprocess.STDOUT,
                env={**os.environ, 'DKYJ_HOME': str(self.root)})
        except Exception:
            self.close()
            raise ValueError('体验场景启动失败，请检查 Blender 安装') from None

    def url(self):
        if not self.process or self.process.poll() is not None:
            return None
        connection = self.folder / 'runtime/connection.json'
        try:
            info = json.loads(connection.read_text())
            return info['http_url'].replace('&phone=1', '')
        except (OSError, ValueError, KeyError):
            return None

    def close(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        if self.log:
            self.log.close()
        if self.folder and self.folder.name.startswith('dkyj-controller-demo-'):
            shutil.rmtree(self.folder, ignore_errors=True)
        self.process = self.folder = self.log = None
