"""Official input routing. This is not physical-device attestation."""
import time


class ControllerSession:
    def __init__(self):
        self.owner = None
        self.last_seen = 0.0

    def public(self):
        return {'mode': 'gamepad' if self.owner else 'manual', 'client_id': self.owner}

    def clear(self):
        self.owner = None

    def check(self, event, *, recording=False, pro=False, demo=False):
        kind = event.get('type')
        client = event.get('client_id', 'legacy')
        if not isinstance(client, str) or not 1 <= len(client) <= 128:
            raise ValueError('控制客户端编号无效')
        gamepad = event.get('input_source') == 'gamepad'
        if kind == 'controller_begin':
            if recording and not (pro or demo):
                raise ValueError('手柄录制需要 Pro；请停止当前录制后体验手柄运镜')
            if self.owner and self.owner != client:
                raise ValueError('另一台设备正在控制机位，请先在该设备关闭手柄')
        if kind == 'record' and (gamepad or self.owner) and not (pro or demo):
            raise ValueError('手柄录制需要 Pro。关闭手柄后可用触控、体感或键盘录制，Lite 导出带水印。')
        if kind in ('input', 'settings', 'orientation'):
            if gamepad and self.owner != client:
                raise ValueError('手柄会话已结束，请重新点击手柄运镜')
            if self.owner and self.owner != client:
                raise ValueError('另一台设备正在手柄运镜')
            if recording and (gamepad or self.owner) and not (pro or demo):
                raise ValueError('手柄录制需要 Pro')

    def accept(self, event, **context):
        self.check(event, **context)
        client = event.get('client_id', 'legacy')
        if event.get('type') == 'controller_begin':
            self.owner = client
        elif event.get('type') == 'controller_end' and self.owner == client:
            self.clear()
        if self.owner == client:
            self.last_seen = time.monotonic()

    def expire(self, now=None):
        # The client sends a heartbeat even while the sticks are centered.
        if self.owner and (time.monotonic() if now is None else now) - self.last_seen > 3:
            self.clear()
            return True
        return False
