"""Scene catalog helpers used by :mod:`scene_projects`.

Projects and scenes are deliberately separate concepts.  A project owns a
small catalog of saved Blender scenes; a scene is never inferred from a Take
or from a spatial zone.  This module contains the filesystem and quota rules
so callers cannot accidentally implement a second, subtly different policy.
"""
import datetime
import re
import uuid
import sys
from pathlib import Path


SCENE_SCHEMA_VERSION = 2
# The final save gate and the license UI use the same product quota.
_root = str(Path(__file__).resolve().parents[1])
if _root not in sys.path:
    sys.path.insert(0, _root)
from licensing.config import FREE_SCENE_LIMIT as FREE_SAVED_SCENE_LIMIT
_SCENE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,63}")


class SceneLimitError(ValueError):
    """The free plan has no remaining saved-scene slot."""


class SceneDraftError(ValueError):
    """An unsaved scene would be discarded without an explicit choice."""


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


class SceneCatalog:
    """Normalize project metadata and resolve scene files safely."""

    def __init__(self, project_folder):
        self.project_folder = Path(project_folder).resolve()

    @staticmethod
    def ensure_project(project):
        """Migrate a v1 project in memory without deleting any old metadata."""
        scenes = project.get("scenes")
        if not isinstance(scenes, list):
            scenes = []
            project["scenes"] = scenes
        project.setdefault("active_scene", None)
        return project

    def migrate_legacy(self, project):
        """Add a metadata entry for the legacy ``scene.blend`` when present."""
        self.ensure_project(project)
        if not any(item.get("id") == "default" for item in project["scenes"]):
            default_file = self.project_folder / "scene.blend"
            if default_file.is_file():
                stamp = project.get("created_at", utc_now())
                project["scenes"].insert(0, {
                    "id": "default",
                    "name": project.get("name", "默认场次"),
                    "description": project.get("description", ""),
                    "created_at": stamp,
                    "updated_at": project.get("updated_at", stamp),
                    "file": "scene.blend",
                })
        if project.get("active_scene") is None and project["scenes"]:
            project["active_scene"] = project["scenes"][0].get("id")
        project["scene_schema"] = SCENE_SCHEMA_VERSION
        return project

    @staticmethod
    def validate_id(scene_id):
        if not isinstance(scene_id, str) or not _SCENE_ID.fullmatch(scene_id):
            raise ValueError("无效场次编号")
        return scene_id

    def item(self, project, scene_id=None):
        self.ensure_project(project)
        if scene_id is None:
            scene_id = project.get("active_scene")
        if scene_id is None and project["scenes"]:
            scene_id = project["scenes"][0].get("id")
        self.validate_id(scene_id)
        for item in project["scenes"]:
            if item.get("id") == scene_id:
                return item
        raise ValueError("场次不存在，请刷新场次列表")

    def path(self, project, scene_id=None):
        item = self.item(project, scene_id)
        relative = item.get("file")
        if not isinstance(relative, str):
            relative = "scene.blend" if item["id"] == "default" else f"scenes/{item['id']}/scene.blend"
        target = (self.project_folder / relative).resolve()
        if not target.is_relative_to(self.project_folder):
            raise ValueError("场次路径超出项目目录")
        return target

    def items(self, project):
        self.ensure_project(project)
        result = []
        for item in project["scenes"]:
            value = dict(item)
            try:
                value["available"] = self.path(project, item.get("id")).is_file()
            except (ValueError, TypeError):
                value["available"] = False
            result.append(value)
        return result

    def saved_count(self, project):
        return sum(1 for item in self.items(project) if item.get("available"))

    def new_item(self, project, name, description="", scene_id=None):
        self.ensure_project(project)
        name = str(name).strip()[:80]
        description = str(description).strip()[:2000]
        if not name:
            raise ValueError("请填写场次名称")
        scene_id = scene_id or uuid.uuid4().hex[:12]
        self.validate_id(scene_id)
        if any(item.get("id") == scene_id for item in project["scenes"]):
            raise ValueError("场次编号已存在")
        stamp = utc_now()
        item = {"id": scene_id, "name": name, "description": description,
                "created_at": stamp, "updated_at": stamp,
                "file": "scene.blend" if scene_id == "default" else f"scenes/{scene_id}/scene.blend"}
        project["scenes"].append(item)
        return item

    def quota_allows(self, project, is_pro=False):
        return bool(is_pro) or self.saved_count(project) < FREE_SAVED_SCENE_LIMIT
