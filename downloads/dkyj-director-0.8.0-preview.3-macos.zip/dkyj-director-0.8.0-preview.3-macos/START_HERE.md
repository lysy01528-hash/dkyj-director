# DKYJ Director — macos

Install Blender + Python, then open Launch DKYJ Director.command.

安装 Blender、Python 后双击 Launch DKYJ Director.command。电脑 Safari。

手机端仅支持 iPhone Safari / Phone: iPhone Safari only.

Full guide: README.md / README.zh-CN.md.
