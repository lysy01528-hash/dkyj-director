"""Durable, data-only scene briefs for a user's external agent."""
import datetime,json,re
from pathlib import Path

MODEL_MODES = {'simple', 'detailed'}

def modeling_profile(mode='simple', requires_confirmation=False):
    if mode not in MODEL_MODES:raise ValueError('建模档位只能是简化或细节')
    return {
        'mode':mode, 'label':'简化建模 · 运镜优先' if mode=='simple' else '细节建模',
        'requires_confirmation':requires_confirmation,
        'preset':'blockout-v1' if mode=='simple' else 'detailed',
        'character_template':({'factory':'DKYJ MCP create_blockout_character','visible_meshes':2,'head':'low_poly_sphere','body':'cuboid','limbs':False,'textures':False,'head_diameter_ratio':0.24,'body_height_ratio':0.76,'body_width_ratio':0.26,'body_depth_ratio':0.18} if mode=='simple' else None),
        'scene':('使用低面数基础体块；只保留空间轮廓、门窗通道、地面与动作必需陈设。省略装饰、纹理、螺丝、密集栏杆和非必要小物。' if mode=='simple' else '只增加用户明确需要的可见结构与陈设细节；不要默认堆叠装饰或高密度网格。'),
        'characters':('固定使用一个低面球形头 + 一个长方体身体，每人仅两个可见网格，通体同一纯色；禁止四肢、胶囊躯干、五官、头发、手指、服装细节及复杂骨骼。使用 blockout_primitives.create_character 标准工厂，动作通过根对象整体平移、转向与关键帧表达。' if mode=='simple' else '按用户需求增加人物轮廓或动作所需关节；脸部、手指、服装细节仅在用户要求时制作。'),
        'motion':'保留可编辑关键帧、清晰剪影、人物间距、通行宽度与摄影机通道；不增加随机晃动、布料／刚体模拟或非必要粒子。特效优先使用简洁可控的占位体。',
        'preserve':'保留真实空间尺度与重要遮挡关系，不能为不穿模而擅自删除必要墙体；在独立方案里简化，保留源模型和已有运镜。',
        'verification':'检查运镜起点、转弯、人物交错和终点的镜头视图与俯视图；说明是否有穿模、遮挡或额外动态干扰。'
    }

def set_modeling(brief, mode, explicit=False):
    if mode == 'detailed' and not explicit:
        raise ValueError('请先打开详细建模开关；默认始终使用固定简化白模')
    brief.pop('model_confirmation_pending',None)
    brief['model_detail']=mode
    brief['model_detail_explicit']=bool(explicit)
    brief['modeling']=modeling_profile(mode)

def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
class BriefStore:
    def __init__(self,root):
        self.path=Path(root)/'projects/briefs.json';self.path.parent.mkdir(parents=True,exist_ok=True)
        self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {'revision':0,'items':[]}
        for b in self.data['items']:
            set_modeling(b,b.get('model_detail','simple') if b.get('model_detail_explicit') else 'simple',b.get('model_detail_explicit',False))
    def save(self):
        self.data['revision']+=1;p=self.path.with_suffix('.pending');p.write_text(json.dumps(self.data,ensure_ascii=False,indent=2), encoding='utf-8');p.replace(self.path)
    def find(self,id):
        found=next((b for b in self.data['items'] if b['id']==id),None)
        if not found:raise ValueError('创作任务不存在')
        return found
    def create(self,e):
        id=e.get('id','')
        if not re.fullmatch(r'[a-z0-9-]{8,64}',id):raise ValueError('无效任务编号')
        if any(b['id']==id for b in self.data['items']):return self.find(id)
        fields={k:str(e.get(k,'')).strip()[:limit] for k,limit in [('scene',2000),('characters',1000),('action',2000),('camera',1000),('source',64)]}
        prompt=str(e.get('prompt','')).strip()
        if len(prompt)>6000:raise ValueError('场景描述最多 6000 字')
        if not prompt and (not fields['scene'] or not fields['characters'] or not fields['action']):raise ValueError('请填写你想制作的场景描述')
        if prompt:fields['scene']=prompt[:2000]
        fields['prompt']=prompt
        fields['input_format']='single_prompt' if prompt else 'structured'
        b=dict(id=id,**fields,status='waiting',project_id=None,created_at=stamp(),updated_at=stamp(),messages=[],verification='')
        mode=e.get('model_detail','simple')
        if mode not in MODEL_MODES:raise ValueError('无效建模档位')
        set_modeling(b,mode,e.get('model_detail_explicit') is True)
        self.data['items'].append(b);self.save();return b
    def update(self,e):
        b=self.find(e.get('id'));status=e.get('status',b['status']);message=str(e.get('message','')).strip()[:2000]
        if status not in {'waiting','working','needs_input','ready','failed'}:raise ValueError('无效任务状态')
        if status in {'working','ready'} and b.get('modeling',{}).get('requires_confirmation'):raise ValueError('请先确认使用简化建模还是细节建模')
        if status=='ready' and b['status']!='working':raise ValueError('请先制作并检查场景，再完成任务')
        if status=='ready' and (not e.get('project_id',b['project_id']) or not str(e.get('verification','')).strip()):raise ValueError('完成任务需要项目编号与验证说明')
        b['status']=status;b['updated_at']=stamp()
        if e.get('project_id'):b['project_id']=e['project_id']
        if e.get('verification'):b['verification']=str(e['verification'])[:2000]
        if message:b['messages'].append({'role':'agent','text':message,'at':stamp()})
        self.save()
    def reply(self,e):
        b=self.find(e.get('id'));message=str(e.get('message','')).strip()[:2000]
        if not message:raise ValueError('请填写补充说明')
        if b['status']=='working':raise ValueError('Agent 正在制作，请等它完成或提出问题后再补充')
        mode=e.get('model_detail')
        if mode is not None and mode not in MODEL_MODES:raise ValueError('无效建模档位')
        if mode is not None:set_modeling(b,mode,True)
        b['messages'].append({'role':'user','text':message,'at':stamp()});b['status']='waiting';b['updated_at']=stamp();self.save()
