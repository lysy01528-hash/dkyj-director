"""Create and validate fixed, featureless blockout characters in Blender."""

import math

import bpy


BLOCKOUT_VERSION = '1'
SPHERE_SEGMENTS = 16
SPHERE_RINGS = 8
_EPSILON = 1e-5


def _finite_vector(value, length, label):
    try:
        result = tuple(float(part) for part in value)
    except (TypeError, ValueError):
        raise ValueError(f'{label} must contain {length} finite numbers')
    if len(result) != length or not all(math.isfinite(part) for part in result):
        raise ValueError(f'{label} must contain {length} finite numbers')
    return result


def _sphere_geometry(radius):
    """Return a UV sphere with 16 segments and 8 latitude divisions."""
    vertices = [(0.0, 0.0, radius)]
    for ring in range(1, SPHERE_RINGS):
        latitude = math.pi * ring / SPHERE_RINGS
        for segment in range(SPHERE_SEGMENTS):
            longitude = 2.0 * math.pi * segment / SPHERE_SEGMENTS
            vertices.append((radius * math.sin(latitude) * math.cos(longitude),
                             radius * math.sin(latitude) * math.sin(longitude),
                             radius * math.cos(latitude)))
    south = len(vertices)
    vertices.append((0.0, 0.0, -radius))
    faces = []

    def outward(face):
        a, b, c = (vertices[index] for index in face[:3])
        ux, uy, uz = (b[i] - a[i] for i in range(3))
        vx, vy, vz = (c[i] - a[i] for i in range(3))
        normal = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        center = tuple(sum(vertices[index][axis] for index in face) / len(face) for axis in range(3))
        return face if sum(normal[i] * center[i] for i in range(3)) >= 0 else tuple(reversed(face))

    for segment in range(SPHERE_SEGMENTS):
        nxt = (segment + 1) % SPHERE_SEGMENTS
        faces.append(outward((0, 1 + nxt, 1 + segment)))
    for ring in range(SPHERE_RINGS - 2):
        upper = 1 + ring * SPHERE_SEGMENTS
        lower = upper + SPHERE_SEGMENTS
        for segment in range(SPHERE_SEGMENTS):
            nxt = (segment + 1) % SPHERE_SEGMENTS
            faces.append(outward((upper + segment, upper + nxt, lower + nxt, lower + segment)))
    last_ring = 1 + (SPHERE_RINGS - 2) * SPHERE_SEGMENTS
    for segment in range(SPHERE_SEGMENTS):
        nxt = (segment + 1) % SPHERE_SEGMENTS
        faces.append(outward((last_ring + segment, last_ring + nxt, south)))
    return vertices, faces


def _box_geometry(width, depth, height):
    x, y, z = width / 2.0, depth / 2.0, height / 2.0
    vertices = [(-x, -y, -z), (x, -y, -z), (x, y, -z), (-x, y, -z),
                (-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z)]
    faces = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
             (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    return vertices, faces


def _require_available_name(name):
    if (bpy.data.objects.get(name) is not None or
            bpy.data.meshes.get(name) is not None or
            bpy.data.materials.get(name) is not None):
        raise ValueError(f"Blender name '{name}' is already in use; choose a new character ID")


def create_character(name, location=(0, 0, 0), height=1.75,
                     color=(0.55, 0.55, 0.55), scene=None):
    """Create a featureless sphere-head/box-body character.

    The returned Empty is the animation root. ``location`` is the root's
    ground-level origin, so the bottom of the body is at local Z=0.
    """
    if not isinstance(name, str) or not name.strip():
        raise ValueError('name must be a non-empty string')
    name = name.strip()
    location = _finite_vector(location, 3, 'location')
    try:
        height = float(height)
    except (TypeError, ValueError):
        raise ValueError('height must be a positive finite number')
    if not math.isfinite(height) or height <= 0:
        raise ValueError('height must be a positive finite number')
    color = _finite_vector(color, 3, 'color')
    if any(component < 0 or component > 1 for component in color):
        raise ValueError('color components must be between 0 and 1')
    if scene is None:
        scene = bpy.context.scene
    if (not isinstance(scene, bpy.types.Scene) or
            bpy.data.scenes.get(scene.name) is not scene):
        raise ValueError('scene must be a live Blender Scene')

    names = (name, name + '_Body', name + '_Head',
             name + '_BodyMesh', name + '_HeadMesh', name + '_Material')
    for candidate in names:
        _require_available_name(candidate)

    body_height = height * 0.76
    head_diameter = height * 0.24
    body_width = height * 0.26
    body_depth = height * 0.18

    # Construct datablocks only after all public inputs and names are checked.
    material = bpy.data.materials.new(name + '_Material')
    material.diffuse_color = (*color, 1.0)
    if material.node_tree:
        material.node_tree.nodes.clear()
    body_mesh = bpy.data.meshes.new(name + '_BodyMesh')
    body_vertices, body_faces = _box_geometry(body_width, body_depth, body_height)
    body_mesh.from_pydata(body_vertices, [], body_faces)
    body_mesh.update()
    body_mesh.materials.append(material)
    head_mesh = bpy.data.meshes.new(name + '_HeadMesh')
    head_vertices, head_faces = _sphere_geometry(head_diameter / 2.0)
    head_mesh.from_pydata(head_vertices, [], head_faces)
    head_mesh.update()
    head_mesh.materials.append(material)

    root = bpy.data.objects.new(name, None)
    root.empty_display_type = 'PLAIN_AXES'
    root.location = location
    root['dkyj_character_id'] = name
    root['dkyj_blockout_version'] = BLOCKOUT_VERSION
    root['dkyj_blockout_height'] = height
    root['dkyj_blockout_color'] = color
    scene.collection.objects.link(root)

    body = bpy.data.objects.new(name + '_Body', body_mesh)
    body.parent = root
    body.location = (0.0, 0.0, body_height / 2.0)
    body['dkyj_character_part'] = 'body'
    scene.collection.objects.link(body)

    head = bpy.data.objects.new(name + '_Head', head_mesh)
    head.parent = root
    head.location = (0.0, 0.0, body_height + head_diameter / 2.0)
    head['dkyj_character_part'] = 'head'
    scene.collection.objects.link(head)
    return root


def validate_character(root):
    """Raise ValueError unless root is one untouched fixed blockout character."""
    def invalid(reason):
        raise ValueError(f'invalid blockout character: {reason}')

    if not isinstance(root, bpy.types.Object) or bpy.data.objects.get(root.name) is not root:
        invalid('root is not a live Blender object')
    if root.type != 'EMPTY' or not root.get('dkyj_character_id'):
        invalid('root must be a tagged Empty')
    if root.get('dkyj_blockout_version') != BLOCKOUT_VERSION:
        invalid('unsupported blockout version')
    try:
        height = float(root['dkyj_blockout_height'])
        color = _finite_vector(root['dkyj_blockout_color'], 3, 'color')
    except (KeyError, TypeError, ValueError):
        invalid('missing or malformed dimensions/color metadata')
    if not math.isfinite(height) or height <= 0:
        invalid('height metadata must be positive')
    children = list(root.children)
    if len(children) != 2 or any(child.parent is not root for child in children):
        invalid('root must have exactly two direct child meshes')
    if any(child.children for child in children):
        invalid('child meshes cannot have children')
    by_part = {child.get('dkyj_character_part'): child for child in children}
    if set(by_part) != {'body', 'head'} or len(by_part) != 2:
        invalid('children must be tagged exactly once as body and head')
    body, head = by_part['body'], by_part['head']
    if body.type != 'MESH' or head.type != 'MESH':
        invalid('body and head must be meshes')

    expected_body = _box_geometry(height * 0.26, height * 0.18, height * 0.76)
    if len(body.data.vertices) != 8 or len(body.data.polygons) != 6:
        invalid('body must be an eight-vertex, six-face box')
    if any(len(poly.vertices) != 4 for poly in body.data.polygons):
        invalid('body faces must be quads')
    for actual, expected in zip(body.data.vertices, expected_body[0]):
        if any(abs(actual.co[index] - expected[index]) > _EPSILON for index in range(3)):
            invalid('body geometry does not match the fixed proportions')

    radius = height * 0.12
    if len(head.data.vertices) != 2 + SPHERE_SEGMENTS * (SPHERE_RINGS - 1):
        invalid('head must use a 16 by 8 UV sphere')
    if len(head.data.polygons) != SPHERE_SEGMENTS * SPHERE_RINGS:
        invalid('head must use a 16 by 8 UV sphere')
    for vertex in head.data.vertices:
        if abs(vertex.co.length - radius) > _EPSILON:
            invalid('head vertices do not match the fixed sphere radius')
    if any(poly.use_smooth for poly in head.data.polygons):
        invalid('head must use flat shading')

    expected_body_z = height * 0.76 / 2.0
    expected_head_z = height * 0.76 + radius
    if (any(abs(body.location[i] - (0, 0, expected_body_z)[i]) > _EPSILON for i in range(3)) or
            any(abs(head.location[i] - (0, 0, expected_head_z)[i]) > _EPSILON for i in range(3))):
        invalid('body/head placement does not match the fixed proportions')
    if len(body.data.materials) != 1 or len(head.data.materials) != 1:
        invalid('each mesh must have exactly one solid material')
    body_mat, head_mat = body.data.materials[0], head.data.materials[0]
    if (body_mat is None or head_mat != body_mat or
            (body_mat.node_tree and len(body_mat.node_tree.nodes) != 0)):
        invalid('meshes must share one material without nodes or textures')
    if any(abs(body_mat.diffuse_color[index] - color[index]) > _EPSILON for index in range(3)):
        invalid('material color does not match character metadata')
    return True
