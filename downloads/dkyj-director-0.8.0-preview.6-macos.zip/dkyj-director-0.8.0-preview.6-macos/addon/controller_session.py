"""Exclusive phone/gamepad routing. This is not physical-device attestation."""
import time


class ControllerSession:
    POSE = {'input', 'settings', 'orientation', 'sensor_base', 'resume_live',
            'camera', 'reset_camera', 'record', 'play', 'seek'}

    def __init__(self):
        self.mode = 'phone'
        self.client = None
        self.last_seen = 0.0
        self.record_client = None
        self.record_mode = None

    @property
    def owner(self):
        return self.client if self.mode == 'gamepad' else None

    def public(self):
        return {'mode': self.mode, 'client_id': self.client,
                'record_client_id': self.record_client, 'record_mode': self.record_mode}

    def clear(self):
        self.client = self.record_client = self.record_mode = None
        self.mode = 'phone'

    def check(self, event, *, recording=False, pro=False, demo=False):
        kind = event.get('type')
        client = event.get('client_id', 'legacy')
        if not isinstance(client, str) or not 1 <= len(client) <= 128:
            raise ValueError('控制客户端编号无效')
        source = 'gamepad' if event.get('input_source') == 'gamepad' else 'phone'
        wanted = 'gamepad' if kind == 'controller_begin' else event.get('mode')
        if kind == 'control_mode' and wanted not in ('phone', 'gamepad'):
            raise ValueError('未知控制模式')
        if kind == 'controller_begin' and recording and not (pro or demo):
            raise ValueError('手柄录制需要 Pro；请停止当前录制后体验手柄运镜')
        if kind == 'record' and (source == 'gamepad' or self.owner) and not (pro or demo):
            raise ValueError('手柄录制需要 Pro。关闭手柄后可用触控、体感或键盘录制，Lite 导出带水印。')
        if kind in self.POSE or kind in ('control_mode', 'controller_begin'):
            owner = self.record_client if recording and self.record_client else self.client
            if owner and owner != client:
                raise ValueError('另一台设备正在控制机位，请先停止并释放控制')
        if kind in ('controller_begin', 'control_mode'):
            if recording and wanted != (self.record_mode or self.mode):
                raise ValueError('录制中不能切换手机 / 手柄模式，请先停止录制')
        if kind in ('input', 'settings', 'orientation', 'sensor_base'):
            mode = self.record_mode if recording and self.record_mode else self.mode
            if source != mode or (kind in ('orientation', 'sensor_base') and mode != 'phone'):
                raise ValueError('控制模式不匹配，请明确选择手机或手柄模式')
            if source == 'gamepad' and self.owner != client:
                raise ValueError('手柄会话已结束，请重新点击手柄运镜')
            if recording and source == 'gamepad' and not (pro or demo):
                raise ValueError('手柄录制需要 Pro')

    def accept(self, event, **context):
        self.check(event, **context)
        kind = event.get('type')
        client = event.get('client_id', 'legacy')
        if kind == 'control_mode':
            self.mode, self.client = event['mode'], client
        elif kind == 'controller_begin':
            self.mode, self.client = 'gamepad', client
        elif kind == 'controller_end' and self.client == client:
            self.client = None
        elif kind in ('stop', 'pause'):
            self.record_client = self.record_mode = None
            self.client = None
        elif kind in ('resume_live', 'sensor_base', 'record') or (
                kind == 'input' and any(event.get('move', []) + event.get('look', []))):
            if self.client is None and self.mode == 'phone':
                self.client = client
        if kind == 'record':
            self.record_client, self.record_mode = client, self.mode
        if self.client == client:
            self.last_seen = time.monotonic()

    def expire(self, now=None):
        # Both control modes send heartbeats while the sticks are centered.
        if self.client and (time.monotonic() if now is None else now) - self.last_seen > 3:
            self.client = None
            return True
        return False
