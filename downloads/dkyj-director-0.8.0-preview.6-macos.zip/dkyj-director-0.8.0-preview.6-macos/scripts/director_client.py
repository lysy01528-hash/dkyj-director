"""Authenticated local director client; credentials stay on this machine."""
import json,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def request(path,data=None):
    token=json.loads((ROOT/'runtime/connection.json').read_text(encoding='utf-8'))['token']
    req=urllib.request.Request('http://127.0.0.1:8765'+path+'?token='+token,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=15) as r:return json.load(r)
def state():return request('/api/state')

def _revision(body, snapshot):
    """Return the backend revision used to confirm this command."""
    kind=body.get('type','')
    if kind=='blockout_character':return snapshot.get('blockout_event',0)
    if kind.startswith('project_'):return snapshot.get('project_event',0)
    if kind.startswith('scene_'):
        scenes=snapshot.get('scenes') or {}
        # Scene commands use the existing backend project_event counter.
        # Keep the other fields only as compatibility fallback for older hosts.
        if 'project_event' in snapshot:return snapshot.get('project_event',0)
        if 'scene_event' in snapshot:return snapshot.get('scene_event',0)
        return scenes.get('revision',snapshot.get('scene_revision',0)) if isinstance(scenes,dict) else snapshot.get('scene_revision',0)
    if kind.startswith('brief_'):return snapshot.get('briefs',{}).get('revision',0)
    return snapshot.get('event',0)

def command(body):
    before=state();revision=_revision(body,before)
    response=request('/api/control',body)
    if isinstance(response,dict) and response.get('ok') is False:raise RuntimeError(response.get('error','Director command rejected'))
    deadline=time.monotonic()+60
    while time.monotonic()<deadline:
        time.sleep(.25);s=state();now=_revision(body,s)
        if now>revision:
            if s.get('error'):raise RuntimeError(s['error'])
            return s
        # Retry of a client-generated brief id is idempotent.
        if body['type']=='brief_create' and any(b['id']==body['id'] for b in s.get('briefs',{}).get('items',[])):return s
    raise TimeoutError('Command not confirmed; inspect director state before retrying.')

def scene_create(name,description='',discard_draft=False):
    body={'type':'scene_create','name':name,'description':description,'discard_draft':bool(discard_draft)}
    return command(body)

def scene_save():
    return command({'type':'scene_save'})

def scene_switch(scene_id,discard_draft=False):
    return command({'type':'scene_switch','id':scene_id,'discard_draft':bool(discard_draft)})

def scene_delete(scene_id):
    return command({'type':'scene_delete','id':scene_id})

def scene_discard():
    return command({'type':'scene_discard','discard_draft':True})
