"""Disposable real-render smoke test. Run in background Blender; no user project is opened."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import urllib.request
import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'addon'))
sys.path.insert(0, str(ROOT / 'tests'))
from test_deleted_data import DeletedDataTests, module
out = ROOT / 'qa/capture-export-e2e'
out.mkdir(parents=True, exist_ok=True)
module.TAKES = out
fixture = DeletedDataTests();fixture.setUp()
s, scene = fixture.s, fixture.scene
report = {'ok': False, 'exports': [], 'blender': bpy.app.version_string}

def command(event, rid):
    event = {**event, 'client_id': 'e2e-phone', 'request_id': rid}
    request = urllib.request.Request(fixture.url.replace('/api/state','/api/control'),
        data=json.dumps(event).encode(), headers={'Content-Type':'application/json'})
    accepted = json.load(fixture.opener.open(request, timeout=5))
    assert accepted.get('queued') == rid
    while s.events:
        s.process(s.events.popleft())
    ack = json.load(fixture.opener.open(fixture.url.replace('/api/state','/api/command')+'&client_id=e2e-phone&id='+rid,timeout=5))
    assert ack['status'] == 'done', ack

try:
    scene.frame_start, scene.frame_end = 1, 12
    scene.render.fps = 24
    # Static reference geometry means a changing POV must come from the camera.
    for x in (-2, 0, 2):
        bpy.ops.mesh.primitive_cube_add(size=1, location=(x,0,.5))
        mat=bpy.data.materials.new('Reference');mat.diffuse_color=(.25+.1*x,.4,.5,1)
        bpy.context.object.data.materials.append(mat)
    bpy.ops.mesh.primitive_plane_add(size=20, location=(0,0,-.05))
    camera=scene.camera;camera.location=(0,-8,3)
    camera.rotation_quaternion=(Vector((0,0,.6))-camera.location).to_track_quat('-Z','Y')
    scene['previs_zones'] = json.dumps([{'id':'room','name':'测试空间','description':'三个固定方块用于观察相机横移、转向与变焦。','color':'#999999','x':0,'y':0,'z':0,'width':8,'depth':8,'height':3,'open_sky':True}])
    command({'type':'control_mode','mode':'phone'}, 'mode')
    command({'type':'record'}, 'record')
    take=scene.camera
    for frame in range(1,13):
        scene.frame_set(frame)
        take.location=(frame*.18-1.2,-8+frame*.05,3)
        take.rotation_quaternion=(Vector((.2,0,.6))-take.location).to_track_quat('-Z','Y')
        take.data.lens=32+frame
        s.record_key()
    command({'type':'stop'}, 'stop')
    assert s.recorded_take_info()['frames']==12
    command({'type':'resume_live'}, 'resume')
    assert scene.camera.get('dkyj_live_camera')
    for mode in ('pov','spatial','overview'):
        command({'type':'export','mode':mode}, 'export-'+mode)
        assert s.export_process is not None
        deadline=time.monotonic()+240
        while s.export_process.poll() is None:
            if time.monotonic()>deadline:raise RuntimeError('render timed out: '+mode)
            time.sleep(.25)
        s.finish_export()
        assert s.export_state['status']=='done', s.export_state
        files=[f['url'].split('/download/')[1].split('?')[0] for f in s.export_state['files']]
        assert all((out/f).stat().st_size>0 for f in files)
        # Download every artifact via production Handler, not just a file existence check.
        for f in files:
            url=fixture.url.split('/api/state')[0]+'/download/'+f+'?token='+s.token
            data=fixture.opener.open(url,timeout=10).read()
            assert data==(out/f).read_bytes()
        report['exports'].append({'mode':mode,'camera':s.export_state['camera'],'files':files})
        print('REAL_EXPORT_OK',mode,flush=True)
    report['ok']=True
finally:
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    fixture.tearDown()
print('CAPTURE_EXPORT_E2E_OK',json.dumps(report,ensure_ascii=False),flush=True)
