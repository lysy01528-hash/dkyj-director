#!/usr/bin/env node
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

function makeHarness({portrait = false, fullscreenReject = false, lockReject = false, phone = true} = {}) {
  const listeners = new Map();
  let isPortrait = portrait;
  const makeTarget = () => ({
    style: {}, classList: {values: new Set(), add(v) { this.values.add(v); }, remove(v) { this.values.delete(v); }, toggle(v, on) { on ? this.values.add(v) : this.values.delete(v); }},
    addEventListener(type, fn) { (listeners.get(this) || listeners.set(this, new Map()).get(this)).set(type, fn); },
    dispatch(type, event = {}) { return listeners.get(this)?.get(type)?.({...event, type}); },
    dispatchEvent(event) { this.dispatched = (this.dispatched || 0) + 1; return this.dispatch(event.type, event); },
    setPointerCapture() {}, getBoundingClientRect() { return {left: 0, top: 0, width: 100, height: 100}; },
  });
  const byId = Object.fromEntries(['phoneLookPad','phoneLookStick','phonePortraitGate','phoneFullscreen','phoneFullscreenWide','phoneOrientationStatus','controlMode'].map(id => [id, makeTarget()]));
  byId.phonePortraitGate.hidden = false;
  byId.phoneFullscreenWide.hidden = true;
  byId.controlMode.value = 'gamepad';
  let modeChanges = 0;
  byId.controlMode.addEventListener('change', () => modeChanges++);
  const body = makeTarget();
  const documentListeners = new Map();
  const doc = {
    body, documentElement: {requestFullscreen: fullscreenReject ? () => Promise.reject(Error('not allowed')) : undefined}, hidden: false,
    getElementById(id) { return byId[id] || null; },
    addEventListener(type, fn) { documentListeners.set(type, fn); },
    dispatch(type, event = {}) { return documentListeners.get(type)?.({...event, type}); },
  };
  const windowListeners = new Map();
  const win = {
    location: {search: phone ? '?phone=1' : ''},
    matchMedia: () => ({matches: !isPortrait}), innerWidth: portrait ? 390 : 852, innerHeight: portrait ? 852 : 390,
    addEventListener(type, fn) { windowListeners.set(type, fn); },
    dispatch(type, event = {}) { return windowListeners.get(type)?.({...event, type}); },
    previsSetLook(x, y) { this.look = [x, y]; },
    previsReleaseLook() { this.look = [0, 0]; this.releases = (this.releases || 0) + 1; },
    previsSuspendControls() { this.suspends = (this.suspends || 0) + 1; this.look = [0, 0]; },
  };
  const screen = {orientation: {lock: lockReject ? () => Promise.reject(Error('unsupported')) : undefined}};
  const context = {window: win, document: doc, screen, navigator: {userAgent: phone ? 'iPhone' : 'Macintosh'}, URLSearchParams, Event: class {constructor(type) {this.type = type;}}, console};
  vm.runInNewContext(fs.readFileSync('web/phone.js', 'utf8'), context, {filename: 'web/phone.js'});
  return {byId, body, doc, win, screen, listeners, setOrientation(value) { isPortrait = value; }};
}

const desktop = makeHarness({phone: false});
assert.equal(desktop.win.DKYJPhoneControls.isPhone, false, 'desktop starts without phone surface');
assert.equal(desktop.body.classList.values.has('phone-layout'), false, 'desktop layout remains untouched');

const h = makeHarness({portrait: true});
const api = h.win.DKYJPhoneControls;
assert.equal(h.byId.controlMode.value, 'gamepad', 'phone script does not override the selected mode');
assert.equal(h.byId.controlMode.dispatched || 0, 0, 'phone script does not dispatch a mode change');
assert.equal(h.win.suspends, 1, 'portrait startup suspends camera controls immediately');
assert.deepEqual(Array.from(api.normalizeStick(0, 0, 50)), [0, 0], 'centered stick is neutral');
assert.deepEqual(Array.from(api.normalizeStick(2, 1, 50)), [0, 0], 'deadzone suppresses drift');
const diagonal = api.normalizeStick(100, 100, 50);
assert.ok(Math.hypot(...diagonal) <= 1.000001, 'diagonal input is clamped to unit magnitude');
assert.equal(h.byId.phonePortraitGate.hidden, false, 'portrait view shows the rotate prompt');
h.setOrientation(false);
h.win.dispatch('orientationchange');
assert.equal(h.byId.phonePortraitGate.hidden, true, 'landscape removes the rotate prompt');
assert.equal(h.byId.phoneFullscreenWide.hidden, false, 'landscape shows an accessible fullscreen action');

const pad = h.byId.phoneLookPad;
pad.dispatch('pointerdown', {pointerId: 3, clientX: 50, clientY: 50, preventDefault() {}});
assert.deepEqual(Array.from(h.win.look), [0, 0], 'starting at the stick center emits no camera input');
pad.dispatch('pointermove', {pointerId: 3, clientX: 84, clientY: 50});
assert.ok(h.win.look[0] > 0 && Math.abs(h.win.look[1]) < 1e-8, 'right stick sends horizontal look');
pad.dispatch('pointercancel', {pointerId: 3});
assert.deepEqual(Array.from(h.win.look), [0, 0], 'cancelling touch immediately zeros the look input');

pad.dispatch('pointerdown', {pointerId: 4, clientX: 50, clientY: 50, preventDefault() {}});
pad.dispatch('pointermove', {pointerId: 4, clientX: 50, clientY: 16});
h.win.dispatch('blur');
assert.deepEqual(Array.from(h.win.look), [0, 0], 'window blur releases held look input');
h.setOrientation(true);
h.win.dispatch('orientationchange');
assert.equal(h.win.suspends, 2, 'returning to portrait immediately suspends camera controls');

(async () => {
  const denied = makeHarness({portrait: true, fullscreenReject: true, lockReject: true});
  denied.setOrientation(false);
  denied.win.dispatch('orientationchange');
  await denied.byId.phoneFullscreenWide.dispatch('click');
  assert.match(denied.byId.phoneOrientationStatus.textContent, /Safari 未允许网页请求全屏或锁定横屏/);
  assert.equal(denied.win.DKYJPhoneControls.isPhone, true, 'unsupported orientation APIs do not disable phone input');
  console.log('PASS phone orientation and dual-control behavior');
})().catch(error => { console.error(error); process.exitCode = 1; });
