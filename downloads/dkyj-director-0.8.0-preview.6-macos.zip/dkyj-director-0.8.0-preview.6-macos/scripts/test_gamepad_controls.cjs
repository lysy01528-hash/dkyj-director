/* Behavioral tests for the production input adapter and web control channel. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {Input,stick,getProfile}=require('../web/gamepad.js');
const pad=()=>({connected:true,index:3,id:'TEST STANDARD PAD',mapping:'standard',axes:[0,0,0,0],buttons:Array.from({length:17},()=>({value:0,pressed:false}))});
let checks=0;
const check=(condition,message)=>{assert(condition,message);checks++;};
check(stick(.05,.06).every(v=>v===0),'drift must be zero');
check(Math.abs(Math.hypot(...stick(1,1))-1)<1e-9,'diagonals must be normalized');
check(getProfile('invalid').key==='xbox'&&getProfile('ps5').key==='ps5','profile fallback and PS5 profile');
{const m=new Input('ps5'),p=pad();m.sample(p,0);p.axes=[0,-1,1,-1];p.buttons[6].value=1;p.buttons[4].value=1;const s=m.sample(p,.05);check(s.move[1]>0&&s.move[2]<0&&s.look[0]<0&&s.look[1]>0&&s.lens<0,'PS5 dual-stick L2/L1 mapping');}
{const m=new Input('ps5'),p=pad();m.sample(p,0);p.buttons[7].value=1;p.buttons[5].value=1;const s=m.sample(p,.05);check(s.move[2]>0&&s.lens>0,'PS5 R2 raises and R1 increases focal length');}
const totals=[30,60,120].map(hz=>{const m=new Input(),p=pad();m.sample(p,0);p.axes[2]=1;let sum=0;for(let i=0;i<hz;i++)sum+=m.sample(p,1/hz).look[0];return sum;});
check(totals.every(v=>Math.abs(v+1.2)<1e-9),'turn rate must not depend on refresh rate');
{const m=new Input(),p=pad();m.sample(p,0);p.axes=[NaN,Infinity,NaN,Infinity];check([...m.sample(p,NaN).move,...m.sample(p,NaN).look].every(Number.isFinite),'invalid input');p.mapping='';check(m.sample(p,.05).reason==='unmapped','unknown mapping');}

const source=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
const els={},listeners={},intervals=[],sent=[];let now=0,pads=[pad()],focused=true,dialog=false,delayType=null,heldResponse=null,failNext=false,active=0,maxActive=0;
const events=(target,type,fn)=>(listeners[target+':'+type]||=[]).push(fn);
function el(id,tag='DIV'){return els[id]||=( {id,tagName:tag,style:{},dataset:{},hidden:false,value:'',textContent:'',innerHTML:'',disabled:false,classList:{add(){},remove(){},toggle(){}},setAttribute(k,v){this[k]=v;},removeAttribute(k){delete this[k];},setPointerCapture(){},append(){},addEventListener(type,fn){events(id,type,fn)},querySelector(){return el('knob')}} );}
const buttons=['up','down'].map(x=>{const b=el('height-'+x,'BUTTON');b.dataset.move=x;return b;});
const pitchButtons=['up','down'].map(x=>{const b=el('pitch-'+x,'BUTTON');b.dataset.look=x;return b;});
const document={body:el('body','BODY'),activeElement:{tagName:'BODY'},hidden:false,hasFocus:()=>focused,querySelector:s=>s[0]==='#'?el(s.slice(1)):s==='dialog[open]'&&dialog?{}:null,querySelectorAll:s=>s==='[data-move]'?buttons:s==='[data-look]'?pitchButtons:[],createElement:t=>el('new'+Math.random(),t.toUpperCase()),addEventListener:(t,f)=>events('document',t,f)};
const window={location:{search:'?token=test'},document,isSecureContext:true,addEventListener:(t,f)=>events('window',t,f),removeEventListener(){}};
const state={license:{plan:'pro'},connected:true,camera:'Camera_Phone',cameras:['Camera_Phone'],recording:false,playing:false,control_hold:false,project_event:1,frame:1,frame_start:1,frame_end:240,fps:24,lens:35,speed:1,camera_height:1.6};
async function fetchMock(url,options={}){
 if(!url.startsWith('/api/control'))return {ok:true,json:async()=>({...state}),blob:async()=>new Blob()};
 const body=JSON.parse(options.body);sent.push(body);active++;maxActive=Math.max(active,maxActive);
 if(body.type===delayType){delayType=null;await new Promise(resolve=>heldResponse=resolve);}
 active--;const fail=failNext;failNext=false;
 return {ok:!fail,status:fail?500:202,json:async()=>fail?{ok:false,error:'test network failure'}:{ok:true}};
}
const stored={};const localStorage={getItem:key=>stored[key]??null,setItem:(key,value)=>{stored[key]=String(value)}};
const context={window,document,location:window.location,navigator:{getGamepads:()=>pads,userAgent:'Test'},screen:{orientation:{angle:0}},fetch:fetchMock,localStorage,URLSearchParams,URL:{createObjectURL:()=>'',revokeObjectURL(){}},Blob,Math,JSON,Error,console,Date:{now:()=>now},requestAnimationFrame(){},setInterval(fn){intervals.push(fn)},setTimeout(fn,ms=0){if(ms<200)setImmediate(fn);return 0},clearTimeout(){}};context.globalThis=context;
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../web/gamepad.js'),'utf8'),context);
vm.runInNewContext(source.replace(/\n\}\)\(\);\s*$/, '\nwindow.h={render,controlFrame,sendContinuous,toggleGamepad,orientation,enableSensor:()=>{sensorOn=true;gyroReady=true;gyroLatest=[0,0,0,1]},get:()=>({gamepadMode,sensorOn,sensorPaused,pendingLook:[...pendingLook],move:[...move],generation:inputGeneration,profile:activeGamepadProfile})};\n})();'),context);
const h=window.h,settle=()=>new Promise(r=>setImmediate(r));
function startupProfile(value){
 const bootStore={getItem:()=>value,setItem(){}};
 const bootWindow={...window};
 const boot={...context,window:bootWindow,localStorage:bootStore};bootWindow.document=document;bootWindow.DKYJGamepad=context.window.DKYJGamepad;boot.globalThis=boot;
 vm.runInNewContext(source.replace(/\n\}\)\(\);\s*$/, '\nwindow.h={get:()=>({profile:activeGamepadProfile})};\n})();'),boot);
 return boot.window.h.get().profile;
}
async function tick(ms=50){now+=ms;h.controlFrame(now);h.sendContinuous();for(let i=0;i<8;i++)await settle();}
async function arm(){h.render({...state});h.toggleGamepad();await tick();h.render({...state});await tick();}
const neutral=()=>{pads[0].axes=[0,0,0,0];pads[0].buttons.forEach(b=>{b.value=0;b.pressed=false;});};
const input=()=>sent.filter(x=>x.type==='input').at(-1);
const emit=(target,type,event={})=>(listeners[target+':'+type]||[]).forEach(f=>f(event));

(async()=>{
 check(h.get().profile==='xbox','Xbox is the default profile');
 emit('gamepadProfile','change',{target:{value:'ps5'}});check(h.get().profile==='ps5'&&stored['dkyj.gamepad.profile']==='ps5','PS5 profile is selectable and remembered');check(el('gamepadGuideTitle').textContent.includes('PS5')&&el('gamepadTriggerLabel').textContent==='L2 / R2'&&el('gamepadBumperLabel').textContent==='L1 / R1'&&el('gamepadGuideNote').textContent.includes('PS5 使用标准映射')&&el('height-up').title.includes('R2'),'PS5 labels and standard-mapping note are shown');
 emit('gamepadProfile','change',{target:{value:'invalid'}});check(h.get().profile==='xbox'&&stored['dkyj.gamepad.profile']==='xbox','invalid profile falls back to Xbox');
 await settle();h.render({...state});pads=[];h.toggleGamepad();await tick();check(h.get().gamepadMode==='waiting','click before hardware should wait');check(!sent.some(x=>x.type==='resume_live'),'no hardware must not move camera');h.toggleGamepad();await tick();pads=[pad()];
 h.enableSensor();await arm();check(h.get().gamepadMode==='active'&&!h.get().sensorOn,'arm must resume and disable gyro');
 pads[0].axes=[0,-1,1,-1];pads[0].buttons[7].value=1;await tick();
 check(input().move[1]>0&&input().move[2]>0&&input().look[0]<0&&input().look[1]>0,'move/yaw/pitch/height mapping');
 pads[0].buttons[7].value=0;pads[0].buttons[6].value=1;await tick();check(input().move[2]<0,'LT lowers camera');
 neutral();await tick();check(input().move.every(v=>v===0)&&input().look.every(v=>v===0),'neutral sends zero');
 pads[0].buttons[5].value=1;for(let i=0;i<8;i++)await tick();check(sent.some(x=>x.type==='settings'&&x.lens>35),'RB sends focal length');neutral();await tick();
 pads[0].axes[2]=1;delayType='input';const switchStart=sent.length;await tick();check(heldResponse,'delayed request exists');emit('gamepadProfile','change',{target:{value:'ps5'}});check(h.get().gamepadMode==='off','active profile switch pauses controller');heldResponse();await tick();await tick();const afterInputs=sent.slice(switchStart).filter(x=>x.type==='input'),finalInput=afterInputs.at(-1);check(finalInput?.move.every(v=>v===0)&&finalInput?.look.every(v=>v===0)&&h.get().pendingLook.every(v=>v===0),'profile switch sends zero without reversing old look');
 pads[0].axes[0]=1;await arm();await tick();check(h.get().gamepadMode==='active'&&input().move.every(v=>v===0),'re-enable with held stick stays centered');neutral();await tick();pads[0].axes[0]=1;await tick();check(input().move[0]>0,'PS5 resumes after neutral center');
 emit('gamepadProfile','change',{target:{value:'xbox'}});check(h.get().gamepadMode==='off'&&el('gamepadTriggerLabel').textContent==='LT / RT'&&el('height-up').title.includes('RT'),'switching back restores Xbox labels');neutral();
 neutral();await arm();pads[0].axes[0]=1;await tick();emit('window','blur');await tick();check(h.get().gamepadMode==='off'&&input().move.every(v=>v===0),'blur pauses and zeros');
 neutral();await arm();pads[0].axes[0]=1;await tick();emit('window','gamepaddisconnected',{gamepad:pads[0]});pads=[];await tick();check(h.get().gamepadMode==='off'&&input().move.every(v=>v===0),'disconnect pauses');
 pads=[pad()];pads[0].axes[0]=1;await tick();check(h.get().gamepadMode==='off','reconnect must not auto-enable');await arm();await tick();check(input().move.every(v=>v===0),'held stick after rearm must wait for neutral');neutral();await tick();pads[0].axes[0]=1;await tick();check(input().move[0]>0,'neutral then movement resumes');
 neutral();el('recordBtn').onclick();await tick();state.recording=true;state.playing=true;state.camera='Camera_Take_01';h.render({...state});pads[0].axes[0]=1;await tick();check(h.get().gamepadMode==='active'&&input().move[0]>0&&sent.some(x=>x.type==='record'),'record retains gamepad camera input');
 const recordingSwitchStart=sent.length;emit('gamepadProfile','change',{target:{value:'ps5'}});const recordingSwitchEvents=sent.slice(recordingSwitchStart);check(h.get().gamepadMode==='off'&&!recordingSwitchEvents.some(x=>['record','stop','resume_live'].includes(x.type)),'recording profile switch only pauses and zeros');neutral();await arm();neutral();await tick();pads[0].axes[0]=1;await tick();check(h.get().gamepadMode==='active'&&input().move[0]>0,'recording re-enable resumes gamepad movement');
 el('stopBtn').onclick();await tick();state.recording=false;state.playing=false;state.control_hold=true;h.render({...state});await tick();check(h.get().gamepadMode==='off','stop recording releases controller');state.control_hold=false;state.camera='Camera_Phone';
 neutral();await arm();buttons[0].onpointerdown({pointerId:1});await tick();await tick();check(h.get().gamepadMode==='active'&&input().move[2]===0,'on-screen height cannot steal gamepad control');h.toggleGamepad();await tick();emit('controlMode','change',{target:{value:'phone'}});await tick();await tick();buttons[0].onpointerdown({pointerId:1});await tick();check(input().move[2]===1,'height works after explicit phone selection');emit('height-up','pointerup');await tick();check(input().move[2]===0,'height release stops');
 h.enableSensor();pitchButtons[0].onpointerdown({pointerId:1});await tick();check(input().look[1]>0,'on-screen tilt up');check(!h.get().sensorOn,'on-screen tilt disables conflicting absolute gyro input');emit('pitch-up','pointercancel');await tick();check(input().look[1]===0,'tilt cancel stops');
 neutral();await arm();dialog=true;await tick();check(h.get().gamepadMode==='off','opening project/welcome dialog pauses controller');dialog=false;
 neutral();await arm();pads[0].axes[0]=1;failNext=true;await tick();await tick();check(h.get().gamepadMode==='off','network failure disables controller');
 neutral();await arm();h.render({...state,project_event:2});await tick();check(h.get().gamepadMode==='off','project change must stop gamepad');
 check(startupProfile('ps5')==='ps5','PS5 profile restores from localStorage at startup');
 check(startupProfile('bogus')==='xbox','invalid stored profile falls back to Xbox at startup');
 check(maxActive===1,'gamepad must share serialized control channel');
 console.log(JSON.stringify({ok:true,checks,maxConcurrentControlRequests:maxActive,kind:'production JS with synthetic input'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
