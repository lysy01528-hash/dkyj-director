const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('web/index.html','utf8'),source=fs.readFileSync('web/welcome.js','utf8');
function boot(storage={}){
 const ids=new Map();
 class Node{
  constructor(tag='div'){this.tag=tag;this.children=[];this.value='';this.hidden=false;this.classList={toggle(){}};this.listeners={};}
  set id(v){this._id=v;ids.set(v,this)}get id(){return this._id}
  append(...nodes){this.children.push(...nodes)} add(n){this.children.push(n)}replaceChildren(...n){this.children=n}
  addEventListener(n,f){this.listeners[n]=f}setAttribute(k,v){this[k]=v}getAttribute(k){return this[k]}
  focus(){}select(){}showModal(){this.open=true}close(){this.open=false}
 }
 for(const [,id] of html.matchAll(/id="([^"]+)"/g)){const n=new Node();n.id=id}
 const calls=[],localStorage={getItem:k=>storage[k]??null,setItem:(k,v)=>storage[k]=v};
 const document={getElementById:id=>{assert(ids.has(id),'Missing HTML element '+id);return ids.get(id)},createElement:t=>new Node(t),createTextNode:t=>t,querySelectorAll:()=>[]};
 const window={dispatchEvent(){},previsControl:body=>calls.push(body)},context={document,window,localStorage,navigator:{userAgent:'Test'},location:{search:'',hostname:'localhost'},URL,URLSearchParams,CustomEvent:class{},Option:class{constructor(text,value){this.text=text;this.value=value}},Date,Math};
 vm.runInNewContext(source,context);const state={connected:true,recording:false,projects:{active:'room',items:[{id:'room',name:'Room',available:true}]},briefs:{revision:0,items:[]}};window.previsWelcome.render(state);
 return {ids,calls,window,state,storage};
}
function submit(b,text='一艘小船，红色主角跑上甲板，镜头跟随。'){b.ids.get('briefAnswer').value=text;b.ids.get('briefForm').onsubmit({preventDefault(){}})}
let b=boot();assert.equal(b.ids.get('briefModelDetail').checked,false);submit(b);assert.equal(b.calls.length,1);assert.equal(b.calls[0].prompt,'一艘小船，红色主角跑上甲板，镜头跟随。');assert.equal(b.calls[0].model_detail,'simple');assert.equal(b.calls[0].model_detail_explicit,false);assert(!('characters' in b.calls[0]));assert.equal(b.ids.get('briefNext').textContent,'开始建模 →');
submit(b);assert.equal(b.calls.length,1,'double-click while pending must not duplicate');
b=boot();b.ids.get('briefModelDetail').checked=true;b.ids.get('briefModelDetail').onchange();submit(b,'房间，详细制作门框');assert.equal(b.calls[0].model_detail,'detailed');assert.equal(b.calls[0].model_detail_explicit,true);
const reloaded=boot(b.storage);assert.equal(reloaded.ids.get('briefModelDetail').checked,false,'new task must not inherit detail');assert.equal(reloaded.ids.get('briefAnswer').value,'房间，详细制作门框');
b.state.briefs={revision:1,items:[{...b.calls[0],status:'waiting',messages:[],modeling:{requires_confirmation:false}}]};b.window.previsWelcome.render(b.state);assert.equal(b.ids.get('briefModelDetail').checked,false);assert.equal(b.ids.get('briefAnswer').value,'');
b=boot({'dkyj-brief-draft':JSON.stringify(['legacy','two','walk','follow'])});assert.equal(b.ids.get('briefAnswer').value,'legacy\ntwo\nwalk\nfollow');assert.equal(b.ids.get('briefModelDetail').checked,false);
b=boot();submit(b,'');assert.equal(b.calls.length,0);b.state.connected=false;b.window.previsWelcome.render(b.state);submit(b);assert.equal(b.calls.length,0);
b=boot();submit(b,'需要细节建模的场景');assert.equal(b.calls[0].model_detail,'simple','text alone must never opt in');
console.log('MODELING_UI_OK single-submit/default-fixed/detail-opt-in/draft-migration/no-double-submit/offline');
