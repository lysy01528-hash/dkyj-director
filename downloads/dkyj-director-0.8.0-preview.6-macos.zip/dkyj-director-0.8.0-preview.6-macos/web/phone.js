/* iPhone Safari landscape camera surface and independent right look stick. */
(() => {
  'use strict';

  const params = new URLSearchParams(window.location.search);
  const isPhone = params.get('phone') === '1' || /iPhone|iPod/i.test(navigator.userAgent || '');
  const body = document.body;
  const pad = document.getElementById('phoneLookPad');
  const nub = document.getElementById('phoneLookStick');
  const gate = document.getElementById('phonePortraitGate');
  const fullscreenButton = document.getElementById('phoneFullscreen');
  const fullscreenWideButton = document.getElementById('phoneFullscreenWide');
  const orientationStatus = document.getElementById('phoneOrientationStatus');
  let pointerId = null;
  let lastLandscape = null;

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const normalizeStick = (x, y, radius, deadzone = 0.12) => {
    const safeRadius = Math.max(1, Number(radius) || 1);
    let nx = clamp((Number(x) || 0) / safeRadius, -1, 1);
    let ny = clamp((Number(y) || 0) / safeRadius, -1, 1);
    const length = Math.hypot(nx, ny);
    if (length <= deadzone) return [0, 0];
    const strength = (Math.min(1, length) - deadzone) / (1 - deadzone);
    return [nx / length * strength, ny / length * strength];
  };
  const setLook = (x, y) => {
    if (typeof window.previsSetLook === 'function') window.previsSetLook(x, y);
  };
  const releaseLook = () => {
    pointerId = null;
    if (nub) nub.style.transform = '';
    if (typeof window.previsReleaseLook === 'function') window.previsReleaseLook();
    else setLook(0, 0);
  };

  const updateOrientation = () => {
    if (!isPhone || !gate) return;
    const landscape = window.matchMedia?.('(orientation: landscape)').matches ?? window.innerWidth > window.innerHeight;
    gate.hidden = landscape;
    if (fullscreenWideButton) fullscreenWideButton.hidden = !landscape;
    body.classList.toggle('phone-landscape', landscape);
    if (!landscape && lastLandscape !== false) {
      releaseLook();
      window.previsSuspendControls?.();
    }
    lastLandscape = landscape;
  };

  async function requestPhoneView() {
    let fullscreenOk = false;
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
        fullscreenOk = true;
      }
    } catch (_) { /* Safari may reject fullscreen unless initiated from an installed web app. */ }

    let orientationOk = false;
    try {
      if (screen.orientation?.lock) {
        await screen.orientation.lock('landscape');
        orientationOk = true;
      }
    } catch (_) { /* iPhone Safari does not expose or allow orientation locking in many contexts. */ }

    if (orientationStatus) {
      orientationStatus.textContent = orientationOk
        ? '已请求横屏显示；若屏幕未旋转，请手动横过手机。'
        : fullscreenOk
          ? '已进入全屏。网页无法锁定横屏，请手动横过手机。'
          : 'Safari 未允许网页请求全屏或锁定横屏。请手动横过手机；横屏后仍可双摇杆运镜。';
    }
    updateOrientation();
  }

  if (!isPhone) {
    window.DKYJPhoneControls = {normalizeStick, isPhone: false};
    return;
  }

  body.classList.add('phone-layout');

  if (pad && nub) {
    pad.addEventListener('pointerdown', event => {
      event.preventDefault();
      pointerId = event.pointerId;
      pad.setPointerCapture?.(pointerId);
      pad.classList.add('active');
      updateStick(event);
    });

    const updateStick = event => {
      if (pointerId !== event.pointerId) return;
      const rect = pad.getBoundingClientRect();
      const radius = Math.max(20, Math.min(rect.width, rect.height) * 0.34);
      const dx = event.clientX - (rect.left + rect.width / 2);
      const dy = event.clientY - (rect.top + rect.height / 2);
      const [x, y] = normalizeStick(dx, dy, radius);
      nub.style.transform = `translate(calc(-50% + ${x * radius}px), calc(-50% + ${y * radius}px))`;
      setLook(x, y);
    };

    pad.addEventListener('pointermove', updateStick);
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => pad.addEventListener(type, event => {
      if (pointerId === null || (event.pointerId !== undefined && event.pointerId !== pointerId)) return;
      pad.classList.remove('active');
      releaseLook();
    }));
  }

  fullscreenButton?.addEventListener('click', requestPhoneView);
  fullscreenWideButton?.addEventListener('click', requestPhoneView);
  window.addEventListener('resize', updateOrientation, {passive: true});
  window.addEventListener('orientationchange', updateOrientation, {passive: true});
  window.addEventListener('blur', releaseLook);
  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseLook(); });
  window.addEventListener('pagehide', releaseLook);
  updateOrientation();

  window.DKYJPhoneControls = {normalizeStick, requestPhoneView, releaseLook, isPhone: true};
})();
