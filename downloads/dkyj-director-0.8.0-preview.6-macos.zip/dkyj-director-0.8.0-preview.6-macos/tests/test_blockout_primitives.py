"""Blender-background acceptance checks for the fixed blockout character factory."""

import sys
from pathlib import Path

import bpy

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'addon'))
from blockout_primitives import create_character, validate_character


def close(actual, expected, epsilon=1e-5):
    assert abs(actual - expected) < epsilon, (actual, expected)


scene = bpy.context.scene
other_scene = bpy.data.scenes.new('Blockout_OnlyTargetScene')
baseline_objects = set(bpy.data.objects)
root = create_character('Blockout_TestActor', (2, -1, 3), 2.0,
                        (0.2, 0.4, 0.6), scene=other_scene)
assert root.get('dkyj_character_id') == 'Blockout_TestActor'
assert root.get('dkyj_blockout_version') == '1'
assert root.name in other_scene.objects
assert root.name not in scene.objects
assert len(set(bpy.data.objects) - baseline_objects) == 3
assert validate_character(root) is True

body, head = sorted(root.children, key=lambda ob: ob.get('dkyj_character_part'))
assert body.get('dkyj_character_part') == 'body'
assert head.get('dkyj_character_part') == 'head'
assert body.type == head.type == 'MESH'
close(body.dimensions.x, 2.0 * 0.26)
close(body.dimensions.y, 2.0 * 0.18)
close(body.dimensions.z, 2.0 * 0.76)
close(head.dimensions.x, 2.0 * 0.24)
close(head.dimensions.y, 2.0 * 0.24)
close(head.dimensions.z, 2.0 * 0.24)
close(body.location.z - body.dimensions.z / 2, 0.0)
close(head.location.z + head.dimensions.z / 2, 2.0)
assert len(body.data.vertices) == 8 and len(body.data.polygons) == 6
assert len(head.data.vertices) == 114 and len(head.data.polygons) == 128
assert not any(poly.use_smooth for poly in head.data.polygons)
assert len(body.data.materials[0].node_tree.nodes) == 0
assert body.data.materials[0] == head.data.materials[0]
for actual, expected in zip(body.data.materials[0].diffuse_color, (0.2, 0.4, 0.6, 1.0)):
    close(actual, expected)

# The root supports whole-character movement and turning animation.
root.location = (0, 0, 0)
root.rotation_euler.z = 0
root.keyframe_insert(data_path='location', frame=1)
root.keyframe_insert(data_path='rotation_euler', frame=1)
root.location = (4, 2, 0)
root.rotation_euler.z = 1.2
root.keyframe_insert(data_path='location', frame=20)
root.keyframe_insert(data_path='rotation_euler', frame=20)
scene.frame_set(20)
assert tuple(round(value, 3) for value in root.location) == (4.0, 2.0, 0.0)
assert round(root.rotation_euler.z, 3) == 1.2

# A duplicate ID is rejected without replacing or deleting the existing rig.
existing_root = bpy.data.objects.get('Blockout_TestActor')
old_body = bpy.data.objects.get('Blockout_TestActor_Body')
try:
    create_character('Blockout_TestActor', scene=scene)
    raise AssertionError('duplicate name was accepted')
except ValueError:
    pass
assert bpy.data.objects.get('Blockout_TestActor') is existing_root
assert bpy.data.objects.get('Blockout_TestActor_Body') is old_body
assert len(existing_root.children) == 2

# Bad inputs are rejected before creating even one datablock.
for kwargs in ({'height': 0}, {'height': float('nan')}, {'color': (1, 0, -0.1)},
               {'location': (0, float('inf'), 0)}, {'name': '   '}, {'scene': object()}):
    before = (set(bpy.data.objects), set(bpy.data.meshes), set(bpy.data.materials))
    bad_name = kwargs.get('name', 'Blockout_InvalidActor')
    try:
        create_character(bad_name, **{key: value for key, value in kwargs.items() if key != 'name'})
        raise AssertionError(f'bad input accepted: {kwargs}')
    except ValueError:
        pass
    assert (set(bpy.data.objects), set(bpy.data.meshes), set(bpy.data.materials)) == before

# Validation refuses a third child mesh and leaves the existing rig untouched.
arm_mesh = bpy.data.meshes.new('Blockout_TestArmMesh')
arm_mesh.from_pydata([(-0.1, 0, 0), (0.1, 0, 0), (0, 0, 0.5)], [], [(0, 1, 2)])
arm = bpy.data.objects.new('Blockout_TestArm', arm_mesh)
arm.parent = root
other_scene.collection.objects.link(arm)
try:
    validate_character(root)
    raise AssertionError('validator accepted an extra arm')
except ValueError as error:
    assert 'exactly two' in str(error)
assert bpy.data.objects.get('Blockout_TestActor') is existing_root
assert len(root.children) == 3

print('BLOCKOUT_PRIMITIVES_BLENDER_TESTS_OK fixed-shape/color/scene/motion/no-overwrite/input-validation/extra-child')
