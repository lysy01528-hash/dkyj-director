"""Regression tests for timestamps in the exported spatial camera route."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import compose_overview  # noqa: E402


class _Camera:
    name = "Camera_Phone"
    data = SimpleNamespace(lens=33.0)

    class _Matrix:
        translation = (0.0, 0.0, 0.0)

        @staticmethod
        def to_quaternion():
            return SimpleNamespace(x=0.0, y=0.0, z=0.0, w=1.0)

    matrix_world = _Matrix()


class SpatialTimestampTests(unittest.TestCase):
    def test_unaligned_end_frame_gets_its_own_timestamp(self):
        scene = SimpleNamespace(
            name="Test Scene",
            render=SimpleNamespace(fps=24, fps_base=1.0),
            unit_settings=SimpleNamespace(scale_length=1.0),
            frame_set=lambda frame: None,
            get=lambda key, default=None: default,
        )
        camera = _Camera()
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "route.json"
            compose_overview.write_zones_json([], scene, camera, output, 1, 26)
            samples = json.loads(output.read_text(encoding="utf-8"))["route_samples"]

        self.assertEqual([sample["frame"] for sample in samples], [1, 13, 25, 26])
        self.assertEqual([sample["time_seconds"] for sample in samples], [0.0, 0.5, 1.0, 1.04167])

    def test_aligned_end_frame_is_not_duplicated(self):
        samples = compose_overview._route_sample_frames(1, 25, 24.0)
        self.assertEqual(samples, [(1, 0.0), (13, 0.5), (25, 1.0)])


if __name__ == "__main__":
    unittest.main()
