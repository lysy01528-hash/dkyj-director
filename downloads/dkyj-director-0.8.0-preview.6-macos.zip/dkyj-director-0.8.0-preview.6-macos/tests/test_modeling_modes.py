import importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'addon'))
from scene_briefs import BriefStore

class ModelingTests(unittest.TestCase):
    def make(self,root,**kw):
        store=BriefStore(root);b=store.create(dict(id='brief-modeling',scene='房间',characters='两人',action='走过门口',**kw));return store,b
    def test_default_and_reload(self):
        with tempfile.TemporaryDirectory() as root:
            s,b=self.make(root);self.assertEqual(b['modeling']['mode'],'simple');self.assertIn('五官',b['modeling']['characters']);self.assertFalse(b['modeling']['requires_confirmation'])
            self.assertEqual(BriefStore(root).find(b['id'])['model_detail'],'simple')
    def test_explicit_detail_and_reply(self):
        with tempfile.TemporaryDirectory() as root:
            s,b=self.make(root,model_detail='detailed',model_detail_explicit=True)
            self.assertFalse(b['modeling']['requires_confirmation'])
            s.reply(dict(id=b['id'],message='改回简化',model_detail='simple'))
            self.assertEqual(BriefStore(root).find(b['id'])['model_detail'],'simple')
    def test_description_never_enables_detail(self):
        with tempfile.TemporaryDirectory() as root:
            s,b=self.make(root,camera='需要细节建模再跟拍')
            self.assertFalse(b['modeling']['requires_confirmation'])
            self.assertEqual(b['modeling']['preset'],'blockout-v1')
            self.assertEqual(b['modeling']['character_template']['visible_meshes'],2)
            self.assertFalse(b['modeling']['character_template']['limbs'])
            s.update(dict(id=b['id'],status='working'))
    def test_followup_words_do_not_change_mode(self):
        with tempfile.TemporaryDirectory() as root:
            s,b=self.make(root);s.reply(dict(id=b['id'],message='这次需要细节建模并加桌子'))
            s=BriefStore(root);self.assertFalse(s.find(b['id'])['modeling']['requires_confirmation'])
            self.assertEqual(s.find(b['id'])['model_detail'],'simple')
            s.reply(dict(id=b['id'],message='已打开详细建模',model_detail='detailed'))
            self.assertEqual(BriefStore(root).find(b['id'])['model_detail'],'detailed')
    def test_single_prompt_roundtrip_and_opt_in(self):
        with tempfile.TemporaryDirectory() as root:
            s=BriefStore(root);text='小船上的红色主角跑上甲板。'*200
            b=s.create(dict(id='brief-one-prompt',prompt=text))
            self.assertEqual(b['prompt'],text);self.assertEqual(b['characters'],'')
            self.assertEqual(BriefStore(root).find(b['id'])['prompt'],text)
            with self.assertRaises(ValueError):s.create(dict(id='brief-no-optin',prompt='x',model_detail='detailed'))
            self.assertEqual(len(s.data['items']),1)
    def test_invalid_does_not_mutate(self):
        with tempfile.TemporaryDirectory() as root:
            s=BriefStore(root)
            with self.assertRaises(ValueError):s.create(dict(id='brief-invalid',scene='x',characters='y',action='z',model_detail='ultra'))
            self.assertFalse(s.data['items'])
            s,b=self.make(root);before=json.dumps(s.data)
            with self.assertRaises(ValueError):s.reply(dict(id=b['id'],message='x',model_detail='ultra'))
            self.assertEqual(json.dumps(s.data),before)
    def test_legacy_read_does_not_overwrite_file(self):
        with tempfile.TemporaryDirectory() as root:
            s,b=self.make(root)
            for key in ('model_detail','model_detail_explicit','modeling'):b.pop(key)
            s.save();raw=s.path.read_bytes();loaded=BriefStore(root)
            self.assertEqual(loaded.find(b['id'])['model_detail'],'simple');self.assertEqual(s.path.read_bytes(),raw)
    def test_mcp_stops_before_project_mutation(self):
        class FakeMCP:
            def __init__(self,*a):pass
            def tool(self):return lambda f:f
        fake=types.ModuleType('mcp.server.fastmcp');fake.FastMCP=FakeMCP
        client=types.ModuleType('director_client');calls=[]
        with tempfile.TemporaryDirectory() as root:
            _,brief=self.make(root,camera='详细走位，细节建模')
            brief['modeling']['requires_confirmation']=True
            client.state=lambda:{'recording':False,'briefs':{'items':[brief]}}
            client.command=lambda e:calls.append(e) or {}
            with patch.dict(sys.modules,{'mcp.server.fastmcp':fake,'director_client':client}):
                spec=importlib.util.spec_from_file_location('modeling_agent_test',ROOT/'scripts/agent_server.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
                result=module.prepare_brief(brief['id'],'测试项目')
                self.assertEqual(result['status'],'needs_input');self.assertEqual([c['type'] for c in calls],['brief_update'])
                brief['modeling']['requires_confirmation']=False;calls.clear()
                client.state=lambda:{'recording':False,'briefs':{'items':[brief]},'projects':{'active':'p'}}
                module.state=client.state;module.command=lambda e:calls.append(e) or {'projects':{'active':'p'}}
                result=module.prepare_brief(brief['id'],'测试项目')
                self.assertEqual(result['modeling']['mode'],'simple');self.assertEqual(calls[0]['type'],'project_create')
if __name__=='__main__':unittest.main()
