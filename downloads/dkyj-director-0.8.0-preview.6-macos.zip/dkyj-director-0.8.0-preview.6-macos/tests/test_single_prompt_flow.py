"""Real Blender service integration: one prompt and the fixed character API."""
from pathlib import Path
import sys,tempfile
import bpy
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_deleted_data import DeletedDataTests
from scene_briefs import BriefStore
from blockout_primitives import validate_character
fixture=DeletedDataTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory() as root:
  s=fixture.s;s.briefs=BriefStore(root)
  s.process({'type':'brief_create','id':'brief-single-flow','prompt':'小船上红色主角跑出船舱，飞机飞过。'})
  b=s.briefs.find('brief-single-flow')
  assert b['status']=='waiting' and b['modeling']['preset']=='blockout-v1' and b['characters']==''
  s.process({'type':'blockout_character','name':'SinglePromptActor','location':[1,2,0],'height':1.8,'color':[.8,.1,.1]})
  actor=fixture.scene.objects['SinglePromptActor'];validate_character(actor)
  assert len(actor.children)==2 and s.blockout_result['name']==actor.name
  assert s.blockout_event==1
  try:s.process({'type':'blockout_character','name':'InvalidActor','height':-1})
  except ValueError:pass
  else:raise AssertionError('negative height accepted')
  assert s.blockout_event==2 and s.blockout_result is None
  assert 'InvalidActor' not in fixture.scene.objects
  project=Path(root)/'test.blend';project.touch()
  s.projects=SimpleNamespace(entry=lambda _:None,path=lambda _:project)
  s.briefs.update({'id':b['id'],'status':'working','project_id':'test'})
  extra=bpy.data.objects.new('ForbiddenArm',None);fixture.scene.collection.objects.link(extra);extra.parent=actor
  try:s.process({'type':'brief_update','id':b['id'],'status':'ready','verification':'test'})
  except ValueError:pass
  else:raise AssertionError('extra limb passed completion')
  assert b['status']=='working'
  bpy.data.objects.remove(extra,do_unlink=True)
  s.process({'type':'brief_update','id':b['id'],'status':'ready','verification':'fixed template verified'})
  assert b['status']=='ready'
  print('SINGLE_PROMPT_SERVICE_FLOW_OK')
finally:fixture.tearDown()
