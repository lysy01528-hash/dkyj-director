"""Blender regressions for managed takes, idempotent commands and input modes.

Run with:
  blender --background --factory-startup --python-exit-code 1 \
    --python tests/test_capture_session.py
All Blender data and export snapshots are disposable fixtures.
"""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import bpy

ROOT = Path(__file__).resolve().parents[1]


class FakeLicense:
    def is_pro(self):
        return True

    def status(self):
        return {"plan": "pro", "is_pro": True}


def load_disposable_fixture():
    spec = importlib.util.spec_from_file_location(
        "capture_deleted_fixture", ROOT / "tests" / "test_deleted_data.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fixture = module.DeletedDataTests()
    fixture.setUp()
    fixture.module = module.module
    fixture.s._license = FakeLicense()
    return fixture


class PendingProcess:
    def __init__(self, args, **kwargs):
        self.args = list(args)
        self.returncode = None

    def poll(self):
        return None


class CaptureSessionTests(unittest.TestCase):
    def setUp(self):
        self.fixture = load_disposable_fixture()
        self.s = self.fixture.s
        self.scene = self.fixture.scene

    def tearDown(self):
        self.fixture.tearDown()

    def process(self, event):
        return self.s.process(event)

    def record_with_motion(self, client="phone"):
        self.process({"type": "record", "client_id": client})
        take = self.s.recording_camera()
        self.assertIsNotNone(take)
        start = self.scene.frame_current
        self.scene.frame_set(start + 1)
        take.location.x += 1.25
        take.data.lens += 11
        self.s.record_key()
        self.process({"type": "stop", "client_id": client})
        return take, start

    def test_ten_record_stop_resume_cycles_keep_single_managed_camera(self):
        phone = next(obj for obj in self.scene.objects if obj.name == "Camera_Phone")
        for index in range(10):
            self.scene.frame_set(1 + index * 3)
            self.process({"type": "record", "client_id": "phone"})
            self.assertTrue(self.s.recording)
            take = self.s.recording_camera()
            self.scene.frame_set(self.scene.frame_current + 1)
            take.location.x += 0.25
            take.data.lens += 1
            self.s.record_key()
            self.process({"type": "stop", "client_id": "phone"})
            managed = [obj for obj in self.scene.objects if obj.get("dkyj_managed_take")]
            self.assertEqual(len(managed), 1)
            self.process({"type": "resume_live", "client_id": "phone"})
            self.assertIs(self.scene.camera, phone)
        self.assertEqual(len([obj for obj in self.scene.objects if obj.type == "CAMERA"]), 2)

    def test_existing_user_camera_take_and_action_are_preserved(self):
        data = bpy.data.cameras.new("UserTakeData")
        old = bpy.data.objects.new("Camera_Take_User_Keep", data)
        self.scene.collection.objects.link(old)
        old.rotation_mode = "QUATERNION"
        old.location.x = 4.0
        old.keyframe_insert(data_path="location", frame=1)
        old.location.x = 7.0
        old.keyframe_insert(data_path="location", frame=9)
        old["previs_take_start"] = 1
        old["previs_take_end"] = 9
        action = old.animation_data.action
        action_name = action.name
        original_data = old.data
        self.scene.frame_set(1)
        before_start = old.location.x
        self.scene.frame_set(9)
        before_end = old.location.x

        self.scene.frame_set(1)
        self.process({"type": "record", "client_id": "phone"})
        take = self.s.recording_camera()
        self.scene.frame_set(2)
        take.location.x += 0.1
        take.data.lens += 2
        self.s.record_key()
        self.process({"type": "stop", "client_id": "phone"})

        self.assertIs(self.scene.objects.get(old.name), old)
        self.assertIs(old.data, original_data)
        self.assertIs(old.animation_data.action, action)
        self.assertEqual(action.name, action_name)
        self.scene.frame_set(1)
        self.assertAlmostEqual(old.location.x, before_start, places=4)
        self.scene.frame_set(9)
        self.assertAlmostEqual(old.location.x, before_end, places=4)
        self.assertEqual(old["previs_take_start"], 1)
        self.assertEqual(old["previs_take_end"], 9)

    def test_deleted_managed_take_is_recreated(self):
        take, _ = self.record_with_motion()
        name = take.name
        bpy.data.objects.remove(take, do_unlink=True)
        phone = next(obj for obj in self.scene.objects if obj.name == "Camera_Phone")
        self.scene.camera = phone
        self.process({"type": "resume_live", "client_id": "phone"})
        self.process({"type": "record", "client_id": "phone"})
        replacement = self.s.recording_camera()
        self.assertIsNotNone(replacement)
        self.assertTrue(replacement.get("dkyj_managed_take"))
        self.assertIsNotNone(self.s.recorded_take_info())
        self.assertEqual(self.s.recorded_take_info()["name"], name)
        self.process({"type": "stop", "client_id": "phone"})

    def test_zoom_translation_and_rotation_are_keyed_and_play_seek_reselect_take(self):
        take, start = self.record_with_motion()
        end = start + 1
        self.assertNotEqual(take.location.x, 0.0)
        self.scene.frame_set(start)
        start_lens = take.data.lens
        self.scene.frame_set(end)
        end_lens = take.data.lens
        self.assertNotEqual(start_lens, end_lens)
        self.assertTrue(take.animation_data and take.animation_data.action)
        self.assertTrue(take.data.animation_data and take.data.animation_data.action)

        self.process({"type": "resume_live", "client_id": "phone"})
        phone = self.scene.camera
        self.assertEqual(phone.name, "Camera_Phone")
        self.process({"type": "play", "client_id": "phone"})
        self.assertIs(self.scene.camera, take)
        self.process({"type": "pause", "client_id": "phone"})
        self.process({"type": "resume_live", "client_id": "phone"})
        self.assertEqual(self.scene.camera.name, "Camera_Phone")
        self.process({"type": "seek", "frame": end, "client_id": "phone"})
        self.assertIs(self.scene.camera, take)
        self.assertEqual(self.scene.frame_current, end)

    def test_duplicate_record_request_does_not_replace_recorded_motion(self):
        event = {"type": "record", "client_id": "phone", "request_id": "record-once"}
        self.process(event)
        take = self.s.recording_camera()
        self.scene.frame_set(2)
        take.location.x = 3.25
        take.rotation_euler.z = 0.4
        take.data.lens = 61.0
        self.s.record_key()
        self.process({"type": "stop", "client_id": "phone"})
        self.assertTrue(take.animation_data and take.animation_data.action)
        self.process(event)
        self.assertFalse(self.s.recording)
        self.assertIs(self.scene.camera, take)
        self.scene.frame_set(2)
        self.assertAlmostEqual(take.location.x, 3.25, places=4)
        self.assertAlmostEqual(take.data.lens, 61.0, places=3)
        self.assertGreater(abs(take.rotation_euler.z), 0.1)

    def test_export_names_are_unique_for_same_second(self):
        self.record_with_motion()
        with tempfile.TemporaryDirectory() as temp_dir:
            # Module.TAKES belongs to the backend module used by this fixture.
            webcam = self.fixture.module
            previous_takes = webcam.TAKES
            webcam.TAKES = Path(temp_dir)
            try:
                with patch.object(webcam.time, "strftime", return_value="20260916_120000"), \
                     patch.object(webcam.subprocess, "Popen", PendingProcess):
                    self.s.begin_export(mode="pov")
                    first_snapshot = Path(self.s.export_process.args[3])
                    first_output = Path(self.s.export_process.args[self.s.export_process.args.index("--") + 1])
                    self.assertTrue(first_snapshot.exists())
                    first_snapshot.write_bytes(b"first snapshot stays untouched")
                    self.s.export_process = None
                    self.s.export_log.close()
                    self.s.export_log = None
                    self.s.begin_export(mode="pov")
                    second_snapshot = Path(self.s.export_process.args[3])
                    second_output = Path(self.s.export_process.args[self.s.export_process.args.index("--") + 1])
                    self.assertNotEqual(first_snapshot, second_snapshot)
                    self.assertNotEqual(first_output, second_output)
                    self.assertEqual(first_snapshot.read_bytes(), b"first snapshot stays untouched")
                    self.assertTrue(second_snapshot.exists())
            finally:
                if self.s.export_log:
                    self.s.export_log.close()
                    self.s.export_log = None
                self.s.export_process = None
                webcam.TAKES = previous_takes

    def test_gamepad_rejects_other_device_gyro_and_manual_input(self):
        self.process({"type": "controller_begin", "client_id": "gamepad-A"})
        with self.assertRaisesRegex(ValueError, "另一台设备"):
            self.process({"type": "input", "client_id": "phone-B", "input_source": "gamepad",
                          "move": [0.2, 0, 0], "look": [0, 0]})
        with self.assertRaisesRegex(ValueError, "控制模式不匹配"):
            self.process({"type": "orientation", "client_id": "gamepad-A",
                          "quaternion": [0, 0, 0, 1]})
        with self.assertRaisesRegex(ValueError, "控制模式不匹配"):
            self.process({"type": "input", "client_id": "gamepad-A", "input_source": "manual",
                          "move": [0.2, 0, 0], "look": [0, 0]})

    def test_control_mode_cannot_change_during_recording(self):
        self.process({"type": "controller_begin", "client_id": "gamepad-A"})
        self.process({"type": "record", "client_id": "gamepad-A"})
        with self.assertRaisesRegex(ValueError, "录制中不能切换手机 / 手柄模式"):
            self.process({"type": "control_mode", "mode": "phone", "client_id": "gamepad-A"})
        self.assertTrue(self.s.recording)
        self.process({"type": "stop", "client_id": "gamepad-A"})

    def test_replay_stops_at_take_end_not_scene_end(self):
        take, _ = self.record_with_motion()
        self.scene.frame_end = 48
        take_end = self.s.recorded_take_info()["end"]
        self.process({"type": "play", "client_id": "phone"})
        self.assertTrue(self.s.playing)
        self.s.play_started = time.monotonic() - 10
        self.s.tick()
        self.assertEqual(self.scene.frame_current, take_end)
        self.assertFalse(self.s.playing)
        self.assertIs(self.scene.camera, take)

    def test_deleted_recording_camera_interrupt_releases_controller_lock(self):
        self.process({"type": "controller_begin", "client_id": "gamepad-A"})
        self.process({"type": "record", "client_id": "gamepad-A"})
        take = self.s.recording_camera()
        self.assertEqual(self.s.controller().public()["record_client_id"], "gamepad-A")
        bpy.data.objects.remove(take, do_unlink=True)

        self.s.sync_scene_data()

        self.assertFalse(self.s.recording)
        self.assertIsNone(self.s.controller().public()["record_client_id"])
        self.assertIsNone(self.s.controller().public()["record_mode"])
        self.process({"type": "controller_begin", "client_id": "gamepad-B"})
        self.assertEqual(self.s.controller().owner, "gamepad-B")

    def test_export_spawn_error_closes_log_and_can_retry(self):
        self.record_with_motion()
        webcam = self.fixture.module
        previous_takes = webcam.TAKES
        with tempfile.TemporaryDirectory() as temp_dir:
            webcam.TAKES = Path(temp_dir)
            try:
                with patch.object(webcam.subprocess, "Popen", side_effect=OSError("spawn failed")):
                    with self.assertRaisesRegex(ValueError, "无法启动导出进程"):
                        self.s.begin_export(mode="pov")
                self.assertIsNone(self.s.export_log)
                self.assertIsNone(self.s.export_process)
                self.assertEqual(self.s.export_state["status"], "error")

                with patch.object(webcam.subprocess, "Popen", PendingProcess):
                    self.s.begin_export(mode="pov")
                self.assertEqual(self.s.export_state["status"], "running")
                self.assertIsNotNone(self.s.export_process)
                self.assertIsNotNone(self.s.export_log)
            finally:
                if self.s.export_log:
                    self.s.export_log.close()
                    self.s.export_log = None
                self.s.export_process = None
                webcam.TAKES = previous_takes


def write_report(result):
    report_dir = ROOT / "qa" / "capture-session-regression"
    report_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "suite": "capture-session-regression",
        "tests_run": result.testsRun,
        "passed": result.testsRun - len(result.failures) - len(result.errors),
        "failures": [f"{test}: {detail}" for test, detail in result.failures],
        "errors": [f"{test}: {detail}" for test, detail in result.errors],
        "ok": result.wasSuccessful(),
    }
    (report_dir / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CaptureSessionTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    write_report(result)
    print("CAPTURE_SESSION_REPORT", ROOT / "qa" / "capture-session-regression" / "report.json")
    if not result.wasSuccessful():
        raise SystemExit(1)
    print("CAPTURE_SESSION_TESTS_OK", result.testsRun)
