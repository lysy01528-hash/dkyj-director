# DKYJ Director — windows

Install Blender + Python, then run Install DKYJ Director.cmd, followed by Launch DKYJ Director.cmd.

先安装 Blender、Python，再双击 Install DKYJ Director.cmd，之后双击 Launch DKYJ Director.cmd。电脑 Edge。详见 docs/windows.md。Windows 真机渲染尚待验证。

手机端仅支持 iPhone Safari / Phone: iPhone Safari only.

Full guide: README.md / README.zh-CN.md.
